/* ============================================================================
 * やさしい日本語（NHK WORLD 2019 中文版）· 简明日语精读 —— 前端主程序
 *
 * 数据（构建期已备好，运行时只读）：
 *   data/eps/index.json      集数索引 {episodes:[{ep,tag,title,desc,dur,audio,cues,zh,ru}]}
 *   data/eps/epNN.json       {ep,tag,title,desc,dur,audio,cues:[{s,e,rows:[]}]}
 *       row = { t:日文, ru:[[表层,读音]](完整覆盖 t), zh:简体中文,
 *               w:[{k:词,s:读音,p:词性,b:原形}], sp:说话人, grp:分组,
 *               st:句型key(可缺), blk:[[日文块,中文块]](可缺), note:备注(可缺) }
 *   data/lexicon/vocab.json  词库（可缺 → 优雅降级）
 *   data/lexicon/styles.json 文型（可缺）
 *   data/lexicon/grammar.json 句型（可缺）
 *
 * 音频：同源相对路径 media/epNN.m4a
 *   网页版 → <audio> 直接取站点上的文件
 *   APK    → 同一个地址由本机代理伺服（assets 内置 → 断网也能听）
 *
 * ⚠️ 写这个文件时守的规矩（都是踩过的坑）：
 *   ① 新增函数先 grep 同名（函数声明提升会互相覆盖，静默失效无报错）
 *   ② 不用 el.innerHTML +=（会重新解析 DOM 冲掉 onclick）→ 一次性建容器 + appendChild
 *   ③ st / blk / note / 词库缺失都是正常情况 → 优雅降级，不报错、不白屏
 * ========================================================================== */
(function () {
  'use strict';

  var APP_VER = '1.0.0';
  var CFG = window.EJ_CFG || window.PONY_CFG || { BUNDLED: false };
  var LS_KEY = 'td_';                 /* 本项目自己的 localStorage 前缀（别用 pony.） */
  var AUDIO_DIR = 'media/';           /* 音频与站点同源 → 不依赖任何外部 CDN */
  var WEB_CACHE = 'td-audio-v1';      /* 网页版的音频缓存（Cache API） */

  var $ = function (s) { return document.querySelector(s); };
  var $$ = function (s) { return Array.prototype.slice.call(document.querySelectorAll(s)); };

  /* ---------------- 状态 ---------------- */
  var S = {
    eps: [], ep: null, lines: [], idx: -1,
    playing: false, pos: 0, dur: 0, hasAudio: true,
    zh: true, follow: true, loopOne: false,
    fs: 30, pfs: 17,
    fav: {}, progress: {},
    lex: { vocab: {}, styles: {}, grammar: {} },
    trad: false,
    exIdx: -1, studyTab: 'fav',
    lexReady: false, lexTried: false, lexToast: false
  };

  var LS = {
    get: function (k, d) {
      try { var v = localStorage.getItem(LS_KEY + k); return v == null ? d : JSON.parse(v); }
      catch (e) { return d; }
    },
    set: function (k, v) { try { localStorage.setItem(LS_KEY + k, JSON.stringify(v)); } catch (e) { } }
  };

  var au = $('#au');
  var isNative = !!(window.Android && typeof window.Android.playAudio === 'function');
  var tickCb = null;
  var lastSpeaker = '';

  /* ---------------- 工具 ---------------- */
  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }
  function fmt(sec) {
    sec = Math.max(0, sec || 0);
    var m = Math.floor(sec / 60), s = Math.floor(sec % 60);
    return m + ':' + (s < 10 ? '0' + s : s);
  }
  function fmtMs(ms) { return fmt((ms || 0) / 1000); }
  function closest(el, sel) { return el && el.closest ? el.closest(sel) : null; }

  /* ---------------- 播放层 ---------------- */
  function nativeLoad(url, posMs) { window.Android.playAudio(url, posMs || 0); }
  function nativePlay() { window.Android.resumeAudio(); }
  function nativePause() { window.Android.pauseAudio(); }
  function nativeSeek(ms) { window.Android.seekAudio(ms); }
  function nativeStop() { try { window.Android.stopAudio(); } catch (e) { } }

  /** 音频地址：同源相对路径 → 站点上是 https://站点/media/ep01.m4a，
   *  APK 里是 http://127.0.0.1:18788/app/media/ep01.m4a（同一个相对路径解析出来的） */
  function audioRel() {
    if (!S.ep) return '';
    if (!S.ep.audio) return '';          /* 这一本没有配音 ⇒ 不要去请求一个 404 的 mp3 */
    return AUDIO_DIR + S.ep.tag + '.mp3';
  }
  function audioUrl() {
    var rel = audioRel();
    if (!rel) return '';            /* ⚠️ new URL('', base) 会返回 base（网页地址）⇒ 必须先判空 */
    try { return new URL(rel, document.baseURI || location.href).href; }
    catch (e) { return rel; }
  }

  function loadEp(ep, posMs) {
    if (!ep) return;
    S.ep = ep;
    S.pos = 0;
    S.dur = Math.round((ep.dur || 0) * 1000);
    S.idx = -1;
    lastSpeaker = '';
    var url = audioUrl();
    if (!url) {
      /* 本书无配音：清掉上一本的音频（否则会接着放别的故事），并把播放键置灰 */
      au.removeAttribute('src');
      try { au.load(); } catch (e) { }
      S.hasAudio = false;
      S.dur = 0;
    } else {
      S.hasAudio = true;
      if (isNative) nativeLoad(url, posMs || 0);
      else { au.src = url; if (posMs) au.currentTime = posMs / 1000; au.load(); }
    }
    var lb = $('#epLabel'); if (lb) lb.textContent = '第' + ep.ep + '课';
    renderCues();
    setIdx(binarySearch(posMs || 0), true);
    updateProgress();
    refreshTools();
    updateProgress();
  }

  function play() {
    if (!S.hasAudio) { toast('这一本暂时没有配音，可以先看原文和语法拆解'); return; }
    if (isNative) nativePlay(); else au.play().catch(function () { });
    S.playing = true; $('#btnPlay').textContent = '❚❚';
  }
  function pause() {
    if (isNative) nativePause(); else au.pause();
    S.playing = false; $('#btnPlay').textContent = '▶';
  }
  function togglePlay() { S.playing ? pause() : play(); }
  function seek(ms) {
    ms = Math.max(0, Math.min(ms, S.dur || 1e9));
    if (isNative) nativeSeek(ms); else au.currentTime = ms / 1000;
    S.pos = ms;
    setIdx(binarySearch(ms), true);
    updateProgress();
  }

  /* 通用原生钩子（hub 加的）：新项目不用改原生层 */
  window.__hubTick = function (d) {
    S.pos = d.pos; S.dur = d.dur || S.dur; S.playing = !!d.playing;
    var b = $('#btnPlay'); if (b && S.hasAudio) b.textContent = S.playing ? '❚❚' : '▶';
    if (tickCb) tickCb(d);
  };
  if (!isNative) {
    var send = function () {
      window.__hubTick({
        pos: au.currentTime * 1000, dur: (au.duration || 0) * 1000, playing: !au.paused
      });
    };
    au.addEventListener('timeupdate', send);
    au.addEventListener('ended', function () { window.__hubTick({ pos: S.dur, dur: S.dur, playing: false }); });
    au.addEventListener('play', send);
    au.addEventListener('pause', send);
    /* 诊断：音频源拿不到时要说人话，别静默失败 */
    au.addEventListener('error', function () {
      var st = au.error || {};
      var why = st.code === 4 ? '（网络不通或地址失效）'
        : st.code === 3 ? '（解码失败）'
        : st.code === 2 ? '（网络错误）' : ('（' + (st.code || '?') + '）');
      toast('这一集没声音：音频源加载失败' + why);
    });
  }

  /* ---------------- 数据 ---------------- */
  function loadIndex() {
    return fetch('data/eps/index.json').then(function (r) { return r.json(); })
      .then(function (o) { S.eps = o.episodes || []; });
  }
  function loadCues(ep) {
    return fetch('data/eps/' + ep.tag + '.json').then(function (r) { return r.json(); });
  }

  /* 词库/句型库：体积大（几百 KB）→ 不进首屏，进播放页时后台预热
   * 缺文件是正常情况（主会话还在补）→ 静默降级，弹窗里显示「词库还没装上」
   * 弹窗先开、词库后到 → 词库到位后自动重画弹窗（老花眼不用手动刷新） */
  function ensureWordData() {
    if (S.lexReady || S.lexTried) return;
    S.lexTried = true;
    var jobs = [
      ['vocab', 'data/lexicon/vocab.json'],
      ['styles', 'data/lexicon/styles.json'],
      ['grammar', 'data/lexicon/grammar.json']
    ];
    var ps = jobs.map(function (j) {
      return fetch(j[1])
        .then(function (r) { return r.ok ? r.json() : {}; })
        .catch(function () { return {}; });
    });
    Promise.all(ps).then(function (res) {
      S.lex = { vocab: res[0] || {}, styles: res[1] || {}, grammar: res[2] || {} };
      S.lexReady = true;
      if (S.exIdx >= 0) refreshEx();
      if (S.studyTab === 'pat') renderStudy();
    });
  }

  /* ---------------- 渲染字幕流 ---------------- */
  /** 逐字 ruby：ru[i] = [表层, 读音]；读音为空 → 不出 <rt> */
  function rubyHtml(row, forPopup) {
    if (!row.ru || !row.ru.length) return esc(row.t || '');
    var out = '';
    for (var i = 0; i < row.ru.length; i++) {
      var t = row.ru[i][0], rr = row.ru[i][1];
      if (!t) continue;
      var inner = rr ? '<ruby>' + esc(t) + '<rt>' + esc(rr) + '</rt></ruby>' : esc(t);
      var attr = forPopup ? ' data-word="' + esc(t) + '"' : ' data-w="' + esc(t) + '"';
      out += '<span class="jpw"' + attr + '>' + inner + '</span>';
    }
    return out;
  }

  var GRP_NAME = { skit: '短剧', key: '重点语句', useit: '说说看 · 跟读', bonus: '常用语句' };

  /* 把 cue 摊平成「行」：一个 cue 里可能有多行台词（rows）
   * 说话人：NHK 的字幕只在「一句话的第一行」标角色名，后面的行沿用 → 这里接力
   * 但只有「短剧对话」组才有角色（重点语句 / 说说看 / 常用语句 是示范句，不带角色） */
  function flatten(cues) {
    var lines = [];
    var who = '';
    for (var i = 0; i < cues.length; i++) {
      var c = cues[i];
      var rows = c.rows || [];
      for (var j = 0; j < rows.length; j++) {
        var r = rows[j];
        if (!r.t) continue;
        var skit = !r.grp || r.grp === 'skit';
        if (skit) {
          if (r.sp) who = r.sp;
        } else {
          who = r.sp || '';
        }
        lines.push({
          cue: c, row: r, s: c.s, e: c.e, first: j === 0, cueIdx: i,
          sp: who, newSp: !!r.sp,
          /* 这句在音频里没有对应（书面原文有、朗読没念）⇒ 不参与高亮/跳转 */
          noAudio: !!c.no_audio
        });
      }
    }
    return lines;
  }

  function renderCues() {
    var box = $('#cueBox');
    var html = '';
    var lastGrp = '';
    for (var i = 0; i < S.lines.length; i++) {
      var L = S.lines[i];
      var r = L.row;
      var grp = r.grp || '';
      /* 分组变化 → 一条细分隔线（短剧那组在最上面，不画） */
      if (grp && grp !== lastGrp) {
        if (grp !== 'skit' && GRP_NAME[grp]) {
          html += '<div class="grp-div"><span>' + esc(GRP_NAME[grp]) + '</span></div>';
        }
        lastGrp = grp;
      }
      html += '<div class="cue" data-i="' + i + '">';
      /* 说话人 + 时间：只在有内容时占一行（续行不重复占位） */
      var head = '';
      if (L.sp && L.newSp) head += '<span class="cue-sp">' + esc(L.sp) + '</span>';
      if (L.first) head += '<span class="cue-t">' + fmt(L.s) + '</span>';
      if (head) html += '<div class="cue-hd">' + head + '</div>';
      html += '<div class="cue-ja">' + rubyHtml(r, false) + '</div>';
      if (S.zh) html += '<div class="cue-zh">' + esc(zhText(r)) + '</div>';
      html += '</div>';
    }
    box.innerHTML = html;
    renderKeyCard();
  }

  /* 本课重点语句卡片：这一课的「重点语句」摆到最上面，点一下直接进详解窗 */
  function renderKeyCard() {
    var card = $('#keyCard');
    if (!card) return;
    var items = [];
    for (var i = 0; i < S.lines.length; i++) {
      if (S.lines[i].row.grp === 'key') items.push(i);
    }
    if (!items.length) { card.classList.add('hidden'); card.innerHTML = ''; return; }
    var h = '<div class="kc-hd">本课重点语句</div>';
    for (var j = 0; j < items.length; j++) {
      var L = S.lines[items[j]];
      h += '<div class="kc-item" data-i="' + items[j] + '">' +
        '<div class="kc-ja">' + rubyHtml(L.row, false) + '</div>' +
        '<div class="kc-zh">' + esc(zhText(L.row)) + '</div></div>';
    }
    card.innerHTML = h;
    card.classList.remove('hidden');
  }

  /* 简 / 繁：繁体模式用预生成的 zt 字段（构建期 OpenCC s2t 算好），没有就回退简体 */
  function zhText(row) {
    if (!row) return '';
    if (S.trad && row.zt) return row.zt;
    return row.zh || '';
  }

  function binarySearch(ms) {
    var lo = 0, hi = S.lines.length - 1, ans = -1;
    while (lo <= hi) {
      var mid = (lo + hi) >> 1;
      if (S.lines[mid].s * 1000 <= ms) { ans = mid; lo = mid + 1; }
      else hi = mid - 1;
    }
    /* 回退到最近一条「音频里有对应」的句子 ⇒ 高亮不会停在哑句上 */
    while (ans >= 0 && S.lines[ans].noAudio) ans--;
    return ans;
  }

  function setIdx(i, scroll) {
    if (i === S.idx) return;
    var old = $('.cue.on');
    if (old) old.classList.remove('on');
    S.idx = i;
    var el = $('.cue[data-i="' + i + '"]');
    if (el) {
      el.classList.add('on');
      if (scroll && S.follow && !exOpen()) {
        var box = $('#stream');
        var r = el.getBoundingClientRect(), br = box.getBoundingClientRect();
        if (r.top < br.top + 8 || r.bottom > br.bottom - 8) {
          box.scrollTop += (r.top - br.top) - br.height * 0.38;
        }
      }
    }
    if (S.loopOne && S.playing) {
      var L = S.lines[i];
      if (L) seek(L.s * 1000);
    }
  }

  function updateProgress() {
    var pct = S.dur ? Math.max(0, Math.min(1, S.pos / S.dur)) : 0;
    var f = $('#scrubFill'); if (f) f.style.width = (pct * 100) + '%';
    var d = $('#scrubDot'); if (d) d.style.left = (pct * 100) + '%';
    var t = $('#timeLabel');
    if (t) t.textContent = S.hasAudio ? (fmtMs(S.pos) + ' / ' + fmtMs(S.dur)) : '— / —';
  }

  /* ---------------- 详解大弹窗 ---------------- */
  function exOpen() { return !$('#exSheet').classList.contains('hidden'); }

  /** 查词：先按表层形查，再按原形（b）查，都没有 → null */
  function vocabFor(word, base) {
    if (!word) return null;
    var v = S.lex.vocab[word];
    if (v) return v;
    if (base) {
      v = S.lex.vocab[base];
      if (v) return v;
    }
    /* 去掉送假名再试一次（ Attached 用法） */
    var plain = word.replace(/[ぁ-んァ-ヶー]+$/u, '');
    if (plain && plain !== word) {
      v = S.lex.vocab[plain];
      if (v) return v;
    }
    return null;
  }

  function openEx(i, opt) {
    var L = S.lines[i];
    if (!L) return;
    S.exIdx = i;
    opt = opt || {};
    /* 词库还在路上 → 先开始加载，并提示一次（别让老花眼以为没内容） */
    if (!S.lexReady) {
      if (!S.lexTried) ensureWordData();
      if (!S.lexToast) { S.lexToast = true; toast('正在載入詞庫…'); }
    }
    var r = L.row;
    var h = '';

    /* ① 原句（全注音）+ 中文 */
    h += '<div class="ex-orig">' +
      '<div class="ex-jp">' + rubyHtml(r, true) + '</div>' +
      '<div class="ex-zh">' + esc(zhText(r)) + '</div>' +
      (r.note ? '<div class="ex-note">' + esc(r.note) + '</div>' : '') +
      '<div class="ex-act">' +
      '<button class="mini-btn" data-act="speak">🔊 朗读</button>' +
      '<button class="mini-btn" data-act="seek">⤓ 跳到这句</button>' +
      '<button class="mini-btn" data-act="copy">复制整句</button>' +
      '</div></div>';

    /* ② 语法拆解（用户定的三段式：一、大框架 / 二、逐块拆解 / 整句意思）
     *   ⚠️ 旧的「①逐词拆解 → ②语法说明 → ③整句结构」已废弃，别改回去。 */
    var g = r.g || {};
    h += '<div class="ex-sec">语法拆解</div>';

    h += '<div class="ex-sub">一、大框架</div>';
    if (g.frame) {
      h += '<div class="ex-frame">' + esc(g.frame) + '</div>';
      if (g.tree && g.tree.length) {
        h += '<div class="ex-roles">';
        for (var gi = 0; gi < g.tree.length; gi++) {
          h += '<div class="ex-role-row"><span class="ex-role-t">' + esc(g.tree[gi].t) + '</span>' +
            '<span class="ex-role-tag">' + esc(g.tree[gi].role) + '</span>' +
            '<span class="ex-role-pos">' + esc(g.tree[gi].pos || '') + '</span></div>';
        }
        h += '</div>';
      }
    } else {
      h += '<div class="ex-none">这一句成分简单，没有分层修饰。</div>';
    }

    h += '<div class="ex-sub">二、逐块拆解</div>';
    if (r.blk && r.blk.length) {
      h += '<div class="ex-blocks">';
      for (var bi = 0; bi < r.blk.length; bi++) {
        var bj = r.blk[bi][0] || '', bz = r.blk[bi][1] || '', bp = r.blk[bi][2] || '', br = r.blk[bi][3] || '';
        var bw = r.blk[bi][4] || [];
        h += '<div class="ex-block">';
        h += '<div class="ex-block-jp">' + esc(bj) + '</div>';
        if (br || bp) {
          h += '<div class="ex-block-meta"><span class="ex-block-role">' + esc(br) + '</span>' +
            '<span class="ex-block-pos">' + esc(bp) + '</span></div>';
        }
        if (bw.length) {
          h += '<div class="ex-block-words">';
          for (var wi = 0; wi < bw.length; wi++) {
            h += '<span class="ex-wchip" data-word="' + esc(bw[wi].k || bw[wi].s) + '">' +
              esc(bw[wi].s || bw[wi].k) +
              (bw[wi].p ? '<em>' + esc(bw[wi].p) + '</em>' : '') + '</span>';
          }
          h += '</div>';
        }
        if (bz) h += '<div class="ex-block-zh">意思：' + esc(bz) + '</div>';
        h += '</div>';
      }
      h += '</div>';
    } else {
      h += '<div class="ex-none">本句暂无分块标注。</div>';
    }

    h += '<div class="ex-sub">整句意思</div>';
    h += '<div class="ex-whole">' + esc(r.zh || '（这句还没有译文）') + '</div>';

    /* 底部操作 */
    var isFav = !!S.fav[favKey()];
    h += '<div class="ex-foot">' +
      '<button class="mini-btn" data-act="loop">' + (S.loopOne ? '🔁 循环中' : '🔁 循环本句') + '</button>' +
      '<button class="mini-btn' + (isFav ? ' on' : '') + '" data-act="fav">' + (isFav ? '★ 已收藏' : '☆ 收藏本句') + '</button>' +
      '<button class="mini-btn" data-act="dl">⬇ 存本集</button>' +
      '<span class="sp"></span>' +
      '<button class="mini-btn" data-act="close">收起 ▲</button>' +
      '</div>';

    $('#exBody').innerHTML = h;
    var who = $('#exWho');
    if (who) who.textContent = (L.sp ? L.sp + ' · ' : '') + '详解';
    $('#exTime').textContent = fmt(L.s);
    $('#exSheet').classList.remove('hidden');
    $('#exMask').classList.remove('hidden');
    $('#exBody').scrollTop = 0;

    /* 点词直接进来 → 把那个词就地展开 */
    if (opt.word) {
      var li = findWordLi(opt.word);
      if (li) {
        expandWord(li, opt.word, true);
        try { li.scrollIntoView({ block: 'center' }); } catch (err) { }
      }
    }
  }

  /* 句型例句匹配：句型库的 example 都是本剧真台词 */
  var gramIndex = null;
  function buildGramIndex() {
    if (gramIndex) return gramIndex;
    gramIndex = {};
    var g = S.lex.grammar || {};
    for (var k in g) {
      var ex = (g[k].example || '').replace(/\s+/g, '');
      if (ex) gramIndex[ex] = g[k];
    }
    return gramIndex;
  }
  function matchGrammar(text) {
    if (!text) return null;
    var idx = buildGramIndex();
    var t = String(text).replace(/\s+/g, '');
    if (idx[t]) return idx[t];
    /* 退一步：用句首 6 字匹配 */
    if (t.length > 6) {
      for (var ex in idx) {
        if (ex.length > 6 && t.indexOf(ex) >= 0) return idx[ex];
      }
    }
    return null;
  }

  function closeEx() {
    $('#exSheet').classList.add('hidden');
    $('#exMask').classList.add('hidden');
    S.exIdx = -1;
  }

  /* 词库到位后重画弹窗（保留滚动位置和展开的那个词） */
  function refreshEx() {
    var i = S.exIdx;
    if (i < 0) return;
    var body = $('#exBody');
    var top = body ? body.scrollTop : 0;
    var li = body ? body.querySelector('.ex-wd li.on') : null;
    var word = li ? li.getAttribute('data-word') : null;
    openEx(i, { word: word });
    if (body) body.scrollTop = top;
  }

  function findWordLi(word) {
    var list = $$('.ex-wd li');
    for (var i = 0; i < list.length; i++) {
      if (list[i].getAttribute('data-word') === word) return list[i];
    }
    return null;
  }

  /* 弹窗内点词 → 在弹窗里就地展开（就地展开唯一该用的地方） */
  function expandWord(li, word, forceOpen) {
    var open = li.querySelector('.ex-detail');
    if (open && !forceOpen) { open.remove(); li.classList.remove('on'); return; }
    if (open) return;
    $$('.ex-wd li.on').forEach(function (x) {
      x.classList.remove('on');
      var d = x.querySelector('.ex-detail');
      if (d) d.remove();
    });
    var w = null, base = '';
    var row = S.lines[S.exIdx] ? S.lines[S.exIdx].row : null;
    var wl = (row && row.w) ? row.w : [];
    for (var i = 0; i < wl.length; i++) {
      if (wl[i].k === word) { w = wl[i]; break; }
    }
    if (w) base = w.b || '';
    var v = vocabFor(word, base);
    var h = '<div class="ex-detail">';
    h += '<div class="d-h"><span class="d-w">' + esc(word) + '</span>' +
      (v && v.reading ? '<span class="d-r">' + esc(v.reading) + '</span>' : '') +
      (v && v.pos ? '<span class="d-p">' + esc(v.pos) + '</span>' : '') +
      (base && base !== word ? '<span class="d-p">原形 ' + esc(base) + '</span>' : '') + '</div>';
    if (v) {
      if (v.meaning) h += '<div class="d-m">' + esc(v.meaning) + '</div>';
      if (v.usage) h += '<div class="d-u">' + esc(v.usage) + '</div>';
      if (v.example) h += '<div class="d-e"><b>本剧例句</b>' + esc(v.example) +
        (v.exampleZh ? '<em>' + esc(v.exampleZh) + '</em>' : '') + '</div>';
    } else {
      h += '<div class="d-m">词库里还没有这个词（词库还在补充中）。</div>';
    }
    h += '</div>';
    li.insertAdjacentHTML('beforeend', h);
    li.classList.add('on');
  }

  /* ---------------- 朗读（Web Speech API） ---------------- */
  function jaVoice() {
    try {
      if (!window.speechSynthesis) return null;
      var vs = speechSynthesis.getVoices() || [];
      for (var i = 0; i < vs.length; i++) {
        if (vs[i] && vs[i].lang && vs[i].lang.toLowerCase().indexOf('ja') === 0) return vs[i];
      }
    } catch (e) { }
    return null;
  }
  function speak(text) {
    if (!text) return;
    try {
      if (!window.speechSynthesis) { toast('这台设备不支持朗读'); return; }
      var u = new SpeechSynthesisUtterance(text);
      u.lang = 'ja-JP';
      u.rate = 0.85;
      var v = jaVoice();
      if (v) u.voice = v;
      speechSynthesis.cancel();
      speechSynthesis.speak(u);
      if (!v) {
        /* 没装日语语音包 → 给指引（不是报错，是用户能自己解决的） */
        setTimeout(function () {
          toast('没有日语语音包：请到「设置 → 语言 → 文字转语音」里添加日语');
        }, 300);
      }
    } catch (e) { toast('朗读失败'); }
  }
  function copySentence(btn) {
    var L = S.lines[S.exIdx];
    var txt = L && L.row ? (L.row.t || '') : '';
    if (!txt) { toast('这句没有可复制的日文'); return; }
    var done = function () {
      if (btn) { var old = btn.textContent; btn.textContent = '已复制'; setTimeout(function () { btn.textContent = old; }, 1400); }
      toast('已复制整句日文');
    };
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(txt).then(done, function () { legacyCopy(txt, done); });
        return;
      }
    } catch (e) { }
    legacyCopy(txt, done);
  }

  function legacyCopy(txt, done) {
    var ta = document.createElement('textarea');
    ta.value = txt;
    ta.setAttribute('readonly', '');
    ta.style.position = 'fixed';
    ta.style.left = '-9999px';
    document.body.appendChild(ta);
    ta.select();
    ta.setSelectionRange(0, ta.value.length);
    var ok = false;
    try { ok = document.execCommand('copy'); } catch (e) { ok = false; }
    document.body.removeChild(ta);
    if (ok) done(); else toast('复制失败，请长按选择文字');
  }

  function speakCurrent() {
    var L = S.lines[S.exIdx];
    if (!L || !L.row.t) return;
    speak(L.row.t);
  }

  /* ---------------- 收藏 ---------------- */
  function favKey() {
    var L = S.lines[S.exIdx];
    if (!L) return '';
    return S.ep.tag + '@' + L.cueIdx + '@' + (L.row.t || '').slice(0, 24);
  }
  function toggleFav() {
    var k = favKey();
    if (!k) return false;
    if (S.fav[k]) delete S.fav[k];
    else {
      var L = S.lines[S.exIdx];
      S.fav[k] = { ep: S.ep.tag, epNo: S.ep.ep, ja: L.row.t, zh: L.row.zh, sp: L.sp || '' };
    }
    LS.set('fav', S.fav);
    renderStudy();
    return !!S.fav[k];
  }

  /* ---------------- 学习页（我的收藏 + 句型表） ---------------- */
  function renderStudy() {
    var list = $('#studyList');
    if (!list) return;
    if (S.studyTab === 'fav') {
      var keys = Object.keys(S.fav);
      var c = $('#studyCount'); if (c) c.textContent = keys.length ? keys.length + ' 条' : '';
      if (!keys.length) {
        list.innerHTML = '<div class="ex-none" style="padding:16px 4px">还没有收藏。点任意一句 → 弹窗里「☆ 收藏本句」。</div>';
        return;
      }
      var h = '';
      for (var i = 0; i < keys.length; i++) {
        var f = S.fav[keys[i]];
        h += '<div class="st-item"><div class="st-h">' +
          '<span class="st-w">' + esc(f.ja) + '</span>' +
          '<span class="st-cat">第' + f.epNo + '课</span>' +
          '<button class="st-del" data-fav="' + esc(keys[i]) + '">删除</button></div>' +
          (f.sp ? '<div class="st-sp">' + esc(f.sp) + '</div>' : '') +
          '<div class="st-m">' + esc(f.zh || '') + '</div></div>';
      }
      list.innerHTML = h;
    } else {
      var g = S.lex.grammar || {};
      var gk = Object.keys(g);
      var c2 = $('#studyCount'); if (c2) c2.textContent = gk.length ? gk.length + ' 条' : '';
      if (!gk.length) {
        list.innerHTML = '<div class="ex-none" style="padding:16px 4px">句型表还没装上（词库还在补充中）。</div>';
        return;
      }
      var h2 = '';
      for (var j = 0; j < gk.length; j++) {
        var p = g[gk[j]];
        h2 += '<div class="st-item"><div class="st-h">' +
          '<span class="st-w">' + esc(p.name) + '</span>' +
          (p.short ? '<span class="st-r">' + esc(p.short) + '</span>' : '') +
          (p.cat ? '<span class="st-cat">' + esc(p.cat) + '</span>' : '') + '</div>' +
          (p.conn ? '<div class="st-u"><b>接续</b> ' + esc(p.conn) + '</div>' : '') +
          (p.mean ? '<div class="st-m">' + esc(p.mean) + '</div>' : '') +
          (p.feel ? '<div class="st-u"><b>语感</b> ' + esc(p.feel) + '</div>' : '') +
          (p.note ? '<div class="st-u">' + esc(p.note) + '</div>' : '') +
          (p.chain ? '<div class="st-u"><b>形态链</b> ' + esc(p.chain) + '</div>' : '') +
          (p.example ? '<div class="st-e"><b>本剧例句</b>' + esc(p.example) +
            (p.exampleZh ? '<em>' + esc(p.exampleZh) + '</em>' : '') + '</div>' : '') +
          '</div>';
      }
      list.innerHTML = h2;
    }
  }

  function openStudy() {
    $('#viewPlayer').classList.add('hidden');
    $('#viewStudy').classList.remove('hidden');
    $('#btnBack').classList.remove('hidden');
    renderStudy();
  }
  function backToPlayer() {
    $('#viewStudy').classList.add('hidden');
    $('#viewPlayer').classList.remove('hidden');
    $('#btnBack').classList.add('hidden');
  }

  /* ---------------- 下载 / 缓存 ---------------- */
  function inApk() { return !!(window.Android && typeof window.Android.downloadAudio === 'function'); }
  function webCacheOk() {
    try { return typeof caches !== 'undefined' && !!caches.open; } catch (e) { return false; }
  }

  /** 按「地址」判断是否已存（hub 里各项目的音频都叫 epNN.m4a，只按 id 会串台） */
  function epDownloaded(url) {
    if (inApk()) {
      try {
        var st = JSON.parse(window.Android.downloadedList() || '{}');
        var items = st.items || [];
        if (Array.isArray(items)) {
          for (var i = 0; i < items.length; i++) {
            if (items[i] && items[i].url && items[i].url === url) return true;
          }
        } else {
          for (var k in items) {
            var one = items[k];
            var o = null;
            try { o = (typeof one === 'string') ? JSON.parse(one) : one; } catch (e) { o = null; }
            if (o && o.url && o.url === url) return true;
          }
        }
      } catch (e) { }
      return false;
    }
    if (webCacheOk()) {
      if (webCacheUrls[url]) return true;
    }
    return false;
  }

  /* 网页版缓存：Cache API。存过的集由 sw.js 从缓存里放出来（断网也能听）
   * ⚠️ caches.open() 返回的是 Promise —— 不能直接 .keys()（会报 "c.keys is not a function"） */
  var webCacheRef = null;      /* Promise<Cache> */
  var webCacheUrls = {};
  function webCacheOpen() {
    if (!webCacheOk()) return null;
    if (!webCacheRef) {
      try { webCacheRef = caches.open(WEB_CACHE); } catch (e) { return null; }
    }
    return webCacheRef;
  }
  function refreshWebCache() {
    var c = webCacheOpen();
    if (!c) return Promise.resolve(null);
    return c.then(function (cache) { return cache.keys(); })
      .then(function (keys) {
        var urls = {};
        for (var i = 0; i < keys.length; i++) urls[keys[i].url] = true;
        webCacheUrls = urls;
        return keys.length;
      }).catch(function () { return null; });
  }
  function webCacheSize() {
    var c = webCacheOpen();
    if (!c) return Promise.resolve({ count: 0, bytes: 0 });
    return c.then(function (cache) { return cache.keys(); })
      .then(function (keys) {
        var ps = keys.map(function (k) {
          return cache.match(k).then(function (res) {
            if (!res) return 0;
            var len = res.headers.get('content-length');
            if (len) return parseInt(len, 10) || 0;
            return res.clone().blob().then(function (b) { return b.size; }).catch(function () { return 0; });
          }).catch(function () { return 0; });
        });
        return Promise.all(ps).then(function (sizes) {
          var bytes = 0;
          for (var i = 0; i < sizes.length; i++) bytes += sizes[i];
          return { count: keys.length, bytes: bytes };
        });
      }).catch(function () { return { count: 0, bytes: 0 }; });
  }

  function refreshTools() {
    var url = audioUrl();
    var pb = $('#btnPlay');
    if (pb) {
      if (!S.hasAudio) { pb.textContent = '无音频'; pb.disabled = true; pb.classList.add('off'); }
      else { pb.disabled = false; pb.classList.remove('off'); pb.textContent = S.playing ? '❚❚' : '▶'; }
    }
    var dl = $('#btnDl');
    if (dl) {
      var done = epDownloaded(url);
      dl.textContent = done ? '✓ 已存' : '⬇ 下載';
      dl.classList.toggle('done', done);
      dl.title = done ? '这一集已经存在手机里了' : '把本集音频存到手机（断网也能听）';
    }
    var lo = $('#btnLoopOne2');
    if (lo) lo.classList.toggle('on', S.loopOne);
    var tr = $('#btnTrad2');
    if (tr) { tr.classList.toggle('on', !!S.trad); tr.textContent = S.trad ? '繁體' : '簡體'; }
  }

  function downloadCurrent() {
    var url = audioUrl();
    if (epDownloaded(url)) { toast('第' + S.ep.ep + '课已经在手机里了'); return; }
    if (inApk()) {
      try {
        window.Android.downloadAudio(url, S.ep.tag);
        toast('正在保存第' + S.ep.ep + '课…');
        var t = setInterval(function () {
          try {
            var st = JSON.parse(window.Android.downloadStatus() || '{}');
            if (st.state === 'done') { clearInterval(t); toast('已存到手机'); refreshCache(); refreshTools(); }
            else if (st.state === 'error') { clearInterval(t); toast('保存失败：' + (st.error || '')); }
          } catch (e) { clearInterval(t); }
        }, 900);
      } catch (e) { toast('保存失败'); }
      return;
    }
    if (!webCacheOk()) {
      toast('这个浏览器不能缓存音频，请用 Android App');
      return;
    }
    toast('正在保存第' + S.ep.ep + '课…');
    var c = webCacheOpen();
    fetch(url).then(function (r) {
      if (!r.ok) throw new Error('HTTP ' + r.status);
      return c.then(function (cache) { return cache.put(new Request(url), r.clone()); });
    }).then(function () {
      return refreshWebCache();
    }).then(function () {
      toast('已存到手机（断网也能听）');
      refreshCache(); refreshTools();
    }).catch(function (e) {
      toast('保存失败：' + (e && e.message ? e.message : e));
    });
  }

  function fmtCache(n, b) {
    var mb = (b || 0) / 1048576;
    return n + ' 集 · ' + (mb < 0.1 ? '<0.1' : mb.toFixed(1)) + ' MB';
  }
  function refreshCache() {
    var el = $('#cacheVal');
    if (!el) return;
    if (inApk()) {
      try {
        var info = JSON.parse(window.Android.downloadedList() || '{}');
        el.textContent = fmtCache(info.count || 0, info.bytes || 0);
      } catch (e) { el.textContent = '—'; }
      return;
    }
    if (!webCacheOk()) { el.textContent = '0 集 · 0 MB'; return; }
    webCacheSize().then(function (info) {
      el.textContent = fmtCache(info.count, info.bytes);
    });
  }
  function clearCache() {
    if (!window.confirm('確定刪除所有已下載的音頻？\n（會釋放手機空間，已聽過的集需要重新下載）')) return;
    if (inApk()) {
      try {
        var r = JSON.parse(window.Android.clearDownloads() || '{}');
        toast(r.removed ? ('已刪除 ' + r.removed + ' 個音頻') : '沒有已下載的音頻');
      } catch (e) { toast('刪除失敗'); }
    } else if (webCacheOk()) {
      caches.delete(WEB_CACHE).then(function () {
        webCacheUrls = {};
        toast('已刪除所有已下載的音頻');
      }).catch(function () { toast('刪除失敗'); });
    } else {
      toast('没有已下載的音頻');
    }
    refreshCache(); refreshTools();
  }

  /* ---------------- 字号（字幕 / 弹窗独立） ---------------- */
  function applyFs() {
    document.documentElement.style.setProperty('--fs', S.fs + 'px');
    document.documentElement.style.setProperty('--fszh', Math.round(S.fs * 0.87) + 'px');
    var r = $('#fsRange'); if (r) r.value = S.fs;
  }
  function applyPfs() {
    document.documentElement.style.setProperty('--pfs', S.pfs + 'px');
    var r = $('#pfsRange'); if (r) r.value = S.pfs;
    var v = $('#pfsVal'); if (v) v.textContent = S.pfs;
  }
  function setFs(n) {
    n = Math.max(14, Math.min(40, Math.round(n)));
    S.fs = n; LS.set('fs', n); applyFs();
    if (window.HubShell && window.HubShell.setFs) { try { window.HubShell.setFs(n); } catch (e) { } }
  }
  function setPfs(n) {
    n = Math.max(14, Math.min(30, Math.round(n)));
    S.pfs = n; LS.set('pfs', n); applyPfs();
  }
  /* shell 接管字号时同步回来 */
  window.onHubShellFs = function (n) { S.fs = Math.max(14, Math.min(40, n)); applyFs(); };

  /* ---------------- 轻提示 ---------------- */
  function toast(msg) {
    try {
      if (window.HubShell && typeof window.HubShell.toast === 'function') { window.HubShell.toast(msg); return; }
    } catch (e) { }
    var t = document.createElement('div');
    t.textContent = msg;
    t.style.cssText = 'position:fixed;left:50%;bottom:80px;transform:translateX(-50%);z-index:99;' +
      'background:rgba(20,20,20,.9);color:#fff;padding:10px 18px;border-radius:10px;font:15px/1.4 system-ui;max-width:80%';
    document.body.appendChild(t);
    setTimeout(function () { t.remove(); }, 2200);
  }

  /* ---------------- 选集抽屉 ---------------- */
  function renderEpList() {
    var h = '';
    var lv = '';
    for (var i = 0; i < S.eps.length; i++) {
      var e = S.eps[i];
      if (e.level !== lv) {
        lv = e.level;
        h += '<div class="ep-group">' + esc(lvName(lv)) + '</div>';
      }
      var on = S.ep && e.tag === S.ep.tag;
      h += '<div class="ep-item' + (on ? ' on' : '') + '" data-tag="' + esc(e.tag) + '">' +
        '<span class="ep-n">' + esc(lvShort(e.level)) + '</span>' +
        '<div class="ep-main">' +
        '<div class="ep-d">' + esc(e.desc || e.title || '') + '</div>' +
        '<div class="ep-t">' + esc(e.title || '') + '</div>' +
        '</div>' +
        '<span class="ep-meta">' + fmt(e.dur) + ' · ' + (e.zh || e.cues || 0) + '句' +
        (e.has_audio ? '' : ' · 无音频') + '</span>' +
        '</div>';
    }
    $('#epList').innerHTML = h;
  }

  function lvName(lv) {
    var m = { '教材L0': '教材 Level 0 · 起步（最简单）', '教材L1': '教材 Level 1 · 入门',
              '教材L2': '教材 Level 2 · 初级', '教材L3': '教材 Level 3 · 中级',
              '教材L4': '教材 Level 4 · 中高级',
              '初L1': '别册多読 · 初级 L1（补充）', '中L2': '别册多読 · 中级 L2（补充）',
              '上L3': '别册多読 · 上级 L3（补充）', '别L4': '别册多読 · L4（补充）' };
    return m[lv] || lv;
  }
  function lvShort(lv) {
    var m = { '教材L0': 'L0', '教材L1': 'L1', '教材L2': 'L2', '教材L3': 'L3', '教材L4': 'L4',
              '初L1': '初', '中L2': '中', '上L3': '上', '别L4': '别' };
    return m[lv] || (lv || '').replace('Level', 'L');
  }

  function openSheet(id) {
    var el = $(id);
    if (el) el.classList.remove('hidden');
  }
  function closeSheet(id) {
    var el = $(id);
    if (el) el.classList.add('hidden');
  }
  function togglePanel(id) {
    var el = $(id);
    if (!el) return;
    var wasHidden = el.classList.contains('hidden');
    ['#fontPanel', '#morePanel'].forEach(function (x) { var e = $(x); if (e) e.classList.add('hidden'); });
    if (wasHidden) el.classList.remove('hidden');
  }

  /* ---------------- 事件绑定 ---------------- */
  function bind() {
    $('#btnPlay').addEventListener('click', togglePlay);
    $('#btnEp').addEventListener('click', function () { renderEpList(); openSheet('#epPanel'); });
    $('#btnCloseEp').addEventListener('click', function () { closeSheet('#epPanel'); });
    $('#btnFont').addEventListener('click', function () { togglePanel('#fontPanel'); });
    $('#btnMore').addEventListener('click', function () { togglePanel('#morePanel'); });
    $('#btnBack').addEventListener('click', backToPlayer);

    /* 字号面板 */
    $$('.fp-btn').forEach(function (b) {
      b.addEventListener('click', function () { setFs(S.fs + (+b.getAttribute('data-fs'))); });
    });
    $$('.fp-p[data-preset]').forEach(function (b) {
      b.addEventListener('click', function () { setFs(+b.getAttribute('data-preset')); });
    });
    var fr = $('#fsRange');
    if (fr) fr.addEventListener('input', function () { setFs(+this.value); });

    /* 弹窗字号条（独立） */
    $$('.fp-p[data-pfs]').forEach(function (b) {
      b.addEventListener('click', function () { setPfs(+b.getAttribute('data-pfs')); });
    });
    var pr = $('#pfsRange');
    if (pr) pr.addEventListener('input', function () { setPfs(+this.value); });
    $('#exAa').addEventListener('click', function () {
      var bar = $('#exSizeBar');
      if (bar) bar.classList.toggle('hidden');
    });

    /* 工具条 */
    $('#btnBack10').addEventListener('click', function () { seek(S.pos - 10000); });
    $('#btnFwd10').addEventListener('click', function () { seek(S.pos + 10000); });
    $('#btnLoopOne2').addEventListener('click', function () {
      S.loopOne = !S.loopOne; LS.set('loopOne', S.loopOne); refreshTools();
      toast(S.loopOne ? '单句循环：开' : '单句循环：关');
    });
    $('#btnTrad2').addEventListener('click', function () {
      S.trad = !S.trad; LS.set('trad', S.trad);
      renderCues(); setIdx(S.idx, false); refreshTools();
      toast(S.trad ? '中文：繁体' : '中文：简体');
    });
    $('#btnFontBig2').addEventListener('click', function () { setFs(S.fs + 2); });
    $('#btnDl').addEventListener('click', downloadCurrent);

    /* 更多菜单 */
    $('#btnStudy').addEventListener('click', function () { closeSheet('#morePanel'); openStudy(); });
    $('#btnCache').addEventListener('click', function () { closeSheet('#morePanel'); refreshCache(); openSheet('#cachePanel'); });
    $('#btnZh').addEventListener('click', function () {
      S.zh = !S.zh; LS.set('zh', S.zh);
      this.textContent = S.zh ? '开' : '关'; this.classList.toggle('on', S.zh);
      renderCues(); setIdx(S.idx, false); refreshTools();
    });
    $('#btnFollow').addEventListener('click', function () {
      S.follow = !S.follow; LS.set('follow', S.follow);
      this.textContent = S.follow ? '开' : '关'; this.classList.toggle('on', S.follow);
    });
    // APK 打成 zip 交付（手机直接下 .apk 会被拦）⇒ 站内入口也指 zip
    $('#btnApk').addEventListener('click', function () { location.href = encodeURI('tadoku-apk.zip'); });
    $('#btnApk2').addEventListener('click', function () { location.href = encodeURI('tadoku-apk.zip'); });
    $('#btnCloseCache').addEventListener('click', function () { closeSheet('#cachePanel'); });
    $('#btnClearCache').addEventListener('click', clearCache);

    /* 学习页 tab */
    $$('#studyTabs .tab').forEach(function (t) {
      t.addEventListener('click', function () {
        $$('#studyTabs .tab').forEach(function (x) { x.classList.remove('on'); });
        t.classList.add('on');
        S.studyTab = t.getAttribute('data-tab');
        renderStudy();
      });
    });

    /* 字幕流：点词 → 查那个词；点句 → 跳到这句 + 弹大窗 */
    $('#cueBox').addEventListener('click', function (e) {
      var chip = closest(e.target, '.jpw');
      if (chip) {
        var cueEl = closest(chip, '.cue');
        var ci = cueEl ? +cueEl.getAttribute('data-i') : S.idx;
        var w = chip.getAttribute('data-w');
        speak(w);
        if (ci >= 0) openEx(ci, { word: w });
        return;
      }
      var el = closest(e.target, '.cue');
      if (!el) return;
      var i = +el.getAttribute('data-i');
      /* 哑句（音频里没有这句）⇒ 跳到最近一条有对应的地方，不跳到自己的时间 */
      var j = i;
      while (j >= 0 && S.lines[j].noAudio) j--;
      if (j >= 0) seek(S.lines[j].s * 1000);   /* 点句 → 跳到播放位置 */
      openEx(i);
    });
    /* 本课重点卡片：点一条 → 直接进详解窗 */
    $('#keyCard').addEventListener('click', function (e) {
      var it = closest(e.target, '.kc-item');
      if (!it) return;
      var i = +it.getAttribute('data-i');
      seek(S.lines[i].s * 1000);
      openEx(i);
    });

    /* 弹窗：点词就地展开 / 底部操作 */
    $('#exBody').addEventListener('click', function (e) {
      /* 原句里的词 → 展开逐词区里对应那个词 */
      var chip = closest(e.target, '.ex-jp .jpw');
      if (chip) {
        var cw = chip.getAttribute('data-word');
        speak(cw);
        var li = findWordLi(cw);
        if (li) {
          expandWord(li, cw, true);
          try { li.scrollIntoView({ block: 'center' }); } catch (err) { }
        }
        return;
      }
      var li2 = closest(e.target, '.ex-wd li');
      if (li2) {
        var ww = li2.getAttribute('data-word');
        expandWord(li2, ww);
        speak(ww);
        return;
      }
      var btn = closest(e.target, '[data-act]');
      if (!btn) return;
      var act = btn.getAttribute('data-act');
      if (act === 'close') closeEx();
      else if (act === 'seek') { var L = S.lines[S.exIdx]; if (L) seek(L.s * 1000); closeEx(); }
      else if (act === 'speak') speakCurrent();
      else if (act === 'fav') { var on = toggleFav(); btn.textContent = on ? '★ 已收藏' : '☆ 收藏本句'; btn.classList.toggle('on', on); }
      else if (act === 'loop') { S.loopOne = !S.loopOne; LS.set('loopOne', S.loopOne); refreshTools(); btn.textContent = S.loopOne ? '🔁 循环中' : '🔁 循环本句'; }
      else if (act === 'dl') downloadCurrent();
      else if (act === 'copy') copySentence(btn);
    });

    /* 弹窗头部 */
    $('#exClose').addEventListener('click', closeEx);
    $('#exX').addEventListener('click', closeEx);
    $('#exMask').addEventListener('click', closeEx);
    $('#exJump').addEventListener('click', function () { var L = S.lines[S.exIdx]; if (L) seek(L.s * 1000); closeEx(); });
    $('#exDl').addEventListener('click', downloadCurrent);

    /* 学习页删除收藏 */
    $('#studyList').addEventListener('click', function (e) {
      var b = closest(e.target, '[data-fav]');
      if (!b) return;
      delete S.fav[b.getAttribute('data-fav')];
      LS.set('fav', S.fav);
      renderStudy();
    });

    /* 选集 */
    $('#epList').addEventListener('click', function (e) {
      var el = closest(e.target, '.ep-item');
      if (!el) return;
      var tag = el.getAttribute('data-tag');
      closeSheet('#epPanel');
      var ep = null;
      for (var i = 0; i < S.eps.length; i++) if (S.eps[i].tag === tag) ep = S.eps[i];
      if (!ep) return;
      loadCues(ep).then(function (o) {
        S.lines = flatten(o.cues || []);
        loadEp(ep, 0);
        LS.set('ep', tag);
      }).catch(function () { toast('这一课的课文读不出来'); });
    });

    /* 进度条 */
    $('#scrub').addEventListener('click', function (e) {
      var r = this.getBoundingClientRect();
      seek((e.clientX - r.left) / r.width * (S.dur || 0));
    });

    /* 键盘（桌面/横屏用） */
    document.addEventListener('keydown', function (e) {
      if (e.key === ' ') { e.preventDefault(); togglePlay(); }
      else if (e.key === 'ArrowLeft') seek(S.pos - 5000);
      else if (e.key === 'ArrowRight') seek(S.pos + 5000);
      else if (e.key === 'Escape') { closeEx(); closeSheet('#epPanel'); closeSheet('#cachePanel'); }
    });
  }

  /* ---------------- 启动 ---------------- */
  function init() {
    S.zh = LS.get('zh', true) !== false;
    S.trad = LS.get('trad', false) === true;
    S.follow = LS.get('follow', true) !== false;
    S.loopOne = !!LS.get('loopOne', false);
    S.fav = LS.get('fav', {});
    var fs0 = LS.get('fs', 30);
    S.fs = Math.max(14, Math.min(40, fs0));
    S.pfs = Math.max(14, Math.min(30, LS.get('pfs', 17)));
    applyFs(); applyPfs();

    var zb = $('#btnZh');
    if (zb) { zb.textContent = S.zh ? '开' : '关'; zb.classList.toggle('on', S.zh); }
    var fo = $('#btnFollow');
    if (fo) { fo.textContent = S.follow ? '开' : '关'; fo.classList.toggle('on', S.follow); }
    var vl = $('#verLabel');
    if (vl) vl.textContent = APP_VER;

    /* APK 里已经在 App 里了 → 「下载 Android App」没意义（点了会跳 404） */
    if (isNative) {
      var apkRow = $('#btnApk');
      if (apkRow && apkRow.parentElement) apkRow.parentElement.style.display = 'none';
      var apk2 = $('#btnApk2');
      if (apk2) { apk2.textContent = '已是最新版本'; apk2.disabled = true; apk2.style.opacity = '.55'; }
    }

    bind();

    loadIndex().then(function () {
      if (!S.eps.length) { toast('集数索引读不出来'); return; }
      var last = LS.get('ep', null);
      var ep = null;
      for (var i = 0; i < S.eps.length; i++) if (S.eps[i].tag === last) ep = S.eps[i];
      if (!ep) ep = S.eps[0];
      return loadCues(ep).then(function (o) {
        S.lines = flatten(o.cues || []);
        loadEp(ep, 0);
        renderEpList();
        refreshCache();
        refreshTools();
        /* 词库后台预热（几百 KB，不占首屏；等首屏画完再开始） */
        setTimeout(ensureWordData, 600);
      });
    }).catch(function (e) {
      toast('数据加载失败：' + (e && e.message ? e.message : e));
    });

    if (webCacheOk() && !isNative) {
      refreshWebCache().then(function () { refreshTools(); refreshCache(); });
    }

    /* Service Worker：外壳离线 + 音频缓存放行（APK 里不用，页面由本机代理伺服） */
    if (!isNative && 'serviceWorker' in navigator && location.protocol !== 'file:') {
      window.addEventListener('load', function () {
        try { navigator.serviceWorker.register('sw.js?v=' + APP_VER).catch(function () { }); }
        catch (e) { }
      });
    }

    /* 位置回传 → 高亮当前句 */
    tickCb = function (d) {
      updateProgress();
      if (!S.lines.length) return;
      var i = binarySearch(d.pos);
      if (i >= 0) setIdx(i, true);
    };
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
