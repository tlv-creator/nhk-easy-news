#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
独立核对「mp3 ↔ 书」的映射（不靠同事的结论）

两条独立证据：
  ① 时长证据：每条轨的实测时长 == manifest 的 dur_parts（已在 fetch_jgr_asr.py --stage build 跑过）
  ② **内容证据**：我自己 ASR 出来的每本书开头 ~45 秒 vs manifest 里同事记的 audio_head_asr
     ⇒ 字符覆盖率 ≥ 0.5 ⇒ 认对了；低 ⇒ 配错书了

这条比「文件名像不像」硬得多：文件名全是 001/No_002/Track_01。
"""
import json, os, sys
from difflib import SequenceMatcher

ROOT = "/workspace/work/tadoku"
JGR = f"{ROOT}/jgr"
sys.path.insert(0, ROOT)
from align_audio import norm


def cover(a, b):
    if not a:
        return 0.0
    m = SequenceMatcher(None, a, b, autojunk=False)
    return sum(bl.size for bl in m.get_matching_blocks()) / len(a)


def main():
    ms = json.load(open(f"{JGR}/books56/manifest.json"))
    rows = []
    for b in ms:
        tag = b["tag"]
        tp = f"{JGR}/asr_truth/{tag}.json"
        if not os.path.exists(tp):
            print(f"  ⏭ {tag}（ASR 真值还没出来）")
            continue
        truth = json.load(open(tp))
        head = "".join(l["text"] for l in truth if l["start"] < 50)
        peer = b.get("audio_head_asr") or ""
        c = cover(norm(peer), norm(head))
        rows.append((tag, b.get("official_title"), c, len(truth)))
        flag = "✅" if c >= 0.5 else ("🟡" if c >= 0.3 else "❌")
        print(f"  {flag} {tag[:44]:46} 覆盖 {c:.2f}  官方题《{b.get('official_title')}》"
              f"  ASR行 {len(truth)}")
    ok = sum(1 for r in rows if r[2] >= 0.5)
    print(f"\n内容证据通过 {ok}/{len(rows)}（≥0.5）")
    # 交叉核对：有没有两本书的 ASR 头一样（= 认重了就说明映射有重复）
    heads = {}
    for b in ms:
        tp = f"{JGR}/asr_truth/{b['tag']}.json"
        if os.path.exists(tp):
            h = norm("".join(l["text"] for l in json.load(open(tp)) if l["start"] < 50))
            heads.setdefault(h[:60], []).append(b["tag"])
    dup = {k: v for k, v in heads.items() if len(v) > 1}
    if dup:
        print("❌ 有书认到同一段音频：")
        for k, v in dup.items():
            print("   ", v)
        sys.exit(1)
    print("✅ 没有两本书认到同一段音频（映射互斥）")


if __name__ == "__main__":
    main()
