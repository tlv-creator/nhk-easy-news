#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
第 1 批官方朗読：**独立回验**（不看对齐器的中间产物，只看最终结果）

做法：拿重建后的时间轴，从**原始 mp3** 里切出这一句 → 平台 ASR → 跟字幕文字比字符覆盖率
     ⇒ 覆盖率 ≥ 0.5 就算「这句在音频里确实是对的那句」
同时切一次**同事给的旧时间轴**（books56/books/<tag>.json 里的 s/e）做对照
     ⇒ 新旧对比才能说明「对齐有没有真的改好」，光看新的是多少不算证据

🔴 跨轨书的绝对时间 → (轨, 轨内时间) 换算：按 units.json 的 tracks[].offset/dur
"""
import json, os, subprocess, sys
from concurrent.futures import ThreadPoolExecutor

ROOT = "/workspace/work/tadoku"
JGR = f"{ROOT}/jgr"
sys.path.insert(0, ROOT)
from align_audio import norm

PROMPT = ("严格逐字转写这段日语音频的内容：保留原有标点；不要添加原文没有的词，不要翻译、不要概括；"
          "每句前标【秒】=该句在本段里的起始秒数（本段开头为 0）。")


def sh(cmd, timeout=900):
    return subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=timeout).stdout


def cover(a, b):
    from difflib import SequenceMatcher
    if not a:
        return 0.0
    m = SequenceMatcher(None, a, b, autojunk=False)
    return sum(bl.size for bl in m.get_matching_blocks()) / len(a)


def locate(tracks, t):
    """绝对秒 → (轨路径, 轨内秒)"""
    for tr in tracks:
        if tr["offset"] - 0.01 <= t < tr["offset"] + tr["dur"]:
            return tr["path"], t - tr["offset"]
    tr = tracks[-1]
    return tr["path"], max(0.0, t - tr["offset"])


def cut(src, start, dur, out):
    subprocess.run(["ffmpeg", "-v", "error", "-ss", f"{max(0, start):.2f}", "-t", f"{dur:.2f}",
                    "-i", src, "-c:a", "libmp3lame", "-b:a", "64k", "-ar", "22050", "-ac", "1",
                    out, "-y"], capture_output=True)
    return out


def asr(path):
    r = subprocess.run(["mcode-tools", "upload_temp_url", path], capture_output=True,
                       text=True, timeout=900)
    try:
        url = json.loads(r.stdout)["temp_url"]
    except Exception as e:
        return ""
    args = {"audio_info": [{"url": url, "mime_type": "audio/mpeg", "prompt": PROMPT}]}
    ap = path + ".args.json"
    json.dump(args, open(ap, "w"), ensure_ascii=False)
    r = subprocess.run(["mcode-tools", "connector", "call", "connector__matrix__audios_understand",
                        "--args-file", ap], capture_output=True, text=True, timeout=1200)
    try:
        d = json.loads(r.stdout)
    except Exception:
        return ""
    return (d.get("results") or [{}])[0].get("description", "") or ""


def main():
    units = {u["tag"]: u for u in json.load(open(f"{JGR}/units.json"))}
    picks = int(os.environ.get("PICKS", "4"))
    outdir = f"{JGR}/verify"
    os.makedirs(outdir, exist_ok=True)
    jobs = []
    for tag, u in units.items():
        ap_ = f"{JGR}/out/{tag}.json"
        bp = f"{JGR}/books56/books/{tag}.json"
        if not (os.path.exists(ap_) and os.path.exists(bp)):
            print(f"  ⏭ {tag}（还没重建）")
            continue
        new = json.load(open(ap_))
        old = json.load(open(bp))
        oldc = {i: c for i, c in enumerate(old["cues"])}
        live = [(i, c) for i, c in enumerate(new["cues"]) if not c.get("no_audio")]
        live = [x for x in live if (x[1]["e"] - x[1]["s"]) > 1.0]
        if not live:
            continue
        step = max(1, len(live) // picks)
        for i, c in live[::step][:picks]:
            jobs.append((tag, i, c, oldc.get(i, {})))
    print(f"抽样 {len(jobs)} 句（每句切两次：新时间轴 vs 同事给的旧时间轴）")

    results = []

    def one(job):
        tag, i, c, oc = job
        tracks = units[tag]["tracks"]
        dur = max(1.2, c["e"] - c["s"] + 0.8)
        src, loc = locate(tracks, c["s"] - 0.4)
        newf = f"{outdir}/{tag}_{i}_new.mp3"
        cut(src, loc, dur, newf)
        txt = "".join(r.get("t", "") for r in c["rows"])
        n_new = cover(norm(txt), norm(asr(newf)))
        n_old = None
        if oc and oc.get("s") is not None and abs(oc.get("s", 0) - c["s"]) > 1.5:
            osrc, oloc = locate(tracks, oc["s"] - 0.4)
            oldf = f"{outdir}/{tag}_{i}_old.mp3"
            cut(osrc, oloc, dur, oldf)
            n_old = cover(norm(txt), norm(asr(oldf)))
        return {"tag": tag, "i": i, "text": txt, "new_cov": round(n_new, 3),
                "old_cov": round(n_old, 3) if n_old is not None else None,
                "new_s": c["s"], "old_s": oc.get("s")}

    with ThreadPoolExecutor(3) as ex:
        for r in ex.map(one, jobs):
            results.append(r)
            print(f"  {r['tag'][:40]:42} #{r['i']:4} 新={r['new_cov']:.2f} "
                  f"旧={r['old_cov'] if r['old_cov'] is not None else '  - '} | {r['text'][:32]}",
                  flush=True)
    json.dump(results, open(f"{JGR}/verify_report.json", "w"), ensure_ascii=False)
    ok = sum(1 for r in results if r["new_cov"] >= 0.5)
    olds = [r for r in results if r["old_cov"] is not None]
    ok_old = sum(1 for r in olds if r["old_cov"] >= 0.5)
    print(f"\n新时间轴对得上：{ok}/{len(results)}")
    if olds:
        print(f"旧时间轴对得上：{ok_old}/{len(olds)}")
    # 反向验证：把判据反过来（<0.5 算过）必须不成立
    print(f"反向验证：若判据写反则 {len(results)-ok}/{len(results)} 会被误判为通过 ⇒ 判据有效"
          if ok < len(results) else "⚠️ 全过，反向验证无区分力")


if __name__ == "__main__":
    main()
