#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
日语泛读：书面句子 ↔ 音频真值的**字符流全局对齐**，重算时间轴。

为什么不用「按序号硬配」：
  ASR 切句粒度 ≠ 书面切句粒度（一句被拆成 3 行，一行也可能含 2 句）⇒ 序号对不上。
为什么不用「整句相似度」：
  朗読版与教材书面版用词不同（和尚/おしょうさん、家/うち、皮/顔）⇒ ratio 被拉低 ⇒ 误判成没对上。
为什么不用「滑动窗口 + 停顿分段」：
  ASR 会在一句话中间换行（【9】1394年、/【12】京都に/【13】一人…）⇒ 按停顿分段会把一句切碎 ⇒ 匹配散掉。

本器口径（实测校准过）：
  覆盖率 = 字符级**最长公共子串匹配块**总长 / 书面句长度
  ⇒ 「おしょうさんの大切な茶碗を割りました」vs「和尚様の大切な茶碗を割りました」
     匹配块 =「の大切な茶碗を割りました」⇒ 覆盖 ≈ 0.6 ⇒ 判「有对应」✅
  ⇒ 「一休さんは、とても頭のいいお坊さんです。」vs「一休さん」⇒ 0.22 ⇒ 判「无对应」✅（音频开头是书名页）
  ⇒ 「一休さんはどうするのでしょうか。」vs「一休さんはどんなことをしたり…」⇒ 0.00 ⇒ 真·无对应 ✅

时间轴来源：**音频真值**（平台 ASR 逐段转写的时间戳），不是原来的估算值。
"""
import json, os, re, sys, unicodedata
from difflib import SequenceMatcher

ROOT = "/workspace/work/tadoku"
TRUTH_DIR = f"{ROOT}/asr_truth"
COV_THRESHOLD = 0.50

# ---------- 归一化（只用于比较，不改数据）----------
CN_NUM = {"一": "1", "二": "2", "三": "3", "四": "4", "五": "5", "六": "6", "七": "7",
           "八": "8", "九": "9"}


def cn2num(s):
    def repl(m):
        t = m.group(0)
        if all(c in CN_NUM for c in t):
            if len(t) == 1:
                return CN_NUM[t]
            if "十" in t:
                a, _, b = t.partition("十")
                return str(int(CN_NUM.get(a, 1)) * 10 + (int(CN_NUM[b]) if b else 0))
            return t
        return t
    return re.sub(r"[一二三四五六七八九十]+", repl, s)


PUNCT = set("、。「」『』（）()【】［］〈〉<>〔〕・…―－ー～〜!\"#$%&'’‘“”，,.:;?/\\|＝=＋+-×・　 ")


def norm(s):
    s = unicodedata.normalize("NFKC", s or "")
    s = cn2num(s)
    s = "".join(c for c in s if c not in PUNCT)
    return s


KANA_RE = re.compile(r"[ぁ-ゖァ-ヺー]")

# 汉字/数字/字母（去掉假名后剩下的「骨架」）
def skeleton(s):
    """只留汉字/数字/英文字母（去掉假名与标点）
    用途：别册非虚构类书的 OCR 把振假名并进了正文（「これは、むかし昔」）
        ⇒ 整句比对会因为多了注音假名而对不上 ⇒ 误判成哑句
        ⇒ 汉字骨架比对不受影响（假名被去掉了）
    """
    return "".join(c for c in s if not KANA_RE.match(c))


def align(book_cues, asr_lines, dur, transform=None):
    """
    返回 (new_cues, info)
      new_cues[i].s/e   = 音频里的真实时间（秒）
      new_cues[i].no_audio = 1 ⇒ 这句在音频里没有对应
      new_cues[i].cov   = 覆盖率
      new_cues[i]._n    = 本次比对用的字符数（合并双通道时要用）
    transform: 归一化函数，默认 norm；传 skeleton_norm 则走「只比汉字」通道
    """
    tr = transform or norm
    # ---- A：书面字符流（记每句区间）----
    A, a_len = [], []
    for ci, c in enumerate(book_cues):
        t = "".join(r.get("t", "") for r in c.get("rows", []))
        n = tr(t)
        a_len.append(len(n))
        for ch in n:
            A.append((ch, ci))

    # ---- B：ASR 字符流（记每行区间 + 每行起点秒）----
    B, b_len, b_start = [], [], []
    for li, l in enumerate(asr_lines):
        n = tr(l["text"])
        b_len.append(len(n))
        b_start.append(l["start"])
        for ch in n:
            B.append((ch, li))

    cov = [0] * len(book_cues)
    first_b = [None] * len(book_cues)   # 该句首个匹配字符在 B 中的位置
    last_b = [None] * len(book_cues)

    if A and B:
        sa = "".join(x[0] for x in A)
        sb = "".join(x[0] for x in B)
        sm = SequenceMatcher(None, sa, sb, autojunk=False)
        for bi, bj, n in sm.get_matching_blocks():
            if n == 0:
                continue
            for k in range(bi, bi + n):
                ci = A[k][1]
                cov[ci] += 1
                bpos = bj + (k - bi)          # A 的第 k 个字符 ↔ B 的第 bj+(k-bi) 个字符
                if first_b[ci] is None:
                    first_b[ci] = bpos
                last_b[ci] = bpos

    # ---- B 位置 → 时间 ----
    # 行内比例 → 起点 + frac×(下一行起点 - 本行起点)
    line_end_time = []
    for li in range(len(b_start)):
        nxt = b_start[li + 1] if li + 1 < len(b_start) else (dur or (b_start[li] + 2))
        line_end_time.append(nxt)

    def bpos2time(pos):
        if pos is None or not B:
            return None
        li = B[pos][1]
        if b_len[li] <= 0:
            return b_start[li]
        # 该行内第几个字符
        # 找该行首字符在 B 中的位置
        lo = 0
        # 线性扫（B 不大，缓存）
        return b_start[li], li

    # 预先算每个行首字符在 B 中的索引
    line_first_idx = {}
    for idx, (ch, li) in enumerate(B):
        if li not in line_first_idx:
            line_first_idx[li] = idx

    def pos2time(pos):
        if pos is None or not B:
            return None
        li = B[pos][1]
        first = line_first_idx[li]
        frac = (pos - first) / max(1, b_len[li])
        span = max(0.1, line_end_time[li] - b_start[li])
        return b_start[li] + frac * span

    # ---- 输出 ----
    out = []
    prev_end = 0.0
    for i, cue in enumerate(book_cues):
        rec = dict(cue)
        L = max(1, a_len[i])
        c = cov[i] / L
        rec["cov"] = round(c, 3)
        rec["_n"] = a_len[i]
        if c >= COV_THRESHOLD and first_b[i] is not None:
            s = pos2time(first_b[i])
            e = pos2time(last_b[i])
            if s is None:
                s = cue.get("s", 0)
            if e is None or e <= s:
                e = s + max(0.4, (e or s) - s + 0.4)
            rec["s"] = round(s, 2)
            rec["e"] = round(e, 2)
            rec["no_audio"] = 0
            prev_end = rec["e"]
        else:
            rec["no_audio"] = 1
        out.append(rec)
    return out


def skeleton_norm(s):
    return skeleton(norm(s))


def align_dual(book_cues, asr_lines, dur):
    """
    **双通道比对**：整句比对 vs 只比汉字骨架，取覆盖更高者。

    为什么需要：别册非虚构类书的 OCR 把振假名并进了正文
    （「これは、むかし昔」里的「むかし」是「昔」的注音）
    ⇒ 整句比对会因为多出来的注音假名而覆盖率不足 ⇒ **整句明明在音频里，却被判成哑句**
    ⇒ 汉字骨架通道（去掉所有假名）不受注音污染影响

    🔴 不用「删掉被并进来的假名」的做法：
       真例（むかし+昔）和误伤（喜んで+出(で)，「で」是「喜」的送り仮名）
       在 ru 结构上**完全无法区分** ⇒ 改用户正文的风险不可接受
    ⇒ 改成「两个假设各算一遍覆盖率，让音频来裁决哪个对」

    汉字骨架太短（<3 字）时不采信 ⇒ 避免短句靠巧合得高分
    """
    full = align(book_cues, asr_lines, dur)
    skel = align(book_cues, asr_lines, dur, transform=skeleton_norm)
    out = []
    for f, s in zip(full, skel):
        pick, ch = f, "full"
        if s.get("_n", 0) >= 3 and s["cov"] > f["cov"]:
            pick, ch = s, "skel"
        rec = dict(pick)
        rec["_ch"] = ch
        out.append(rec)
    return out


def main():
    """
    参数化（默认参数 = 旧 34 本的路径 ⇒ 旧流程可直接回归验证）
      --books-dir / --truth-dir / --out-dir / --report
      --tags   逗号分隔的 tag 列表；不给就按 books 目录里所有同名文件
    """
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--books-dir", default=f"{ROOT}/books")
    ap.add_argument("--truth-dir", default=TRUTH_DIR)
    ap.add_argument("--out-dir", default=f"{ROOT}/aligned")
    ap.add_argument("--report", default=f"{ROOT}/align_report.json")
    ap.add_argument("--tags", default="")
    ap.add_argument("--dual", action="store_true",
                    help="双通道比对（整句 + 汉字骨架）⇒ 用于正文被并了振假名的书")
    a = ap.parse_args()

    os.makedirs(a.out_dir, exist_ok=True)
    if a.tags:
        tags = [t.strip() for t in a.tags.split(",") if t.strip()]
    else:
        tags = sorted(os.path.splitext(f)[0] for f in os.listdir(a.books_dir) if f.endswith(".json"))
    report = []
    for tag in tags:
        tp = f"{a.truth_dir}/{tag}.json"
        bp = f"{a.books_dir}/{tag}.json"
        if not os.path.exists(tp) or not os.path.exists(bp):
            print(f"  ⏭ {tag}（缺 ASR 真值或书文件）")
            continue
        truth = json.load(open(tp))
        book = json.load(open(bp))
        dur = book.get("dur") or 0
        new = align_dual(book["cues"], truth, dur) if a.dual else align(book["cues"], truth, dur)
        json.dump({"tag": tag, "dur": dur, "cues": new},
                  open(f"{a.out_dir}/{tag}.json", "w"), ensure_ascii=False)
        na = sum(1 for c in new if c.get("no_audio"))
        covs = [c.get("cov", 0) for c in new]
        nskel = sum(1 for c in new if c.get("_ch") == "skel")
        report.append({"tag": tag, "title": book.get("title"), "level": book.get("level"),
                       "cues": len(new), "no_audio": na, "n_skel": nskel,
                       "avg_cov": round(sum(covs) / max(1, len(covs)), 3),
                       "min_cov": round(min(covs), 3) if covs else 0,
                       "asr_lines": len(truth)})
        print(f"  {tag:44} {len(new):4}句  无对应 {na:3}  平均覆盖 {report[-1]['avg_cov']}")
    json.dump(report, open(a.report, "w"), ensure_ascii=False)
    tot = sum(r["cues"] for r in report)
    na = sum(r["no_audio"] for r in report)
    print(f"共 {len(report)} 本 / {tot} 句 / 无对应 {na} 句 ({na/max(1,tot)*100:.1f}%)")


if __name__ == "__main__":
    main()
