#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
日语泛读：书面句子 ↔ 音频真值的**字符流全局对齐**，重算时间轴。

为什么不用「按序号硬配」：
  ASR 切句粒度 ≠ 书面切句粒度（一句被拆成 3 行，一行也可能含 2 句）⇒ 序号对不上。
为什么不用「整句相似度」：
  朗読版与教材书面版用词不同（和尚/おしょうさん、家/うち、皮/顔）⇒ ratio 被拉低 ⇒ 误判成没对上。
为什么不用「滑动窗口 + 停顿分段」：
  ASR 会在一句话中间换行（【9】1394年、/【12】京都に/【13】一人…）⇒ 按停顿分段会把一句切碎 ⇒ 匹配散掉。

本器口径（实测校准过）：
  覆盖率 = 字符级**最长公共子串匹配块**总长 / 书面句长度
  ⇒ 「おしょうさんの大切な茶碗を割りました」vs「和尚様の大切な茶碗を割りました」
     匹配块 =「の大切な茶碗を割りました」⇒ 覆盖 ≈ 0.6 ⇒ 判「有对应」✅
  ⇒ 「一休さんは、とても頭のいいお坊さんです。」vs「一休さん」⇒ 0.22 ⇒ 判「无对应」✅（音频开头是书名页）
  ⇒ 「一休さんはどうするのでしょうか。」vs「一休さんはどんなことをしたり…」⇒ 0.00 ⇒ 真·无对应 ✅

时间轴来源：**音频真值**（平台 ASR 逐段转写的时间戳），不是原来的估算值。
"""
import json, os, re, sys, unicodedata
from difflib import SequenceMatcher

ROOT = "/workspace/work/tadoku"
TRUTH_DIR = f"{ROOT}/asr_truth"
COV_THRESHOLD = 0.50

# ---------- 归一化（只用于比较，不改数据）----------
CN_NUM = {"一": "1", "二": "2", "三": "3", "四": "4", "五": "5", "六": "6", "七": "7",
           "八": "8", "九": "9"}


def cn2num(s):
    def repl(m):
        t = m.group(0)
        if all(c in CN_NUM for c in t):
            if len(t) == 1:
                return CN_NUM[t]
            if "十" in t:
                a, _, b = t.partition("十")
                return str(int(CN_NUM.get(a, 1)) * 10 + (int(CN_NUM[b]) if b else 0))
            return t
        return t
    return re.sub(r"[一二三四五六七八九十]+", repl, s)


PUNCT = set("、。「」『』（）()【】［］〈〉<>〔〕・…―－ー～〜!\"#$%&'’‘“”，,.:;?/\\|＝=＋+-×・　 ")


def norm(s):
    s = unicodedata.normalize("NFKC", s or "")
    s = cn2num(s)
    s = "".join(c for c in s if c not in PUNCT)
    return s


def align(book_cues, asr_lines, dur):
    """
    返回 (new_cues, info)
      new_cues[i].s/e   = 音频里的真实时间（秒）
      new_cues[i].no_audio = 1 ⇒ 这句在音频里没有对应
      new_cues[i].cov   = 覆盖率
    """
    # ---- A：书面字符流（记每句区间）----
    A, a_len = [], []
    for ci, c in enumerate(book_cues):
        t = "".join(r.get("t", "") for r in c.get("rows", []))
        n = norm(t)
        a_len.append(len(n))
        for ch in n:
            A.append((ch, ci))

    # ---- B：ASR 字符流（记每行区间 + 每行起点秒）----
    B, b_len, b_start = [], [], []
    for li, l in enumerate(asr_lines):
        n = norm(l["text"])
        b_len.append(len(n))
        b_start.append(l["start"])
        for ch in n:
            B.append((ch, li))

    cov = [0] * len(book_cues)
    first_b = [None] * len(book_cues)   # 该句首个匹配字符在 B 中的位置
    last_b = [None] * len(book_cues)

    if A and B:
        sa = "".join(x[0] for x in A)
        sb = "".join(x[0] for x in B)
        sm = SequenceMatcher(None, sa, sb, autojunk=False)
        for bi, bj, n in sm.get_matching_blocks():
            if n == 0:
                continue
            for k in range(bi, bi + n):
                ci = A[k][1]
                cov[ci] += 1
                bpos = bj + (k - bi)          # A 的第 k 个字符 ↔ B 的第 bj+(k-bi) 个字符
                if first_b[ci] is None:
                    first_b[ci] = bpos
                last_b[ci] = bpos

    # ---- B 位置 → 时间 ----
    # 行内比例 → 起点 + frac×(下一行起点 - 本行起点)
    line_end_time = []
    for li in range(len(b_start)):
        nxt = b_start[li + 1] if li + 1 < len(b_start) else (dur or (b_start[li] + 2))
        line_end_time.append(nxt)

    def bpos2time(pos):
        if pos is None or not B:
            return None
        li = B[pos][1]
        if b_len[li] <= 0:
            return b_start[li]
        # 该行内第几个字符
        # 找该行首字符在 B 中的位置
        lo = 0
        # 线性扫（B 不大，缓存）
        return b_start[li], li

    # 预先算每个行首字符在 B 中的索引
    line_first_idx = {}
    for idx, (ch, li) in enumerate(B):
        if li not in line_first_idx:
            line_first_idx[li] = idx

    def pos2time(pos):
        if pos is None or not B:
            return None
        li = B[pos][1]
        first = line_first_idx[li]
        frac = (pos - first) / max(1, b_len[li])
        span = max(0.1, line_end_time[li] - b_start[li])
        return b_start[li] + frac * span

    # ---- 输出 ----
    out = []
    prev_end = 0.0
    for i, cue in enumerate(book_cues):
        rec = dict(cue)
        L = max(1, a_len[i])
        c = cov[i] / L
        rec["cov"] = round(c, 3)
        if c >= COV_THRESHOLD and first_b[i] is not None:
            s = pos2time(first_b[i])
            e = pos2time(last_b[i])
            if s is None:
                s = cue.get("s", 0)
            if e is None or e <= s:
                e = s + max(0.4, (e or s) - s + 0.4)
            rec["s"] = round(s, 2)
            rec["e"] = round(e, 2)
            rec["no_audio"] = 0
            prev_end = rec["e"]
        else:
            rec["no_audio"] = 1
        out.append(rec)
    return out


def main():
    idx = json.load(open(f"{ROOT}/index.json"))["episodes"]
    books = [e for e in idx if e.get("has_audio")]
    os.makedirs(f"{ROOT}/aligned", exist_ok=True)
    report = []
    for e in books:
        tag = e["tag"]
        tp = f"{TRUTH_DIR}/{tag}.json"
        bp = f"{ROOT}/books/{tag}.json"
        if not os.path.exists(tp) or not os.path.exists(bp):
            print(f"  ⏭ {tag}（缺 ASR 真值）")
            continue
        truth = json.load(open(tp))
        book = json.load(open(bp))
        dur = book.get("dur") or e.get("dur") or 0
        new = align(book["cues"], truth, dur)
        json.dump({"tag": tag, "dur": dur, "cues": new},
                  open(f"{ROOT}/aligned/{tag}.json", "w"), ensure_ascii=False)
        na = sum(1 for c in new if c.get("no_audio"))
        covs = [c.get("cov", 0) for c in new]
        report.append({"tag": tag, "title": e.get("title"), "cues": len(new), "no_audio": na,
                       "avg_cov": round(sum(covs) / max(1, len(covs)), 3),
                       "asr_lines": len(truth)})
        print(f"  {tag:36} {len(new):4}句  无对应 {na:3}  平均覆盖 {report[-1]['avg_cov']}")
    json.dump(report, open(f"{ROOT}/align_report.json", "w"), ensure_ascii=False)


if __name__ == "__main__":
    main()
