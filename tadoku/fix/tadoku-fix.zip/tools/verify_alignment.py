#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
独立回验：用**重建后的时间轴**切音频 → 平台 ASR → 跟字幕文字比。
并与**旧时间轴**做对照（同一句在旧时间点切，看看念的是不是这句）。

判据：某句在新时间点切出来，ASR 文本与该句文字的字符覆盖率 ≥ 0.5 ⇒ 对上了。
"""
import json, os, subprocess, sys
from concurrent.futures import ThreadPoolExecutor

ROOT = "/workspace/work/tadoku"
sys.path.insert(0, ROOT)
from align_audio import norm

PROMPT = ("严格逐字转写这段日语音频的内容：保留原有标点；不要添加原文没有的词，不要翻译、不要概括；"
          "每句前标【秒】=该句在本段里的起始秒数（本段开头为 0）。")


def cut(src, start, dur, out):
    subprocess.run(["ffmpeg", "-v", "error", "-ss", f"{max(0,start):.2f}", "-t", f"{dur:.2f}",
                    "-i", src, "-c:a", "libmp3lame", "-b:a", "64k", "-ar", "22050", "-ac", "1", out, "-y"],
                   capture_output=True)
    return out


def asr(path):
    r = subprocess.run(["mcode-tools", "upload_temp_url", path], capture_output=True, text=True, timeout=600)
    url = json.loads(r.stdout)["temp_url"]
    args = {"audio_info": [{"url": url, "mime_type": "audio/mpeg", "prompt": PROMPT}]}
    ap = path + ".args.json"
    json.dump(args, open(ap, "w"), ensure_ascii=False)
    r = subprocess.run(["mcode-tools", "connector", "call", "connector__matrix__audios_understand",
                        "--args-file", ap], capture_output=True, text=True, timeout=900)
    d = json.loads(r.stdout)
    return d["results"][0].get("description", "") or ""


def cover(a, b):
    from difflib import SequenceMatcher
    if not a:
        return 0.0
    m = SequenceMatcher(None, a, b, autojunk=False)
    return sum(bl.size for bl in m.get_matching_blocks()) / len(a)


def main():
    books = sys.argv[1:] or ["tadoku-l2-ikkyu", "tadoku-l2-momotaro", "level1-sushi", "level1-urashima-taro"]
    picks = 3
    jobs = []
    for tag in books:
        new = json.load(open(f"{ROOT}/out/{tag}.json"))
        old = json.load(open(f"{ROOT}/books/{tag}.json"))
        oldc = {i: c for i, c in enumerate(old["cues"])}
        live = [(i, c) for i, c in enumerate(new["cues"]) if not c.get("no_audio")]
        # 均匀取样 + 跳过太短的
        live = [x for x in live if (x[1]["e"] - x[1]["s"]) > 0.8]
        step = max(1, len(live) // picks)
        for i, c in live[::step][:picks]:
            oc = oldc.get(i, {})
            jobs.append((tag, i, c, oc))
    print(f"抽样 {len(jobs)} 句（每句切两次：新时间轴 vs 旧时间轴）")

    os.makedirs(f"{ROOT}/verify", exist_ok=True)
    results = []

    def one(job):
        tag, i, c, oc = job
        src = f"{ROOT}/audio/{tag}.mp3"
        dur = max(1.2, c["e"] - c["s"] + 0.8)
        newf = f"{ROOT}/verify/{tag}_{i}_new.mp3"
        cut(src, c["s"] - 0.4, dur, newf)
        txt = "".join(r.get("t", "") for r in c["rows"])
        n_new = cover(norm(txt), norm(asr(newf)))
        n_old = None
        if oc and oc.get("s") is not None and abs(oc.get("s", 0) - c["s"]) > 1.5:
            oldf = f"{ROOT}/verify/{tag}_{i}_old.mp3"
            cut(src, oc["s"] - 0.4, dur, oldf)
            n_old = cover(norm(txt), norm(asr(oldf)))
        return {"tag": tag, "i": i, "text": txt, "new_cov": round(n_new, 3),
                "old_cov": round(n_old, 3) if n_old is not None else None,
                "new_s": c["s"], "old_s": oc.get("s")}

    with ThreadPoolExecutor(3) as ex:
        for r in ex.map(one, jobs):
            results.append(r)
            print(f"  {r['tag']:26} #{r['i']:4} 新={r['new_cov']:.2f} "
                  f"旧={r['old_cov'] if r['old_cov'] is not None else '  - '} | {r['text'][:40]}")
    json.dump(results, open(f"{ROOT}/verify_report.json", "w"), ensure_ascii=False)
    ok = sum(1 for r in results if r["new_cov"] >= 0.5)
    olds = [r for r in results if r["old_cov"] is not None]
    ok_old = sum(1 for r in olds if r["old_cov"] >= 0.5)
    print(f"\n新时间轴对得上：{ok}/{len(results)}")
    if olds:
        print(f"旧时间轴对得上：{ok_old}/{len(olds)}")


if __name__ == "__main__":
    main()
