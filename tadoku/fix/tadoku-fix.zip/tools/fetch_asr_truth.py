#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
日语泛读：批量 ASR 真值抓取（0 额度通道，平台 audios_understand）

为什么按 40 秒切段：
  整本一次喂给平台能拿到全文，但**平台返回的时间戳会随音频变长而漂移**
  （实测 848 秒的书，末尾报 1029 秒 ⇒ 整本版不可信）
  ⇒ 改成 40 秒一段，自己控制每段起点 ⇒ 段内时间戳 + 已知起点 = 绝对时间（可信）
  ⇒ 段边界被切断的句子，由下一段开头自然接上（对齐时按字符级合并）

用法：
  python3 fetch_asr_truth.py --stage download   # 下载 34 本音频
  python3 fetch_asr_truth.py --stage cut        # 切 40 秒段
  python3 fetch_asr_truth.py --stage upload    # 上传所有段拿 temp_url
  python3 fetch_asr_truth.py --stage asr        # 调平台 ASR（每 call 10 段）
  python3 fetch_asr_truth.py --stage parse      # 解析成 asr_truth/<tag>.json
"""
import json, os, re, subprocess, sys, time
from concurrent.futures import ThreadPoolExecutor

ROOT = "/workspace/work/tadoku"
AUDIO_DIR = f"{ROOT}/audio"
CLIP_DIR = f"{ROOT}/clips"
URL_DIR = f"{ROOT}/urls"
TRUTH_DIR = f"{ROOT}/asr_truth"
SITES = ["https://qgozaeqvjc9l9.space.mcode.cn/media",
         "https://0rbbjfw36hj66.space.mcode.cn/media"]
CHUNK = 40          # 秒
BASE = "https://0rbbjfw36hj66.space.mcode.cn"

PROMPT = ("这是一本日语有声读物。**严格逐字转写**这段音频的日文内容："
          "①保留原有标点；②不要添加原文没有的词，不要翻译、不要概括、不要补全；"
          "③听不清用 □；④按听到顺序逐句输出，每句前标【秒】=该句在这段音频里的起始秒数"
          "（整数，本段开头为 0）。")


def sh(cmd, timeout=600):
    return subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=timeout).stdout


def books():
    """线上有音频的书（绕开前端，直接拉数据）"""
    idx = json.load(open(f"{ROOT}/index.json"))["episodes"]
    return [e for e in idx if e.get("has_audio")]


def stage_download():
    os.makedirs(AUDIO_DIR, exist_ok=True)
    bs = books()
    print(f"要下载 {len(bs)} 本")

    def one(e):
        tag = e["tag"]
        dst = f"{AUDIO_DIR}/{tag}.mp3"
        if os.path.exists(dst) and os.path.getsize(dst) > 10000:
            return tag, "skip", os.path.getsize(dst)
        for site in SITES:
            r = subprocess.run(["curl", "-s", "--max-time", "300", "-o", dst, f"{site}/{tag}.mp3"],
                               capture_output=True)
            if os.path.exists(dst) and os.path.getsize(dst) > 10000:
                return tag, "ok", os.path.getsize(dst)
        return tag, "FAIL", 0

    with ThreadPoolExecutor(8) as ex:
        for tag, st, sz in ex.map(one, bs):
            print(f"  {tag:36} {st} {sz/1e6:.1f}MB", flush=True)


def stage_cut():
    os.makedirs(CLIP_DIR, exist_ok=True)
    bs = books()
    total = 0
    for e in bs:
        tag = e["tag"]
        src = f"{AUDIO_DIR}/{tag}.mp3"
        if not os.path.exists(src):
            print(f"  ❌ 缺音频 {tag}")
            continue
        out = f"{CLIP_DIR}/{tag}"
        os.makedirs(out, exist_ok=True)
        dur = float(sh(f'ffprobe -v error -show_entries format=duration -of csv=p=0 "{src}"') or 0)
        n = 0
        i = 0
        while i < dur:
            f = f"{out}/{i:06d}.mp3"
            if not os.path.exists(f):
                sh(f'ffmpeg -v error -ss {i} -t {CHUNK} -i "{src}" -c:a libmp3lame -b:a 48k '
                   f'-ar 22050 -ac 1 "{f}" -y')
            n += 1
            i += CHUNK
            total += 1
        print(f"  {tag:36} dur={dur:8.1f}s → {n} 段", flush=True)
    print(f"总段数 {total}")


def stage_upload():
    os.makedirs(URL_DIR, exist_ok=True)
    clips = []
    for d in sorted(os.listdir(CLIP_DIR)):
        cd = f"{CLIP_DIR}/{d}"
        if not os.path.isdir(cd):
            continue
        for f in sorted(os.listdir(cd)):
            if f.endswith(".mp3"):
                clips.append((d, f, f"{cd}/{f}"))
    print(f"待上传 {len(clips)} 段")

    def one(item):
        tag, f, path = item
        dst = f"{URL_DIR}/{tag}/{f}.url"
        if os.path.exists(dst):
            return tag, f, "skip"
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        out = sh(f'mcode-tools upload_temp_url "{path}"', 600)
        try:
            u = json.loads(out)["temp_url"]
        except Exception:
            return tag, f, "FAIL"
        open(dst, "w").write(u)
        return tag, f, "ok"

    with ThreadPoolExecutor(6) as ex:
        res = list(ex.map(one, clips))
    bad = [r for r in res if r[2] == "FAIL"]
    print(f"完成 {len(res)-len(bad)}/{len(res)}，失败 {len(bad)}")
    for b in bad[:10]:
        print("  ❌", b)


def stage_asr():
    """每 call 10 段"""
    out_dir = f"{ROOT}/asr_raw"
    os.makedirs(out_dir, exist_ok=True)
    tasks = []
    for tag in sorted(os.listdir(URL_DIR)):
        td = f"{URL_DIR}/{tag}"
        for f in sorted(os.listdir(td)):
            key = f"{tag}/{f[:-4]}"
            if os.path.exists(f"{out_dir}/{key}.json"):
                continue
            tasks.append((key, open(f"{td}/{f}").read().strip()))
    print(f"待 ASR {len(tasks)} 段")
    if not tasks:
        return
    B = 5          # 🔴 平台每批最多 5 条（超了直接 400 拒）

    def do_batch(batch):
        args = {"audio_info": [{"url": u, "mime_type": "audio/mpeg", "prompt": PROMPT} for _, u in batch]}
        ap = f"{ROOT}/_args_{os.getpid()}_{batch[0][0].replace('/', '_')}.json"
        json.dump(args, open(ap, "w"), ensure_ascii=False)
        for attempt in range(4):
            r = subprocess.run(["mcode-tools", "connector", "call", "connector__matrix__audios_understand",
                                "--args-file", ap], capture_output=True, text=True, timeout=900)
            try:
                d = json.loads(r.stdout)
            except Exception:
                d = None
            if d and d.get("results"):
                for (key, _), res in zip(batch, d["results"]):
                    fp = f"{out_dir}/{key}.json"
                    os.makedirs(os.path.dirname(fp), exist_ok=True)
                    json.dump(res, open(fp, "w"), ensure_ascii=False)
                return batch, "ok"
            # 并发太高 / 平台瞬时失败 ⇒ 退避重试
            time.sleep(4 * (attempt + 1))
        print(f"  ❌ batch {batch[0][0]} 重试 4 次仍失败: {str(d)[:160] if d else r.stderr[:160]}", flush=True)
        return batch, "fail"

    batches = [tasks[i:i + B] for i in range(0, len(tasks), B)]
    with ThreadPoolExecutor(2) as ex:   # 🔴 并发别高：>3 会被平台拒（latency_ms=0）
        for batch, st in ex.map(do_batch, batches):
            print(f"  batch {batch[0][0]} … {st}", flush=True)


# 平台时间戳格式不固定：有时【35】，有时【00:35】，有时【1:02:03】⇒ 三种都认
LINE_RE = re.compile(r"【\s*((?:\d+:)?\d+(?:\.\d+)?)\s*】\s*(.*)")


def parse_ts(s):
    parts = s.split(":")
    try:
        v = [float(x) for x in parts]
    except ValueError:
        return None
    sec = 0.0
    for x in v:
        sec = sec * 60 + x
    return sec


def stage_parse():
    """把 asr_raw/**/*.json 解析成 asr_truth/<tag>.json = [{start, text}]（绝对秒）"""
    os.makedirs(TRUTH_DIR, exist_ok=True)
    raw = f"{ROOT}/asr_raw"
    per_book = {}
    for dirpath, _d, files in os.walk(raw):
        for f in files:
            if not f.endswith(".json"):
                continue
            rel = os.path.relpath(os.path.join(dirpath, f), raw)
            if os.sep not in rel:
                continue
            tag, seg = rel[:-5].split(os.sep, 1)
            off = int(seg.split(".")[0])
            d = json.load(open(os.path.join(dirpath, f)))
            desc = d.get("description", "") or ""
            if not desc.strip():
                continue
            per_book.setdefault(tag, []).append((off, desc))

    for tag, lst in per_book.items():
        lines = []
        for off, desc in sorted(lst):
            for m in LINE_RE.finditer(desc):
                base = parse_ts(m.group(1))
                if base is None:
                    continue
                txt = m.group(2).strip()
                if txt:
                    lines.append({"start": round(base + off, 2), "text": txt})
        out, seen = [], set()
        for l in sorted(lines, key=lambda x: x["start"]):
            k = (l["start"], l["text"][:24])
            if k in seen:
                continue
            seen.add(k)
            out.append(l)
        json.dump(out, open(f"{TRUTH_DIR}/{tag}.json", "w"), ensure_ascii=False)
        print(f"  {tag:36} {len(out):4} 行  末秒 {out[-1]['start'] if out else 0:.1f}")


if __name__ == "__main__":
    stage = sys.argv[sys.argv.index("--stage") + 1] if "--stage" in sys.argv else "parse"
    {"download": stage_download, "cut": stage_cut, "upload": stage_upload,
     "asr": stage_asr, "parse": stage_parse}[stage]()
