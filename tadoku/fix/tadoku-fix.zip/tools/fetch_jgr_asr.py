#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
日语泛读 · 第 1 批（官方朗読）ASR 真值 —— 0 额度通道，**以书为单位**

与第一版（以 mp3 为单位）的区别：
  · 同事的 manifest 里 **4 本书跨多个 mp3**（官方朗読按故事分轨）
    ⇒ 跨轨的书不能「一书一 mp3」，必须把各轨的绝对时间接起来
  · 本器做法：**不重新拼音频**（省一次 8 小时全量转码），而是
      给每条轨算一个**累计偏移 offset**，切段时就把「绝对起点」写进文件名
      ⇒ ASR 返回的段内时间 + 绝对起点 = 书内的绝对时间
  · 🔴 跨轨拼接顺序 = manifest 的 audio_mp3_all 数组顺序（**不是文件名顺序**）

平台通道参数（上一轮实测，必须照抄）：
  · 每批最多 5 条（超了 400 拒）· 并发 >3 被拒（latency_ms=0）
  · 必须先 upload_temp_url 拿 temp_url，不能直接传外链
"""
import json, os, re, subprocess, sys, time
from concurrent.futures import ThreadPoolExecutor

# 🔴 路径全部可用环境变量覆盖（默认保持旧行为不变）
#    ⇒ 下一批（batch 1）复用**同一份配方**，不另写一套实现
ROOT = os.environ.get("TD_ROOT", "/workspace/work/tadoku")
JGR = os.environ.get("TD_JGR", f"{ROOT}/jgr")
EXT_DIR = f"{JGR}/ext"
B56 = f"{JGR}/books56"
CLIP_DIR = f"{JGR}/clips"
URL_DIR = f"{JGR}/urls"
RAW_DIR = f"{JGR}/asr_raw"
TRUTH_DIR = f"{JGR}/asr_truth"

CHUNK = 40
BATCH = 5
CONCURRENCY = 2

PROMPT = ("这是一本日语有声读物。**严格逐字转写**这段音频的日文内容："
          "①保留原有标点；②不要添加原文没有的词，不要翻译、不要概括、不要补全；"
          "③听不清用 □；④按听到顺序逐句输出，每句前标【秒】=该句在这段音频里的起始秒数"
          "（整数，本段开头为 0）。")


def sh(cmd, timeout=1800):
    return subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=timeout).stdout


def ffprobe_dur(path):
    r = sh(f'ffprobe -v error -show_entries format=duration -of csv=p=0 "{path}"', 120)
    try:
        return float(r.strip())
    except Exception:
        return 0.0


def manifest():
    return json.load(open(os.environ.get("TD_MANIFEST", f"{B56}/manifest.json")))


# 「书文件还没到」时（下一批：先做 ASR，文本后到）跳过书/句数核对
NO_BOOK_CHECK = os.environ.get("TD_NO_BOOK_CHECK") == "1"


# ---------------- stage: build（核映射 + 算跨轨偏移） ----------------
def stage_build():
    ms = manifest()
    units = []
    problems = []
    for b in ms:
        tracks = b.get("audio_mp3_all") or ([b["audio_mp3"]] if b.get("audio_mp3") else [])
        built = []
        off = 0.0
        for i, rel in enumerate(tracks):
            isbn, name = rel.split("/")
            p = f"{EXT_DIR}/{isbn}/{name}"
            if not os.path.exists(p):
                problems.append(f"{b['tag']}: 缺文件 {rel}")
                continue
            d = ffprobe_dur(p)
            # 🔴 独立核对：manifest 报的这条轨时长必须和实测一致（不一致 = 配错书了）
            exp = (b.get("dur_parts") or [])[i] if i < len(b.get("dur_parts") or []) else None
            if exp is not None and abs(exp - d) > 0.5:
                problems.append(f"{b['tag']}: 轨{i} 时长不符 manifest={exp} 实测={d:.2f} ({rel})")
            built.append({"path": p, "rel": rel, "dur": d, "offset": round(off, 3)})
            off += d
        tot = sum(x["dur"] for x in built)
        mdur = b.get("dur") or 0
        if abs(mdur - tot) > 1.0:
            problems.append(f"{b['tag']}: 总时长不符 manifest={mdur} 实测={tot:.2f}")
        # 句子数核对：书里的 cue 数必须等于 manifest 的 sentences
        bp = f"{B56}/books/{b['tag']}.json"
        ncue = None
        if NO_BOOK_CHECK:
            pass                       # 🔴 文本还没到 ⇒ 这一轮不核对（ASR 按轨做，与文本无关）
        elif os.path.exists(bp):
            bd = json.load(open(bp))
            ncue = len(bd.get("cues") or [])
            if b.get("sentences") and ncue != b["sentences"]:
                problems.append(f"{b['tag']}: 句数不符 manifest={b['sentences']} 实文件={ncue}")
        else:
            problems.append(f"{b['tag']}: 缺书文件 {bp}")
        units.append({"tag": b["tag"], "title": b.get("title"), "level": b.get("level"),
                      "sentences": b.get("sentences"), "cues": ncue,
                      "tracks": built, "dur": round(tot, 2), "manifest_dur": mdur,
                      "official_title": b.get("official_title"),
                      "head_asr": (b.get("audio_head_asr") or "")[:120]})
    json.dump(units, open(f"{JGR}/units.json", "w"), ensure_ascii=False, indent=1)
    print(f"核对 {len(units)} 本")
    for u in units:
        ncue = u['cues']
        print(f"  {u['tag'][:50]:52} 句{(str(ncue) if ncue is not None else '-'):>4}  "
              f"轨{len(u['tracks'])}  dur={u['dur']:8.1f}")
    print(f"\n总时长 {sum(u['dur'] for u in units)/3600:.2f} 小时")
    if problems:
        print("\n❌ 核对问题：")
        for p in problems:
            print("   -", p)
        sys.exit(1)
    print("✅ 映射/时长/句数全部核对通过")


# ---------------- stage: cut（文件名写绝对起点 ms） ----------------
def stage_cut():
    units = json.load(open(f"{JGR}/units.json"))
    os.makedirs(CLIP_DIR, exist_ok=True)
    total = 0
    for u in units:
        out = f"{CLIP_DIR}/{u['tag']}"
        os.makedirs(out, exist_ok=True)
        n = 0
        for ti, tr in enumerate(u["tracks"]):
            loc = 0.0
            while loc < tr["dur"]:
                abs_ms = int(round((tr["offset"] + loc) * 1000))
                f = f"{out}/{abs_ms:09d}.mp3"
                if not os.path.exists(f) or os.path.getsize(f) < 1000:
                    sh(f'ffmpeg -v error -ss {loc:.3f} -t {CHUNK} -i "{tr["path"]}" '
                       f'-c:a libmp3lame -b:a 48k -ar 22050 -ac 1 "{f}" -y', 300)
                n += 1
                loc += CHUNK
        u["clips"] = n
        total += n
        print(f"  {u['tag'][:50]:52} dur={u['dur']:8.1f}s → {n:3} 段", flush=True)
    json.dump(units, open(f"{JGR}/units.json", "w"), ensure_ascii=False, indent=1)
    print(f"总段数 {total}")


# ---------------- stage: upload ----------------
def stage_upload():
    os.makedirs(URL_DIR, exist_ok=True)
    tasks = []
    for tag in sorted(os.listdir(CLIP_DIR)):
        cd = f"{CLIP_DIR}/{tag}"
        if not os.path.isdir(cd):
            continue
        for f in sorted(os.listdir(cd)):
            if f.endswith(".mp3"):
                tasks.append((tag, f, f"{cd}/{f}"))
    print(f"待上传 {len(tasks)} 段")

    def one(item):
        tag, f, path = item
        dst = f"{URL_DIR}/{tag}/{f}.url"
        if os.path.exists(dst) and os.path.getsize(dst) > 50:
            return tag, f, "skip"
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        out = sh(f'mcode-tools upload_temp_url "{path}"', 900)
        try:
            u = json.loads(out)["temp_url"]
        except Exception:
            return tag, f, "FAIL:" + out[:150]
        open(dst, "w").write(u)
        return tag, f, "ok"

    with ThreadPoolExecutor(6) as ex:
        res = list(ex.map(one, tasks))
    bad = [r for r in res if r[2].startswith("FAIL")]
    print(f"上传完成 {len(res)-len(bad)}/{len(res)}，失败 {len(bad)}")
    for b in bad[:10]:
        print("  ❌", b)
    # 🔴 单段上传失败**不中断整条链**（上一轮就是被 exit 1 掐死的）⇒ 重试 3 轮
    for rnd in range(3):
        if not bad:
            break
        print(f"  重试第 {rnd+1} 轮：{len(bad)} 段")
        time.sleep(20)

        def one2(item):
            stem, f, path = item
            dst = f"{URL_DIR}/{stem}/{f}.url"
            if os.path.exists(dst) and os.path.getsize(dst) > 50:
                return stem, f, "skip"
            out = sh(f'mcode-tools upload_temp_url "{path}"', 900)
            try:
                u = json.loads(out)["temp_url"]
            except Exception:
                return stem, f, "FAIL:" + out[:150]
            open(dst, "w").write(u)
            return stem, f, "ok"

        retry = [(b[0], b[1], f"{CLIP_DIR}/{b[0]}/{b[1]}") for b in bad]
        with ThreadPoolExecutor(2) as ex:
            res2 = list(ex.map(one2, retry))
        bad = [r for r in res2 if r[2].startswith("FAIL")]
        print(f"  重试后仍失败 {len(bad)}")
    if bad:
        print(f"⚠️ 有 {len(bad)} 段始终上传失败（ASR 会缺这几段，对齐时该处按无对应处理）")
    else:
        print("✅ 全部段上传成功")


# ---------------- stage: asr ----------------
def stage_asr():
    os.makedirs(RAW_DIR, exist_ok=True)
    tasks = []
    for tag in sorted(os.listdir(URL_DIR)):
        td = f"{URL_DIR}/{tag}"
        if not os.path.isdir(td):
            continue
        for f in sorted(os.listdir(td)):
            key = f"{tag}/{f[:-4]}"
            rp = f"{RAW_DIR}/{key}.json"
            if os.path.exists(rp):
                # 🔴 **失败结果也会被缓存** ⇒ 只判「文件存在」会让失败段永远被跳过
                #    ⇒ 判据必须是「success 且 description 非空」
                #    （"[No speech]" 是**真实答案**（书末尾就是静音）⇒ 保留，不重试）
                try:
                    d = json.load(open(rp))
                except Exception:
                    d = None
                desc = (d or {}).get("description") or ""
                if d and d.get("success") and desc.strip() and "No speech" not in desc:
                    continue
                if d and d.get("success") and "No speech" in desc:
                    continue          # 真的没话 ⇒ 不重试
                os.remove(rp)          # 失败/空 ⇒ 清掉重做
                print(f"  ↻ 重做坏段：{key}", flush=True)
            tasks.append((key, open(f"{td}/{f}").read().strip()))
    print(f"待 ASR {len(tasks)} 段")
    if not tasks:
        return
    os.makedirs(f"{JGR}/args", exist_ok=True)

    def do_batch(batch):
        args = {"audio_info": [{"url": u, "mime_type": "audio/mpeg", "prompt": PROMPT}
                               for _, u in batch]}
        ap = f"{JGR}/args/a_{os.getpid()}_{batch[0][0].replace('/', '_')}.json"
        json.dump(args, open(ap, "w"), ensure_ascii=False)
        for attempt in range(4):
            r = subprocess.run(["mcode-tools", "connector", "call",
                                "connector__matrix__audios_understand", "--args-file", ap],
                               capture_output=True, text=True, timeout=1800)
            try:
                d = json.loads(r.stdout)
            except Exception:
                d = None
            if d and d.get("results"):
                for (key, _), res in zip(batch, d["results"]):
                    fp = f"{RAW_DIR}/{key}.json"
                    os.makedirs(os.path.dirname(fp), exist_ok=True)
                    json.dump(res, open(fp, "w"), ensure_ascii=False)
                return batch[0][0], "ok"
            time.sleep(5 * (attempt + 1))
        print(f"  ⚠️ 批次 {batch[0][0]} 重试 4 次仍失败 ⇒ **退回单条调用**"
              f"（一个坏条目会拖垮整批）", flush=True)
        # 🔴 批次失败时**退回单条**：实测同一段单独调是成功的
        #    ⇒ 「整批失败」常常只是某一条把整批拖垮，不该整批丢弃
        n_ok = 0
        for key, u in batch:
            one = {"audio_info": [{"url": u, "mime_type": "audio/mpeg", "prompt": PROMPT}]}
            ap1 = f"{JGR}/args/one_{os.getpid()}_{key.replace('/', '_')}.json"
            json.dump(one, open(ap1, "w"), ensure_ascii=False)
            got = False
            for att in range(3):
                r1 = subprocess.run(["mcode-tools", "connector", "call",
                                     "connector__matrix__audios_understand", "--args-file", ap1],
                                    capture_output=True, text=True, timeout=1800)
                try:
                    d1 = json.loads(r1.stdout)
                except Exception:
                    d1 = None
                if d1 and d1.get("results"):
                    fp = f"{RAW_DIR}/{key}.json"
                    os.makedirs(os.path.dirname(fp), exist_ok=True)
                    json.dump(d1["results"][0], open(fp, "w"), ensure_ascii=False)
                    got = True
                    n_ok += 1
                    break
                time.sleep(3 * (att + 1))
            if not got:
                print(f"     ❌ 单条也失败：{key}", flush=True)
        return batch[0][0], f"single-fallback({n_ok}/{len(batch)})"

    batches = [tasks[i:i + BATCH] for i in range(0, len(tasks), BATCH)]
    done = 0
    with ThreadPoolExecutor(CONCURRENCY) as ex:
        for key, st in ex.map(do_batch, batches):
            done += 1
            print(f"  [{done}/{len(batches)}] {key} … {st}", flush=True)


# ---------------- stage: parse ----------------
LINE_RE = re.compile(r"【\s*((?:\d+:)?\d+(?:\.\d+)?)\s*秒?\s*】\s*(.*)")


def parse_ts(s):
    try:
        v = [float(x) for x in s.split(":")]
    except ValueError:
        return None
    sec = 0.0
    for x in v:
        sec = sec * 60 + x
    return sec


def stage_parse():
    os.makedirs(TRUTH_DIR, exist_ok=True)
    per_book = {}
    for dirpath, _d, files in os.walk(RAW_DIR):
        for f in files:
            if not f.endswith(".json"):
                continue
            rel = os.path.relpath(os.path.join(dirpath, f), RAW_DIR)
            if os.sep not in rel:
                continue
            tag, seg = rel[:-5].split(os.sep, 1)
            off = int(seg.split(".")[0]) / 1000.0     # 文件名写的是**绝对起点 ms**
            d = json.load(open(os.path.join(dirpath, f)))
            desc = d.get("description", "") or ""
            if not desc.strip():
                continue
            per_book.setdefault(tag, []).append((off, desc))

    total = 0
    for tag, lst in sorted(per_book.items()):
        lines = []
        for off, desc in sorted(lst):
            for m in LINE_RE.finditer(desc):
                base = parse_ts(m.group(1))
                if base is None:
                    continue
                txt = m.group(2).strip()
                if txt:
                    lines.append({"start": round(base + off, 2), "text": txt})
        out, seen = [], set()
        for l in sorted(lines, key=lambda x: x["start"]):
            k = (l["start"], l["text"][:24])
            if k in seen:
                continue
            seen.add(k)
            out.append(l)
        json.dump(out, open(f"{TRUTH_DIR}/{tag}.json", "w"), ensure_ascii=False)
        total += len(out)
        print(f"  {tag[:50]:52} {len(out):4} 行  末秒 {out[-1]['start'] if out else 0:.1f}")
    print(f"共 {total} 行")


if __name__ == "__main__":
    stage = sys.argv[sys.argv.index("--stage") + 1] if "--stage" in sys.argv else "parse"
    {"build": stage_build, "cut": stage_cut, "upload": stage_upload,
     "asr": stage_asr, "parse": stage_parse}[stage]()
