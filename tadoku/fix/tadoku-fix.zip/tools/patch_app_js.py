#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
给线上 app.js 打补丁：让「音频里没有对应」的句子不参与高亮 / 跳转。

三处改动（缺一不可）：
  ① flatten()：把 cue.no_audio 带到每行
  ② binarySearch()：回退到最近一条**有对应**的行（否则高亮会停在没声音的句子上）
  ③ 点击句子：no_audio 的句子不跳到自己的时间，改跳到最近一条有对应的句子
     （详解窗照常打开 —— 用户仍要能读这句、查词）

用法：python3 patch_app_js.py <app.js 的路径>
"""
import re, sys

PATCHES = [
    # ① flatten
    ("""        lines.push({
          cue: c, row: r, s: c.s, e: c.e, first: j === 0, cueIdx: i,
          sp: who, newSp: !!r.sp
        });""",
     """        lines.push({
          cue: c, row: r, s: c.s, e: c.e, first: j === 0, cueIdx: i,
          sp: who, newSp: !!r.sp,
          /* 这句在音频里没有对应（书面原文有、朗読没念）⇒ 不参与高亮/跳转 */
          noAudio: !!c.no_audio
        });"""),
    # ② binarySearch
    ("""  function binarySearch(ms) {
    var lo = 0, hi = S.lines.length - 1, ans = -1;
    while (lo <= hi) {
      var mid = (lo + hi) >> 1;
      if (S.lines[mid].s * 1000 <= ms) { ans = mid; lo = mid + 1; }
      else hi = mid - 1;
    }
    return ans;
  }""",
     """  function binarySearch(ms) {
    var lo = 0, hi = S.lines.length - 1, ans = -1;
    while (lo <= hi) {
      var mid = (lo + hi) >> 1;
      if (S.lines[mid].s * 1000 <= ms) { ans = mid; lo = mid + 1; }
      else hi = mid - 1;
    }
    /* 回退到最近一条「音频里有对应」的句子 ⇒ 高亮不会停在哑句上 */
    while (ans >= 0 && S.lines[ans].noAudio) ans--;
    return ans;
  }"""),
    # ③ 点击句子
    ("""      var i = +el.getAttribute('data-i');
      seek(S.lines[i].s * 1000);       /* 点句 → 跳到播放位置 */
      openEx(i);""",
     """      var i = +el.getAttribute('data-i');
      /* 哑句（音频里没有这句）⇒ 跳到最近一条有对应的地方，不跳到自己的时间 */
      var j = i;
      while (j >= 0 && S.lines[j].noAudio) j--;
      if (j >= 0) seek(S.lines[j].s * 1000);   /* 点句 → 跳到播放位置 */
      openEx(i);"""),
]


def main():
    path = sys.argv[1]
    s = open(path, encoding="utf-8").read()
    orig = s
    for old, new in PATCHES:
        if new in s:
            print(f"  · 已是新版，跳过：{old.splitlines()[0][:50]}")
            continue
        if old not in s:
            print(f"  ❌ 找不到待改代码块：{old.splitlines()[0][:60]}")
            sys.exit(1)
        s = s.replace(old, new, 1)
        print(f"  ✅ 已改：{old.splitlines()[0][:50]}")
    if s == orig:
        print("  （无改动）")
    open(path, "w", encoding="utf-8").write(s)
    print(f"写入 {path}")


if __name__ == "__main__":
    main()
