#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
日语泛读：用对齐结果重建线上数据，并修时序硬 bug。

修的东西（都是实测出来的真缺陷）：
  ① 倒序：某条的 s 比上一条还小 ⇒ 前端 binarySearch 直接失效（当前句乱跳）
  ② 重叠：两条时间区间相交
  ③ 零时长：e-s < 0.15s ⇒ 这句在播放时一闪而过（用户看到「字幕跳得不对」）
  ④ 脏文本：句子里混进英文/占位符（一休_examples。/ [NOTE: If base mixed]）
  ⑤ 时间轴整体换成「音频真值」位置（ASR 逐句对齐的结果）

不变量（不满足直接 exit 1）：
  · 有音频对应的句子，按 s 排序后**严格递增**且**互不重叠**
  · 每句 s < e
  · no_audio 的句子**不参与**高亮（前端跳过）
"""
import json, os, re, sys

ROOT = "/workspace/work/tadoku"
ALIGNED = f"{ROOT}/aligned"
BOOKS = f"{ROOT}/books"
OUT = f"{ROOT}/out"

DIRTY = re.compile(r"[A-Za-z_]{3,}|\[NOTE:|examples|<NOTE>")


def fix_monotonic(cues, dur):
    """把有对应的时间轴改成严格递增、不重叠"""
    live = [c for c in cues if not c.get("no_audio")]
    for i, c in enumerate(live):
        if c["e"] - c["s"] < 0.15:
            c["e"] = round(c["s"] + 0.3, 2)
    for i in range(1, len(live)):
        prev, cur = live[i - 1], live[i]
        if cur["s"] < prev["e"]:
            cur["s"] = round(prev["e"] + 0.01, 2)
        if cur["e"] <= cur["s"]:
            cur["e"] = round(cur["s"] + 0.3, 2)
    # 末句不许超出音频
    if live and dur:
        last = live[-1]
        if last["e"] > dur:
            last["e"] = round(dur, 2)
            if last["s"] >= last["e"]:
                last["s"] = round(max(0.0, dur - 0.3), 2)
    return cues


def check(cues, dur):
    live = [c for c in cues if not c.get("no_audio")]
    errs = []
    for i, c in enumerate(live):
        if not (c["e"] > c["s"]):
            errs.append(f"#{i} 时长非正 s={c['s']} e={c['e']}")
        if i and c["s"] <= live[i - 1]["s"]:
            errs.append(f"#{i} 倒序 {live[i-1]['s']} → {c['s']}")
        if i and c["s"] < live[i - 1]["e"] - 1e-6:
            errs.append(f"#{i} 重叠 prev_e={live[i-1]['e']} s={c['s']}")
    if dur and live and live[-1]["e"] > dur + 1.0:
        errs.append(f"末句 e={live[-1]['e']} 超出音频 {dur}")
    return errs


def main():
    os.makedirs(OUT, exist_ok=True)
    idx = json.load(open(f"{ROOT}/index.json"))["episodes"]
    tags = [e["tag"] for e in idx if e.get("has_audio")]
    summary = []
    for tag in tags:
        ap = f"{ALIGNED}/{tag}.json"
        bp = f"{BOOKS}/{tag}.json"
        if not os.path.exists(ap):
            print(f"  ⏭ {tag}（还没对齐）")
            continue
        al = json.load(open(ap))
        bk = json.load(open(bp))
        dur = al.get("dur") or bk.get("dur") or 0
        cues = al["cues"]

        # 脏文本标记（不自动改，列出来人工核）
        dirty = []
        for i, c in enumerate(cues):
            for r in c.get("rows", []):
                t = r.get("t") or ""
                if DIRTY.search(t):
                    dirty.append({"i": i, "text": t})

        cues = fix_monotonic(cues, dur)
        errs = check(cues, dur)
        if errs:
            print(f"  ❌ {tag} 不变量失败：{errs[:3]}")
            sys.exit(1)

        bk["cues"] = cues
        bk["dur"] = dur
        json.dump(bk, open(f"{OUT}/{tag}.json", "w"), ensure_ascii=False)
        na = sum(1 for c in cues if c.get("no_audio"))
        summary.append({"tag": tag, "cues": len(cues), "no_audio": na, "dirty": dirty,
                        "dur": dur})
        print(f"  ✅ {tag:36} {len(cues):4}句  无对应 {na:3}  脏行 {len(dirty)}")
    json.dump(summary, open(f"{ROOT}/rebuild_report.json", "w"), ensure_ascii=False)
    print(f"\n输出到 {OUT}")


if __name__ == "__main__":
    main()
