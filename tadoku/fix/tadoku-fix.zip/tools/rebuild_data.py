#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
日语泛读：用对齐结果重建线上数据，并修时序硬 bug。

修的东西（都是实测出来的真缺陷）：
  ① 倒序：某条的 s 比上一条还小 ⇒ 前端 binarySearch 直接失效（当前句乱跳）
  ② 重叠：两条时间区间相交
  ③ 零时长：e-s < 0.15s ⇒ 这句在播放时一闪而过（用户看到「字幕跳得不对」）
  ④ 脏文本：句子里混进英文/占位符（一休_examples。/ [NOTE: If base mixed]）
  ⑤ 时间轴整体换成「音频真值」位置（ASR 逐句对齐的结果）

不变量（不满足直接 exit 1）：
  · 有音频对应的句子，按 s 排序后**严格递增**且**互不重叠**
  · 每句 s < e
  · no_audio 的句子**不参与**高亮（前端跳过）
"""
import json, os, re, sys

ROOT = "/workspace/work/tadoku"
ALIGNED = f"{ROOT}/aligned"
BOOKS = f"{ROOT}/books"
OUT = f"{ROOT}/out"

DIRTY = re.compile(r"[A-Za-z_]{3,}|\[NOTE:|examples|<NOTE>")


def fix_monotonic(cues, dur):
    """把有对应的时间轴改成严格递增、不重叠

    🔴 **被推移的句子 = 假时间**（前端高亮会停在假位置上）
       ⇒ 交付前必须单独统计这个数（peer 要求）⇒ 返回 (cues, n_shifted)
    """
    live = [c for c in cues if not c.get("no_audio")]
    n_shifted = 0
    for i, c in enumerate(live):
        if c["e"] - c["s"] < 0.15:
            c["e"] = round(c["s"] + 0.3, 2)
    n_clipped = 0
    for i in range(1, len(live)):
        prev, cur = live[i - 1], live[i]
        # ① 先保证**起点严格递增**（前端 binarySearch 的前提）
        #    倒序残余只挪 0.01 秒 ⇒ 视觉上不可见（不是「假时间」那种级别的偏移）
        if cur["s"] <= prev["s"]:
            cur["s"] = round(prev["s"] + 0.01, 2)
            n_shifted += 1
        if cur["e"] <= cur["s"]:
            cur["e"] = round(cur["s"] + 0.3, 2)
        # ② 再消重叠：**裁剪上一句的终点**，不动上一句的起点
        #    🔴 裁剪后若上一句区间变空 ⇒ 只能给 0.01 秒（撑大 0.15 秒会**重新制造重叠**）
        if cur["s"] < prev["e"]:
            prev["e"] = round(cur["s"], 2)
            if prev["e"] <= prev["s"]:
                prev["e"] = round(prev["s"] + 0.01, 2)
            n_clipped += 1
    # 末句不许超出音频
    if live and dur:
        last = live[-1]
        if last["e"] > dur:
            last["e"] = round(dur, 2)
            if last["s"] >= last["e"]:
                last["s"] = round(max(0.0, dur - 0.3), 2)
    return cues, n_shifted, n_clipped


def zero_no_audio(cues):
    """
    哑句的时间轴**归零**（贴在上一条有音句的末尾）⇒ 整条数组非递减、不重叠。

    🔴 为什么必须归零：前端 binarySearch 依赖数组单调
       ⇒ 哑句若留着旧的估算 s/e（可能落在有音句中间）⇒ 高亮会跳到哑句上 / 跳错行
    ⇒ 线上权威数据（v1.2.0）就是这个口径：**零长 + 贴住上一条有音句末尾**（实测核对过）
    """
    prev_end = 0.0
    for c in cues:
        if c.get("no_audio"):
            c["s"] = round(prev_end, 2)
            c["e"] = round(prev_end, 2)
        else:
            prev_end = c.get("e", prev_end)
    return cues


def check(cues, dur):
    live = [c for c in cues if not c.get("no_audio")]
    errs = []
    for i, c in enumerate(live):
        if not (c["e"] > c["s"]):
            errs.append(f"#{i} 时长非正 s={c['s']} e={c['e']}")
        if i and c["s"] <= live[i - 1]["s"]:
            errs.append(f"#{i} 倒序 {live[i-1]['s']} → {c['s']}")
        if i and c["s"] < live[i - 1]["e"] - 1e-6:
            errs.append(f"#{i} 重叠 prev_e={live[i-1]['e']} s={c['s']}")
    if dur and live and live[-1]["e"] > dur + 1.0:
        errs.append(f"末句 e={live[-1]['e']} 超出音频 {dur}")
    return errs


def main():
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--aligned-dir", default=ALIGNED)
    ap.add_argument("--books-dir", default=BOOKS)
    ap.add_argument("--out-dir", default=OUT)
    ap.add_argument("--report", default=f"{ROOT}/rebuild_report.json")
    ap.add_argument("--tags", default="")
    a = ap.parse_args()

    os.makedirs(a.out_dir, exist_ok=True)
    if a.tags:
        tags = [t.strip() for t in a.tags.split(",") if t.strip()]
    else:
        # 🔴 从**书目录**推导，不要写死读 index.json
        #    （旧批次 books/ 里正好是 34 本有音的书 ⇒ 与旧行为等价；
        #      新批次 books56/books/ 里是 20 本 ⇒ 原来会被整批跳过）
        tags = sorted(os.path.splitext(f)[0] for f in os.listdir(a.books_dir) if f.endswith(".json"))
    summary = []
    for tag in tags:
        ap_ = f"{a.aligned_dir}/{tag}.json"
        bp = f"{a.books_dir}/{tag}.json"
        if not os.path.exists(ap_):
            print(f"  ⏭ {tag}（还没对齐）")
            continue
        al = json.load(open(ap_))
        bk = json.load(open(bp))
        dur = al.get("dur") or bk.get("dur") or 0
        cues = al["cues"]

        # 脏文本标记（不自动改，列出来人工核）
        dirty = []
        for i, c in enumerate(cues):
            for r in c.get("rows", []):
                t = r.get("t") or ""
                if DIRTY.search(t):
                    dirty.append({"i": i, "text": t})

        cues, n_shifted, n_clipped = fix_monotonic(cues, dur)
        cues = zero_no_audio(cues)
        errs = check(cues, dur)
        if errs:
            print(f"  ❌ {tag} 不变量失败：{errs[:3]}")
            sys.exit(1)

        bk["cues"] = cues
        bk["dur"] = dur
        # 🔴 统计「乱序降级」要在**剥内部字段之前**取，否则统计恒为 0
        n_ord = sum(1 for c in cues if c.get("_ord"))
        # 🔴 输出格式对齐**线上已发布数据**：
        #    · cov 只留在 aligned/（工作产物），不进交付数据
        #    · no_audio 只在哑句上出现（前端 !!c.no_audio ⇒ 缺省即 false）
        for c in cues:
            c.pop("cov", None)
            for k in [k for k in c if k.startswith("_")]:   # _n / _ch 等内部字段不进交付数据
                c.pop(k, None)
            if c.get("no_audio"):
                c["no_audio"] = 1
            else:
                c.pop("no_audio", None)
        json.dump(bk, open(f"{a.out_dir}/{tag}.json", "w"), ensure_ascii=False)
        na = sum(1 for c in cues if c.get("no_audio"))
        summary.append({"tag": tag, "cues": len(cues), "no_audio": na, "dirty": dirty,
                        "dur": dur, "shifted": n_shifted, "clipped": n_clipped,
                        "out_of_order": n_ord})
        print(f"  ✅ {tag:44} {len(cues):4}句  无对应 {na:3}  乱序降级 "
              f"{summary[-1]['out_of_order']:3}  假时间(被推移) {n_shifted:3}  "
              f"裁剪终点 {n_clipped:3}  脏行 {len(dirty)}")
    json.dump(summary, open(a.report, "w"), ensure_ascii=False)
    sh = sum(r.get("shifted", 0) for r in summary)
    oo = sum(r.get("out_of_order", 0) for r in summary)
    cl = sum(r.get("clipped", 0) for r in summary)
    print(f"\n输出到 {a.out_dir}｜乱序降级合计 {oo} 句｜假时间（被强行推移）合计 {sh} 句"
          f"｜裁剪上一句终点合计 {cl} 处")


if __name__ == "__main__":
    main()
