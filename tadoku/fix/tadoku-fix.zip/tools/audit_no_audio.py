#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
哑句自证：被判成「音频里没有」的句子，到底是真没念，还是**音频里有但我没对上**？

做法：对每条哑句，在**整本 ASR 真值**里找最匹配的一行（独立于全局对齐）
     ⇒ 若存在覆盖 ≥ 0.5 的行 ⇒ 这句**音频里确实有** ⇒ 我判错了（不是哑句）
     ⇒ 若全都 < 0.5 ⇒ 真·哑句（音频没念这句）

这一步是必须的：把有声音的句子误标成哑句 ⇒ 播放时「字幕亮一句、声音念另一句」
              —— 正是这次要修的那个 bug。
"""
import json, os, sys
from difflib import SequenceMatcher

ROOT = "/workspace/work/tadoku"
JGR = f"{ROOT}/jgr"
sys.path.insert(0, ROOT)
from align_audio import norm

THRESH = float(os.environ.get("THRESH", "0.5"))


def cov(a, b):
    if not a or not b:
        return 0.0
    m = SequenceMatcher(None, a, b, autojunk=False)
    return sum(bl.size for bl in m.get_matching_blocks()) / len(a)


def main():
    only = sys.argv[1:] or None
    books = json.load(open(f"{JGR}/align_report.json"))
    total_na = 0
    false_na = 0
    details = {}
    for r in books:
        tag = r["tag"]
        if only and tag not in only:
            continue
        al = json.load(open(f"{JGR}/aligned/{tag}.json"))
        truth = json.load(open(f"{JGR}/asr_truth/{tag}.json"))
        lines = [(l["start"], norm(l["text"])) for l in truth]
        rows = []
        for i, c in enumerate(al["cues"]):
            if not c.get("no_audio"):
                continue
            txt = "".join(x.get("t", "") for x in c.get("rows", []))
            n = norm(txt)
            best, bt = 0.0, None
            for st, ln in lines:
                v = cov(n, ln)
                if v > best:
                    best, bt = v, st
            rows.append({"i": i, "text": txt, "cov": round(best, 3), "at": bt})
        na = len(rows)
        bad = [x for x in rows if x["cov"] >= THRESH]
        total_na += na
        false_na += len(bad)
        details[tag] = {"no_audio": na, "false_no_audio": len(bad), "samples": bad[:6]}
        flag = "🔴" if bad else ("🟡" if na else "  ")
        print(f"  {flag} {tag[:44]:46} 哑句 {na:3}  其中「音频里其实有」 {len(bad):3}")
        for b in bad[:4]:
            print(f"        #{b['i']:4} cov={b['cov']:.2f} @音频{b['at']}s  {b['text'][:44]}")
    print(f"\n合计：哑句 {total_na}，其中疑似误判 {false_na} "
          f"({false_na/max(1,total_na)*100:.1f}%)")
    json.dump(details, open(f"{JGR}/no_audio_audit.json", "w"), ensure_ascii=False, indent=1)


if __name__ == "__main__":
    main()
