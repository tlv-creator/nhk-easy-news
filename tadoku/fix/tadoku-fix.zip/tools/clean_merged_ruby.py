#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
「OCR 把振假名并进正文」的精确清理

现象（別冊非虚构类书，教材 26 本没有这个问题）：
  t  = "これは、むかし昔から日本人が、こわ怖いとおも思っている4つのものです。"
  ru = [["これは、むかし",""], ["昔","むかし"], ["から",""], ["日本人","にほんじん"],
        ["が、こわ",""], ["怖","こわ"], ...]
  ⇒ 「むかし」「こわ」「おも」都是**下一条 ruby 单元的读音**，被 OCR 印在了正文里
  ⇒ 用户看到的正文是「むかし昔」这种重复 ⇒ 既难看，也让对齐覆盖率被拖低 ⇒ 句子被误判成哑句

清理规则（**用 ru 反推，不猜**）：
  相邻两个 ruby 单元 u_i、u_{i+1}：
    若 u_{i+1} 有读音 R，且 u_i 的 base **以 R 结尾**（R 全是假名）⇒ R 就是被并进来的注音
    ⇒ 从 u_i 的 base 末尾删掉 R
  逐条从后往前处理（避免删完又触发新匹配）

为什么可信：
  · 依据是**该字自己的注音表**，不是启发式猜测
  · 删掉的是「紧挨着自己汉字前面」的同一串假名 ⇒ 不会误伤正文里本来就在的词
  · 反向验证：清理后「汉字 + 自己的注音」仍然在 ru 里 ⇒ 没删掉真内容
"""
import re

KANA = re.compile(r"^[ぁ-ゖー]+$")


def clean_row(t, ru):
    """返回清理后的正文；ru 为 None 时原样返回"""
    if not ru or not t:
        return t
    units = [list(u) for u in ru]
    # 从后往前：每删一次，后面单元的 base 不变，只影响它自己
    for i in range(len(units) - 1):
        base_i, read_i = (units[i] + [""])[:2]
        base_next, read_next = (units[i + 1] + [""])[:2]
        if not base_i or not read_next:
            continue
        r = read_next.strip()
        if not r or not KANA.match(r):
            continue
        if base_i.endswith(r):
            units[i][0] = base_i[: -len(r)]
    out = "".join((u[0] or "") for u in units)
    return out or t


def clean_cue_text(cue):
    """cue 的书面文本 = 各 row 清理后拼接"""
    parts = []
    for r in cue.get("rows", []) or []:
        parts.append(clean_row(r.get("t", ""), r.get("ru")))
    return "".join(parts)


def merged_stats(book):
    """统计这本书有多少 row 被并了假名、删了多少字符"""
    rows = touched = 0
    chars = 0
    for cue in book.get("cues", []) or []:
        for r in cue.get("rows", []) or []:
            c = clean_row(r.get("t", ""), r.get("ru"))
            if c != r.get("t", ""):
                touched += 1
                chars += len(r.get("t", "")) - len(c)
            rows += 1
    return rows, touched, chars


if __name__ == "__main__":
    import json, os, sys
    JGR = "/workspace/work/tadoku/jgr"
    books = sorted(os.listdir(f"{JGR}/books56/books"))
    tot_rows = tot_touched = tot_chars = 0
    print(f"{'书':46} {'row':>5} {'被并假名':>8} {'删掉字符':>8}")
    for f in books:
        b = json.load(open(f"{JGR}/books56/books/{f}"))
        rows, touched, chars = merged_stats(b)
        tot_rows += rows; tot_touched += touched; tot_chars += chars
        flag = "🔴" if touched else "  "
        print(f"  {flag} {f[:-5][:44]:46} {rows:5} {touched:8} {chars:8}")
    print(f"\n合计 {tot_rows} row，其中 {tot_touched} 被并了假名，共多出 {tot_chars} 字")
