/**
 * AI 讲解中转 · CloudBase 云函数
 * ------------------------------------------------------------------
 * 作用：保管 MiniMax Subscription Key，把前端的请求转成 MiniMax 调用，
 *       再把结果按固定契约返回。前端永远不接触 key。
 *
 * ✅ 双模式自动适配（同一个文件，两种创建方式都能跑）：
 *   A)「HTTP Node.js Hello World」模板（Web 框架型）→ 自动起 http server 监听 9000
 *   B) 普通云函数 + HTTP 触发器 → 走 exports.main
 *   判别逻辑：exports.main 被调用时会关掉 http server 并直接返回；
 *              Web 框架模式下 scf_bootstrap 只会 require 本文件，走 server 路由。
 *
 * 契约（前端只认这个，字段名别改）：
 *   POST /
 *   {
 *     "scene": "explain_sentence" | "explain_word",
 *     "title": "剧名", "episode": "第 N 话",
 *     "ja": "当前句", "zh": "当前句中文",
 *     "prev": [{ja,zh},...], "next": [{ja,zh},...],
 *     "word": "用户点的词（可空字符串）",
 *     "refs": [{ja,zh},...]      // 本剧真实台词，用来造例句
 *   }
 *   200 -> { "ok": true, "text": "Markdown 全文" }
 *   4xx/5xx -> { "ok": false, "error": "not_configured|too_many|bad_request|upstream_error|timeout" }
 *
 * 环境变量（在 CloudBase 控制台 → 函数配置 → 环境变量里配）：
 *   MM_API_KEY      必填。MiniMax **Subscription Key**（sk-cp- 开头）
 *   MM_BASE_URL     选填。默认 https://api.minimaxi.com/v1  （国内站）
 *                   国际站改成 https://api.minimax.io/v1
 *   MM_MODEL        选填。默认 MiniMax-M3
 *   MM_THINKING     选填。默认 disabled（关思考，快）
 *                   ⚠️ MiniMax-M3.1-Flash 必须用 adaptive，否则接口报 2013
 *   AI_TOKEN        选填。设了就在环境变量里填同一个值，不一致直接 401
 *   MM_TIMEOUT_MS   选填。默认 60000
 *   MM_MAX_TOKENS   选填。默认 2000
 *   AI_WEEKLY_STOP_PCT 选填。默认 20（周窗口剩余低于这个百分比就返回 too_many）
 *
 *   ⚠️ 曾有个 AI_DAILY_CAP（单实例内存计数）—— **已废弃、不生效**。
 *      真正的限流只看官方周窗口（weeklyStopPct），别再被它误导。
 */

'use strict';

const https = require('https');
const http = require('http');
const crypto = require('crypto');

/* prompt 指纹：前端拿它跟本地那份对比 → 不一致就说明该同步了 */
function promptSha() {
  return crypto.createHash('sha256').update(SYSTEM_PROMPT, 'utf8').digest('hex');
}

/* ------------------------------------------------------------------ */
/* 配置                                                                */
/* ------------------------------------------------------------------ */

/* ================================================================
   🔴 备用口子：如果你在 CloudBase 控制台里找不到「环境变量」的入口，
      就把下面这行引号里填上你的 key（只填 sk-cp-... 那一串本身，
      不要加别的字），然后保存部署即可。

      例：const MM_KEY_HERE = 'sk-cp-xxxxxxxxxxxxxxxx';
   ================================================================ */
const MM_KEY_HERE = '';

const CFG = {
  baseUrl: (process.env.MM_BASE_URL || 'https://api.minimaxi.com/v1').replace(/\/+$/, ''),
  apiKey: process.env.MM_API_KEY || MM_KEY_HERE || '',
  model: process.env.MM_MODEL || 'MiniMax-M3',
  thinking: process.env.MM_THINKING || 'disabled',
  timeoutMs: parseInt(process.env.MM_TIMEOUT_MS || '60000', 10),
  maxTokens: parseInt(process.env.MM_MAX_TOKENS || '2000', 10),
  token: process.env.AI_TOKEN || '',
  /* 🔴 真限流：MiniMax 周窗口剩余低于这个百分比就返回 too_many */
  weeklyStopPct: parseInt(process.env.AI_WEEKLY_STOP_PCT || '20', 10),
};

/* 只是日志里的调用计数（冷启动会重置）——**不是限流器**，别拿它当配额 */
let CALLS = 0;

/* ------------------------------------------------------------------ */
/* SYSTEM PROMPT —— 用户亲自定稿，别改格式，只在必要时微调措辞          */
/* ------------------------------------------------------------------ */
const SYSTEM_PROMPT = `【角色】
你是日语老师，给中文母语的学习者讲日语。讲解用中文；日语语法术语第一次出现时写成「中文（日本語用語）」双写。

【任务】
解析用户给你的一句日语台词（可能附带上下文）。严格按下面固定结构输出：不要寒暄、不要复述题目、不要用 emoji、不要自由发挥。

【输出结构（顺序固定）】
1. 原文：日语文本，汉字后用括号注假名（例：元気（げんき））
2. 中文翻译
3. 句子结构剖析

【句子结构剖析的固定写法】
3.1 整体大框架：只写一行，成分用字母标记（从 A 开始按出现顺序），被包住的部分用【】括起来。
    格式：A は 【B】 言っています
3.2 成分展开：每个成分写两行，格式固定
    A：<该成分原文，逐字取自原句>
    A 说明：<它是什么 + 词性/语法功能 + 在这句里跟谁是什么关系>
    （可选）这个成分在本剧有对应的真实台词时，紧跟着一行写：
    例句：<逐字取自上下文的本剧台词原文>
3.3 成分内部骨架：只有当某个成分内部还有结构（修饰成分、并列、介词短语、补助动词等）时才写
    B 内部骨架：X に Y ように
    X = <原文>
    X 说明：<说明>
    に说明：<助词单独解释：接在谁后面、提示什么、全句有几处这种>
    Y 说明：<说明>
    ように说明：<说明>
3.4 主句谓语：谓语如果已经是框架里的某个字母位，就不用单独写；否则单独写
    主句谓语：<原文>
    说明：<说明>

【硬性规则】
- 成分原文必须逐字取自原句，不许改写、不许换成罗马音
- 内部骨架里的助词（如 に / は / を / ので）要单独拎出来解释，一行一个
- 说明要讲「这个成分在这句里的具体作用」，不要只抄词典释义；每条 1~2 句
- 框架里没有的成分不要硬凑；句子简单就少拆几层
- 例句是**可选**的：只在能拿到能体现该要点的**本剧真实台词**时才写；拿不到就**整行不写**
      - 一旦要写，必须逐字取自上下文（refs / prev / next 里原样搬运），一个字都别改
      - 不许编造、不许改写、不许把当前句重复当例句
      - 引用例句时只写日文原文，不要加括号注音、不要加下划线、不要加英文残留
- 不需要罗马音
- 不确定的地方直说不确定，不要编造语法术语或读音
- 假名标注只作参考，App 端有标准注音时以标准注音为准`;

/* ------------------------------------------------------------------ */
/* 工具                                                                */
/* ------------------------------------------------------------------ */
/* ------------------------------------------------------------------ */
/* 音频配置（hub 各项目）                                              */
/* 🔴 为什么要这个端点：hub 的每个项目**每集只有 1 个音频节点** →
/*   节点一挂 = 完全没声音 = 必须重打 APK + 用户重新下载。
/*   这个端点让「换节点」变成「重拉一份配置」，不用重装 APK。
/* 🔴 域名必须是**永久的**（hub 站名每次发版都变）→ 放在中转里。
/* 🔴 **不烧 AI 额度**（不走 MiniMax）。
/* 🔴 改配置 = 改这里 + 重新部署（频率极低：只有换站时才换）。
/* 🔴 数据是从 hub 的 assets 里**自动提取**的（extract.py），不是手抄。 */
var AUDIO_CONFIG = JSON.parse("{\"v\":3,\"updated\":\"2026-10-23T02:30:00Z\",\"note\":\"hub 各项目的音频地址表 —— 节点失效时不用重装 APK，重新拉这个配置即可。\",\"keyRule\":\"table 型的键 = **该集在页面里被查表时用的那个键**。sakura: window.__CDN__[ep.id]（ep.id = \\\"ep01\\\"）；wakakusa: CDN_MAP[ep.id]（ep.id = \\\"ep01\\\"）。🔴 **dora 的 episodes.json 里 id 是数字（1/2/3），但它的音频文件名是 ep01.mp3** —— dora 走 base 型不需要 table；若将来改走 table，键必须用 **audio 文件名去扩展名**（ep01），不是 id。\",\"pathRule\":\"base 型的 path 是**相对 root** 的路径模板。🔴 `{n2}` 之类带数字后缀的占位符 = **按 pad 字段补零**（ama 的 {n2} 必须 2 位）。🔴 `{file}` 类型的占位符**已含扩展名**，不要再拼 ext。⇒ 每个 base 型项目都带 example 字段 —— **示例比说明更难用错**。🔴 但**「一个例子」和「一个规则」不是一回事 —— 例子只能证伪，不能定义**：客户端若照着单个 example 猜规则（以为「数字就是两位」）→ 拼出 E100.m4a → 永远没人发现。⇒ 所以 example 是**数组**，必须覆盖**跨位数**的那一集，并配 exampleRange 写明取值范围。\",\"projects\":{\"sakura\":{\"mode\":\"table\",\"valueType\":\"list\",\"table\":{\"ep01\":[\"https://f3rpiqeouy6c0.space.mcode.cn/media/ep01.m4a\"],\"ep02\":[\"https://f3rpiqeouy6c0.space.mcode.cn/media/ep02.m4a\"],\"ep03\":[\"https://f3rpiqeouy6c0.space.mcode.cn/media/ep03.m4a\"],\"ep04\":[\"https://f3rpiqeouy6c0.space.mcode.cn/media/ep04.m4a\"],\"ep05\":[\"https://f3rpiqeouy6c0.space.mcode.cn/media/ep05.m4a\"],\"ep06\":[\"https://f3rpiqeouy6c0.space.mcode.cn/media/ep06.m4a\"],\"ep07\":[\"https://f3rpiqeouy6c0.space.mcode.cn/media/ep07.m4a\"],\"ep08\":[\"https://f3rpiqeouy6c0.space.mcode.cn/media/ep08.m4a\"],\"ep09\":[\"https://f3rpiqeouy6c0.space.mcode.cn/media/ep09.m4a\"],\"ep10\":[\"https://f3rpiqeouy6c0.space.mcode.cn/media/ep10.m4a\"],\"ep11\":[\"https://f3rpiqeouy6c0.space.mcode.cn/media/ep11.m4a\"],\"ep12\":[\"https://f3rpiqeouy6c0.space.mcode.cn/media/ep12.m4a\"],\"ep13\":[\"https://f3rpiqeouy6c0.space.mcode.cn/media/ep13.m4a\"],\"ep14\":[\"https://f3rpiqeouy6c0.space.mcode.cn/media/ep14.m4a\"],\"ep15\":[\"https://5wxizdpb9tyq8.space.mcode.cn/media/ep15.m4a\"],\"ep16\":[\"https://5wxizdpb9tyq8.space.mcode.cn/media/ep16.m4a\"],\"ep17\":[\"https://5wxizdpb9tyq8.space.mcode.cn/media/ep17.m4a\"],\"ep18\":[\"https://5wxizdpb9tyq8.space.mcode.cn/media/ep18.m4a\"],\"ep19\":[\"https://5wxizdpb9tyq8.space.mcode.cn/media/ep19.m4a\"],\"ep20\":[\"https://5wxizdpb9tyq8.space.mcode.cn/media/ep20.m4a\"],\"ep21\":[\"https://5wxizdpb9tyq8.space.mcode.cn/media/ep21.m4a\"],\"ep22\":[\"https://5wxizdpb9tyq8.space.mcode.cn/media/ep22.m4a\"],\"ep23\":[\"https://5wxizdpb9tyq8.space.mcode.cn/media/ep23.m4a\"],\"ep24\":[\"https://5wxizdpb9tyq8.space.mcode.cn/media/ep24.m4a\"],\"ep25\":[\"https://5wxizdpb9tyq8.space.mcode.cn/media/ep25.m4a\"],\"ep26\":[\"https://5wxizdpb9tyq8.space.mcode.cn/media/ep26.m4a\"],\"ep27\":[\"https://5wxizdpb9tyq8.space.mcode.cn/media/ep27.m4a\"],\"ep28\":[\"https://5wxizdpb9tyq8.space.mcode.cn/media/ep28.m4a\"],\"ep29\":[\"https://bjyzdgmd6px91.space.mcode.cn/media/ep29.m4a\"],\"ep30\":[\"https://bjyzdgmd6px91.space.mcode.cn/media/ep30.m4a\"],\"ep31\":[\"https://bjyzdgmd6px91.space.mcode.cn/media/ep31.m4a\"],\"ep32\":[\"https://bjyzdgmd6px91.space.mcode.cn/media/ep32.m4a\"],\"ep33\":[\"https://bjyzdgmd6px91.space.mcode.cn/media/ep33.m4a\"],\"ep34\":[\"https://bjyzdgmd6px91.space.mcode.cn/media/ep34.m4a\"],\"ep35\":[\"https://bjyzdgmd6px91.space.mcode.cn/media/ep35.m4a\"],\"ep36\":[\"https://bjyzdgmd6px91.space.mcode.cn/media/ep36.m4a\"],\"ep37\":[\"https://bjyzdgmd6px91.space.mcode.cn/media/ep37.m4a\"],\"ep38\":[\"https://bjyzdgmd6px91.space.mcode.cn/media/ep38.m4a\"],\"ep39\":[\"https://bjyzdgmd6px91.space.mcode.cn/media/ep39.m4a\"],\"ep40\":[\"https://bjyzdgmd6px91.space.mcode.cn/media/ep40.m4a\"],\"ep41\":[\"https://bjyzdgmd6px91.space.mcode.cn/media/ep41.m4a\"],\"ep42\":[\"https://bjyzdgmd6px91.space.mcode.cn/media/ep42.m4a\"],\"ep43\":[\"https://clqvqp5j1qrqu.space.mcode.cn/media/ep43.m4a\"],\"ep44\":[\"https://clqvqp5j1qrqu.space.mcode.cn/media/ep44.m4a\"],\"ep45\":[\"https://clqvqp5j1qrqu.space.mcode.cn/media/ep45.m4a\"],\"ep46\":[\"https://clqvqp5j1qrqu.space.mcode.cn/media/ep46.m4a\"],\"ep47\":[\"https://clqvqp5j1qrqu.space.mcode.cn/media/ep47.m4a\"],\"ep48\":[\"https://clqvqp5j1qrqu.space.mcode.cn/media/ep48.m4a\"],\"ep49\":[\"https://clqvqp5j1qrqu.space.mcode.cn/media/ep49.m4a\"],\"ep50\":[\"https://clqvqp5j1qrqu.space.mcode.cn/media/ep50.m4a\"],\"ep51\":[\"https://clqvqp5j1qrqu.space.mcode.cn/media/ep51.m4a\"],\"ep52\":[\"https://clqvqp5j1qrqu.space.mcode.cn/media/ep52.m4a\"],\"ep53\":[\"https://clqvqp5j1qrqu.space.mcode.cn/media/ep53.m4a\"],\"ep54\":[\"https://clqvqp5j1qrqu.space.mcode.cn/media/ep54.m4a\"],\"ep55\":[\"https://clqvqp5j1qrqu.space.mcode.cn/media/ep55.m4a\"],\"ep56\":[\"https://clqvqp5j1qrqu.space.mcode.cn/media/ep56.m4a\"],\"ep57\":[\"https://vi57vb0da33qp.space.mcode.cn/media/ep57.m4a\"],\"ep58\":[\"https://vi57vb0da33qp.space.mcode.cn/media/ep58.m4a\"],\"ep59\":[\"https://vi57vb0da33qp.space.mcode.cn/media/ep59.m4a\"],\"ep60\":[\"https://vi57vb0da33qp.space.mcode.cn/media/ep60.m4a\"],\"ep61\":[\"https://vi57vb0da33qp.space.mcode.cn/media/ep61.m4a\"],\"ep62\":[\"https://vi57vb0da33qp.space.mcode.cn/media/ep62.m4a\"],\"ep63\":[\"https://vi57vb0da33qp.space.mcode.cn/media/ep63.m4a\"],\"ep64\":[\"https://vi57vb0da33qp.space.mcode.cn/media/ep64.m4a\"],\"ep65\":[\"https://vi57vb0da33qp.space.mcode.cn/media/ep65.m4a\"],\"ep66\":[\"https://vi57vb0da33qp.space.mcode.cn/media/ep66.m4a\"],\"ep67\":[\"https://vi57vb0da33qp.space.mcode.cn/media/ep67.m4a\"],\"ep68\":[\"https://vi57vb0da33qp.space.mcode.cn/media/ep68.m4a\"],\"ep69\":[\"https://vi57vb0da33qp.space.mcode.cn/media/ep69.m4a\"],\"ep70\":[\"https://vi57vb0da33qp.space.mcode.cn/media/ep70.m4a\"]}},\"wakakusa\":{\"mode\":\"table\",\"valueType\":\"single\",\"table\":{\"ep01\":\"https://4535p9s0wnpzs.space.mcode.cn/audio/ep01.m4a\",\"ep02\":\"https://4535p9s0wnpzs.space.mcode.cn/audio/ep02.m4a\",\"ep03\":\"https://4535p9s0wnpzs.space.mcode.cn/audio/ep03.m4a\",\"ep04\":\"https://4535p9s0wnpzs.space.mcode.cn/audio/ep04.m4a\",\"ep05\":\"https://4535p9s0wnpzs.space.mcode.cn/audio/ep05.m4a\",\"ep06\":\"https://4535p9s0wnpzs.space.mcode.cn/audio/ep06.m4a\",\"ep07\":\"https://4535p9s0wnpzs.space.mcode.cn/audio/ep07.m4a\",\"ep08\":\"https://4535p9s0wnpzs.space.mcode.cn/audio/ep08.m4a\",\"ep09\":\"https://4535p9s0wnpzs.space.mcode.cn/audio/ep09.m4a\",\"ep10\":\"https://4535p9s0wnpzs.space.mcode.cn/audio/ep10.m4a\",\"ep11\":\"https://4535p9s0wnpzs.space.mcode.cn/audio/ep11.m4a\",\"ep12\":\"https://4535p9s0wnpzs.space.mcode.cn/audio/ep12.m4a\",\"ep13\":\"https://4535p9s0wnpzs.space.mcode.cn/audio/ep13.m4a\",\"ep14\":\"https://4535p9s0wnpzs.space.mcode.cn/audio/ep14.m4a\",\"ep15\":\"https://lem5lvwy41rn9.space.mcode.cn/audio/ep15.m4a\",\"ep16\":\"https://lem5lvwy41rn9.space.mcode.cn/audio/ep16.m4a\",\"ep17\":\"https://lem5lvwy41rn9.space.mcode.cn/audio/ep17.m4a\",\"ep18\":\"https://lem5lvwy41rn9.space.mcode.cn/audio/ep18.m4a\",\"ep19\":\"https://lem5lvwy41rn9.space.mcode.cn/audio/ep19.m4a\",\"ep20\":\"https://lem5lvwy41rn9.space.mcode.cn/audio/ep20.m4a\",\"ep21\":\"https://lem5lvwy41rn9.space.mcode.cn/audio/ep21.m4a\",\"ep22\":\"https://lem5lvwy41rn9.space.mcode.cn/audio/ep22.m4a\",\"ep23\":\"https://lem5lvwy41rn9.space.mcode.cn/audio/ep23.m4a\",\"ep24\":\"https://lem5lvwy41rn9.space.mcode.cn/audio/ep24.m4a\",\"ep25\":\"https://lem5lvwy41rn9.space.mcode.cn/audio/ep25.m4a\",\"ep26\":\"https://lem5lvwy41rn9.space.mcode.cn/audio/ep26.m4a\",\"ep27\":\"https://lem5lvwy41rn9.space.mcode.cn/audio/ep27.m4a\",\"ep28\":\"https://lem5lvwy41rn9.space.mcode.cn/audio/ep28.m4a\",\"ep29\":\"https://wn1nwme4cg1hh.space.mcode.cn/audio/ep29.m4a\",\"ep30\":\"https://wn1nwme4cg1hh.space.mcode.cn/audio/ep30.m4a\",\"ep31\":\"https://wn1nwme4cg1hh.space.mcode.cn/audio/ep31.m4a\",\"ep32\":\"https://wn1nwme4cg1hh.space.mcode.cn/audio/ep32.m4a\",\"ep33\":\"https://wn1nwme4cg1hh.space.mcode.cn/audio/ep33.m4a\",\"ep34\":\"https://wn1nwme4cg1hh.space.mcode.cn/audio/ep34.m4a\",\"ep35\":\"https://wn1nwme4cg1hh.space.mcode.cn/audio/ep35.m4a\",\"ep36\":\"https://wn1nwme4cg1hh.space.mcode.cn/audio/ep36.m4a\",\"ep37\":\"https://wn1nwme4cg1hh.space.mcode.cn/audio/ep37.m4a\",\"ep38\":\"https://wn1nwme4cg1hh.space.mcode.cn/audio/ep38.m4a\",\"ep39\":\"https://wn1nwme4cg1hh.space.mcode.cn/audio/ep39.m4a\",\"ep40\":\"https://wn1nwme4cg1hh.space.mcode.cn/audio/ep40.m4a\"}},\"dora\":{\"mode\":\"base\",\"root\":\"https://9kgu879p4dhy2.space.mcode.cn\",\"path\":\"/audio/{file}\",\"example\":[{\"file\":\"ep01.mp3\",\"url\":\"https://9kgu879p4dhy2.space.mcode.cn/audio/ep01.mp3\"}],\"exampleRange\":{\"min\":1,\"max\":7,\"note\":\"{file} 已含扩展名，不要再拼 ext\"},\"sample\":{\"ep01\":\"ep01.mp3\",\"ep02\":\"ep02.mp3\"}},\"ama\":{\"mode\":\"base\",\"root\":\"https://tcw0ti0k7p0hd.space.mcode.cn\",\"path\":\"/audio/E{n2}.m4a\",\"pad\":{\"n2\":2},\"example\":[{\"n2\":1,\"url\":\"https://tcw0ti0k7p0hd.space.mcode.cn/audio/E01.m4a\"},{\"n2\":9,\"url\":\"https://tcw0ti0k7p0hd.space.mcode.cn/audio/E09.m4a\"},{\"n2\":10,\"url\":\"https://tcw0ti0k7p0hd.space.mcode.cn/audio/E10.m4a\"}],\"exampleRange\":{\"min\":1,\"max\":12,\"note\":\"本项目共 12 集；1~9 与 10~12 均为 2 位（补零到 2 位）\"}},\"pony\":{\"mode\":\"base\",\"root\":\"https://3vpcud2aabhor.space.mcode.cn\",\"path\":\"/media/{tag}.m4a\",\"example\":[{\"tag\":\"ep01\",\"url\":\"https://3vpcud2aabhor.space.mcode.cn/media/ep01.m4a\"}]},\"tadoku\":{\"mode\":\"base\",\"root\":\"https://zyksozpp1p7i0.space.mcode.cn\",\"path\":\"/media/{tag}.mp3\",\"example\":[{\"tag\":\"ep01\",\"url\":\"https://zyksozpp1p7i0.space.mcode.cn/media/ep01.mp3\"}]}}}");

function corsHeaders() {
  return {
    'Content-Type': 'application/json; charset=utf-8',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type,Authorization',
    'Access-Control-Allow-Methods': 'POST,OPTIONS,GET',
    'Access-Control-Max-Age': '86400',
  };
}

function reply(statusCode, obj) {
  return {
    statusCode: statusCode,
    headers: corsHeaders(),
    body: JSON.stringify(obj),
    isBase64Encoded: false,
  };
}

function clean(s, max) {
  if (s === null || s === undefined) return '';
  let t = String(s).replace(/\s+/g, ' ').trim();
  if (max && t.length > max) t = t.slice(0, max);
  return t;
}

function pickJa(x) {
  if (!x) return '';
  if (typeof x === 'string') return clean(x, 200);
  return clean(x.ja || x.jp || x.text || '', 200);
}

function pickZh(x) {
  if (!x) return '';
  if (typeof x === 'string') return clean(x, 200);
  return clean(x.zh || x.cn || x.trans || '', 200);
}

function arr(v, max) {
  if (!Array.isArray(v)) return [];
  return v.slice(0, max || 8).map(function (x) {
    return { ja: pickJa(x), zh: pickZh(x) };
  }).filter(function (x) { return x.ja; });
}

/* ------------------------------------------------------------------ */
/* 拼 USER 消息                                                        */
/* ------------------------------------------------------------------ */
function buildUserMessage(body) {
  const lines = [];
  lines.push('剧名：' + (clean(body.title, 60) || '（未指定）'));
  if (body.episode) lines.push('集数：' + clean(body.episode, 40));
  lines.push('');

  const scene = body.scene === 'explain_word' ? 'explain_word' : 'explain_sentence';
  if (scene === 'explain_word' && clean(body.word, 40)) {
    lines.push('★ 本次要重点讲解的词：' + clean(body.word, 40));
    lines.push('（仍然按五段结构输出，但「逐词拆解」和「语法说明」要围绕这个词展开）');
    lines.push('');
  }

  const prev = arr(body.prev, 4);
  const next = arr(body.next, 4);

  lines.push('【上下文】');
  if (prev.length) {
    lines.push('--- 上一句 ---');
    prev.forEach(function (p) { lines.push(p.ja + (p.zh ? '　' + p.zh : '')); });
  }
  lines.push('--- 当前句（要解析的）---');
  lines.push(clean(body.ja, 300) + (clean(body.zh, 300) ? '　' + clean(body.zh, 300) : ''));
  if (next.length) {
    lines.push('--- 下一句 ---');
    next.forEach(function (p) { lines.push(p.ja + (p.zh ? '　' + p.zh : '')); });
  }
  lines.push('');

  const refs = arr(body.refs, 6);
  if (refs.length) {
    lines.push('【本剧台词参考（用来造例句，优先用这里的原句，不要自己编）】');
    refs.forEach(function (r) { lines.push('- ' + r.ja + (r.zh ? '（' + r.zh + '）' : '')); });
    lines.push('');
  }

  return lines.join('\n');
}

/* ------------------------------------------------------------------ */
/* 调 MiniMax                                                          */
/* ------------------------------------------------------------------ */
function thinkingField() {
  switch (String(CFG.thinking).toLowerCase()) {
    case 'disabled': return { thinking: { type: 'disabled' } };
    case 'enabled':  return { thinking: { type: 'enabled' } };
    case 'adaptive': return { thinking: { type: 'adaptive' } };
    case 'none':     return {};
    default:         return { thinking: { type: 'disabled' } };
  }
}

function callMiniMax(userMsg) {
  return new Promise(function (resolve, reject) {
    const payloadObj = {
      model: CFG.model,
      messages: [
        { role: 'system', content: SYSTEM_PROMPT },
        { role: 'user', content: userMsg }
      ],
      max_completion_tokens: CFG.maxTokens,
      temperature: 0.3
    };
    Object.assign(payloadObj, thinkingField());
    const payload = JSON.stringify(payloadObj);

    /* ⚠️ 绝对不要用 new URL()：
       CloudBase 的 Node 沙箱里没有全局 URL（ReferenceError: URL is not defined），
       而本地 Node 有 → 本地测全绿、线上必挂。改成纯字符串解析。 */
    const fullUrl = CFG.baseUrl + '/chat/completions';
    const um = /^(https?):\/\/([^/:?#]+)(?::(\d+))?([^?#]*)(\?[^#]*)?/.exec(fullUrl);
    if (!um) return reject(new Error('bad_base_url:' + fullUrl));
    const req = https.request({
      hostname: um[2],
      port: um[3] ? parseInt(um[3], 10) : 443,
      path: (um[4] || '/') + (um[5] || ''),
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(payload),
        'Authorization': 'Bearer ' + CFG.apiKey
      },
      timeout: CFG.timeoutMs
    }, function (res) {
      let buf = '';
      res.setEncoding('utf8');
      res.on('data', function (d) { buf += d; });
      res.on('end', function () {
        if (res.statusCode !== 200) {
          return reject(new Error('upstream_' + res.statusCode + ':' + buf.slice(0, 300)));
        }
        let j;
        try { j = JSON.parse(buf); } catch (e) { return reject(new Error('bad_upstream_json')); }
        if (j.base_resp && j.base_resp.status_code && j.base_resp.status_code !== 0) {
          return reject(new Error('upstream_biz:' + JSON.stringify(j.base_resp)));
        }
        const text = j.choices && j.choices[0] && j.choices[0].message
          ? (j.choices[0].message.content || '')
          : '';
        if (!text) return reject(new Error('empty_upstream_text'));
        resolve(text);
      });
    });

    req.on('timeout', function () { req.destroy(new Error('timeout')); });
    req.on('error', function (e) { reject(e); });
    req.write(payload);
    req.end();
  });
}

/* ------------------------------------------------------------------ */
/* 真·额度查询（MiniMax Token Plan 官方接口）                          */
/*   GET {baseUrl}/token_plan/remains                                   */
/*   → 5h 窗口剩余 % / 周窗口剩余 % / 重置倒计时                        */
/*   这是「真信号」—— 比内存计数靠谱得多                                */
/* ------------------------------------------------------------------ */
let QUOTA_CACHE = null;
let QUOTA_AT = 0;

function httpGetJson(url, headers) {
  return new Promise(function (resolve, reject) {
    const um = /^(https?):\/\/([^/:?#]+)(?::(\d+))?([^?#]*)(\?[^#]*)?/.exec(url);
    if (!um) return reject(new Error('bad_url'));
    const req = https.request({
      hostname: um[2],
      port: um[3] ? parseInt(um[3], 10) : 443,
      path: (um[4] || '/') + (um[5] || ''),
      method: 'GET',
      headers: headers || {},
      timeout: 15000
    }, function (res) {
      let buf = '';
      res.setEncoding('utf8');
      res.on('data', function (d) { buf += d; });
      res.on('end', function () {
        if (res.statusCode !== 200) return reject(new Error('quota_http_' + res.statusCode));
        try { resolve(JSON.parse(buf)); } catch (e) { reject(new Error('quota_bad_json')); }
      });
    });
    req.on('timeout', function () { req.destroy(new Error('quota_timeout')); });
    req.on('error', function (e) { reject(e); });
    req.end();
  });
}

async function getQuota(force) {
  const now = Date.now();
  if (!force && QUOTA_CACHE && (now - QUOTA_AT) < 60000) return QUOTA_CACHE;
  const j = await httpGetJson(CFG.baseUrl + '/token_plan/remains', {
    'Authorization': 'Bearer ' + CFG.apiKey,
    'Content-Type': 'application/json'
  });
  const br = j.base_resp || {};
  if (br.status_code && br.status_code !== 0) {
    throw new Error('quota_err:' + br.status_code + ' ' + (br.status_msg || ''));
  }
  const m = (j.model_remains && j.model_remains[0]) || {};
  QUOTA_CACHE = {
    interval_percent: m.current_interval_remaining_percent,
    weekly_percent: m.current_weekly_remaining_percent,
    interval_reset_in_ms: m.remains_time,
    weekly_reset_in_ms: m.weekly_remains_time,
    interval_status: m.current_interval_status,
    weekly_status: m.current_weekly_status
  };
  QUOTA_AT = now;
  return QUOTA_CACHE;
}

/* ------------------------------------------------------------------ */
/* 核心处理                                                            */
/* ------------------------------------------------------------------ */
async function handle(event) {
  const raw = (event && event.body !== undefined && event.body !== null) ? event.body : event;
  const method = String((event && event.httpMethod) || 'POST').toUpperCase();

  /* CORS 预检 */
  if (method === 'OPTIONS') return reply(204, { ok: true });

  /* ==========================================================================
   * 🔴 听力记录站：教师侧特权端点 /vocab-ops（2026-10-24 加）
   * ----------------------------------------------------------------------
   * 为什么加在**现役函数**里、而不是新建一个云函数：
   *   · 新建函数会丢 HTTP 触发器 + 环境变量（MM_API_KEY 那次踩过）⇒ 只能加在现役函数上
   *   · 上传 zip = 整份替换函数代码 ⇒ 这份 zip 必须以**现役 index.js** 为基底
   *   · 本端点**不碰 MiniMax**（不烧额度、不用 AI_TOKEN）⇒ 不影响现役三条路由
   *
   * 🔴 路由识别**不能只看 path**：网关可能把前缀剥掉
   *   （现役 https://…service.tcloudbase.com/ai 进来时 event.path 可能是 '/'）
   *   ⇒ 双重判据：① path 里含 '/vocab-ops'
   *                 ② 请求体的 action 是本端点约定的三个之一
   *   ⇒ AI 端点的请求体是 {scene, ja, zh…} ⇒ 没有 action 字段 ⇒ 绝不会误判
   * ======================================================================= */
  {
    let __act = '';
    try {
      const __raw0 = (event && event.body !== undefined && event.body !== null) ? event.body : event;
      const __o0 = (typeof __raw0 === 'string') ? JSON.parse(__raw0) : __raw0;
      if (__o0 && typeof __o0 === 'object') __act = String(__o0.action || '');
    } catch (e) { __act = ''; }
    const __p0 = String((event && event.path) || '');
    if (__p0.indexOf('/vocab-ops') >= 0 ||
        __act === 'ping' || __act === 'delete_log' || __act === 'clear_class') {
      return require('./vocab_ops').handleVocabOps(event);
    }
  }

  /* 健康检查 */
  if (method === 'GET') {
    const gp = String((event && event.path) || '');
    /* 🔴 GET /prompt —— 让前端能拉到**本函数正在用的那份** SYSTEM_PROMPT 原文。
     *   为什么要有这个：
     *     中转和前端的 prompt 必须**逐字一致**（复制提问模式要跟真接口同结果，
     *     测试也要断言两端相同）。以前靠手抄/复制粘贴同步 → 迟早漂。
     *   现在：**从线上函数拉原文** → 脚本化替换 → 逐字 diff → 漂不了。
     *   🔴 prompt 里**不含任何密钥**，公开可读是安全的。 */
    if (gp.indexOf('prompt') >= 0) {
      return reply(200, {
        ok: true,
        prompt: SYSTEM_PROMPT,
        prompt_sha: promptSha(),
        prompt_len: SYSTEM_PROMPT.length
      });
    }
    /* 🔴🔴 GET /audio-config —— hub 各项目的音频地址表（2026-10-23 加，pony 提的方案）
     *   为什么放在中转：需要一个**永久域名**（hub 站名每次发版都变，不能编进 APK）；
     *   中转的 `vocab-test-….service.tcloudbase.com` 是目前唯一的永久域名。
     *   🔴 不烧 AI 额度、🔴 不含密钥 → 公开可读是安全的。
     *   🔴 契约：
     *     { v, updated, projects: {
     *         <project>: { mode:'table', table:{ <集key>: [url, ...] } }   // 每集独立表
     *         <project>: { mode:'base', base:'https://…/', ext:'.m4a', prefix? }  // base+固定后缀
     *     } }
     *   🔴 前端用法：**只在「当前域名连不上」时才拉**（用户流量敏感）→ 拉不到就用 APK 里的本地表。
     *   🔴 拉到了但没有某项目 → 该项目继续用本地表（不覆盖）。 */
    if (gp.indexOf('audio-config') >= 0) {
      return reply(200, Object.assign({ ok: true }, AUDIO_CONFIG));
    }
    if (gp.indexOf('quota') >= 0) {
      if (!CFG.apiKey) return reply(503, { ok: false, error: 'not_configured' });
      try {
        return reply(200, { ok: true, quota: await getQuota(true) });
      } catch (e) {
        console.error('[ai-proxy] quota fail ' + ((e && e.message) || 'unknown'));
        return reply(502, { ok: false, error: 'upstream_error' });
      }
    }
    return reply(200, {
      ok: true, service: 'ai-proxy', model: CFG.model,
      thinking: CFG.thinking, configured: !!CFG.apiKey
    });
  }

  /* 没有 key → 明确告诉前端「未配置」 */
  if (!CFG.apiKey) return reply(503, { ok: false, error: 'not_configured' });

  /* 可选的访问令牌校验 */
  if (CFG.token) {
    const hdr = (event && event.headers) || {};
    let auth = '';
    for (const k in hdr) {
      if (k.toLowerCase() === 'authorization') { auth = hdr[k]; break; }
    }
    const got = String(auth || '').replace(/^Bearer\s+/i, '').trim();
    if (got !== CFG.token) return reply(401, { ok: false, error: 'unauthorized' });
  }

  /* 🔴 真限流：查 MiniMax 真实额度（周窗口剩余太低就劝退）
     查不到额度时放行 —— 不能因为额度接口挂了就让整个服务不可用 */
  CALLS += 1;
  /* 🔴 真限流只看 MiniMax 真实额度（周窗口剩余低于阈值就劝退）
     ⚠️ 不再用内存计数做拦截 —— 那个阈值冷启动就重置，拦不住任何东西，
        还会让「今天用得有点多」这种文案误导用户（实际触发的是周窗口）。 */
  try {
    const q = await getQuota(false);
    if (typeof q.weekly_percent === 'number' && q.weekly_percent <= CFG.weeklyStopPct) {
      console.log('[ai-proxy] blocked too_many weekly=' + q.weekly_percent + '%');
      return reply(429, { ok: false, error: 'too_many', quota: q });
    }
    console.log('[ai-proxy] call#' + CALLS + ' weekly=' + q.weekly_percent + '% 5h=' + q.interval_percent + '%');
  } catch (e) {
    console.error('[ai-proxy] quota check skipped: ' + ((e && e.message) || 'unknown'));
  }

  /* 解析请求体 */
  let data = raw;
  if (typeof data === 'string') {
    try { data = JSON.parse(data); } catch (e) { return reply(400, { ok: false, error: 'bad_request' }); }
  }
  if (!data || typeof data !== 'object') return reply(400, { ok: false, error: 'bad_request' });

  const ja = clean(data.ja, 300);
  if (!ja) return reply(400, { ok: false, error: 'bad_request' });

  const userMsg = buildUserMessage(data);

  try {
    const text = await callMiniMax(userMsg);
    console.log('[ai-proxy] ok model=' + CFG.model + ' len=' + text.length);
    return reply(200, { ok: true, text: text });
  } catch (e) {
    const msg = (e && e.message) || 'unknown';
    console.error('[ai-proxy] fail ' + msg + ' | code=' + (e && e.code) + ' | stack=' + String((e && e.stack) || '').split('\n').slice(0,3).join(' / '));
    if (msg === 'timeout') return reply(504, { ok: false, error: 'timeout' });
    if (msg.indexOf('upstream_401') >= 0 || msg.indexOf('2049') >= 0) {
      return reply(502, { ok: false, error: 'upstream_auth' });
    }
    if (msg.indexOf('2013') >= 0) {
      // 参数不合法（例如 M3.1-Flash 不允许关思考）
      return reply(502, { ok: false, error: 'upstream_params' });
    }
    if (msg.indexOf('2056') >= 0) {
      return reply(429, { ok: false, error: 'quota_exceeded' });
    }
    return reply(502, { ok: false, error: 'upstream_error' });
  }
}

/* ------------------------------------------------------------------ */
/* 模式 A：普通云函数（exports.main）                                   */
/* ------------------------------------------------------------------ */
let MAIN_CALLED = false;
exports.main = async function (event, context) {
  MAIN_CALLED = true;
  /* 如果是 Web 框架模式误走了这里 → 关掉 http server，让它退出 */
  if (server) {
    try { server.close(); } catch (e) { /* ignore */ }
    server = null;
  }
  return handle(event);
};

/* ------------------------------------------------------------------ */
/* 模式 B：Web 框架云函数（scf_bootstrap require 本文件 → 起 http server） */
/* ------------------------------------------------------------------ */
let server = null;
try {
  server = http.createServer(function (req, res) {
    let body = '';
    /* 🔴 必须 setEncoding('utf8')：Buffer 隐式 toString 是**按 chunk 边界**解码的，
     *   多字节字符（假名/汉字）正好被切在两个 chunk 之间时 → 那个字变 U+FFFD 乱码，
     *   用户那句日语就被静默改了一个字。setEncoding 用 StringDecoder，跨 chunk 正确。 */
    req.setEncoding('utf8');
    req.on('data', function (c) { body += c; });
    req.on('end', function () {
      let parsed = {};
      try { parsed = body ? JSON.parse(body) : {}; } catch (e) { parsed = {}; }
      handle({ httpMethod: req.method, headers: req.headers, body: parsed, path: req.url })
        .then(function (r) {
          res.writeHead(r.statusCode, r.headers);
          res.end(r.body);
        })
        .catch(function (e) {
          console.error('[ai-proxy] http err ' + (e && e.message));
          res.writeHead(500, corsHeaders());
          res.end(JSON.stringify({ ok: false, error: 'server_error' }));
        });
    });
  });
  server.on('error', function (e) {
    console.log('[ai-proxy] http server not started (' + (e && e.message) + ') — 走 exports.main 模式');
    server = null;
  });
  /* 🔴 延迟 400ms 再 bind 9000：
     万一 scf_bootstrap 走的是 Functions Framework（它自己也会 bind 9000），
     让它先占住端口 → 我们 EADDRINUSE → 自动退回 exports.main 模式。
     反过来若我们先占住，框架 bind 失败整个函数就废了。 */
  setTimeout(function () {
    if (MAIN_CALLED) {
      console.log('[ai-proxy] exports.main 模式（框架已接管端口），不起 http server');
      try { server.close(); } catch (e) { /* ignore */ }
      server = null;
      return;
    }
    server.listen(process.env.PORT || 9000, '0.0.0.0', function () {
      console.log('[ai-proxy] web server on :' + (process.env.PORT || 9000));
    });
  }, 400);
} catch (e) {
  console.log('[ai-proxy] http server unavailable — 走 exports.main 模式');
  server = null;
}
