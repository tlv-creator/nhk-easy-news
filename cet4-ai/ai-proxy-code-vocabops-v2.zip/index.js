/**
 * AI 讲解中转 · CloudBase 云函数
 * ------------------------------------------------------------------
 * 作用：保管 MiniMax Subscription Key，把前端的请求转成 MiniMax 调用，
 *       再把结果按固定契约返回。前端永远不接触 key。
 *
 * ✅ 双模式自动适配（同一个文件，两种创建方式都能跑）：
 *   A)「HTTP Node.js Hello World」模板（Web 框架型）→ 自动起 http server 监听 9000
 *   B) 普通云函数 + HTTP 触发器 → 走 exports.main
 *   判别逻辑：exports.main 被调用时会关掉 http server 并直接返回；
 *              Web 框架模式下 scf_bootstrap 只会 require 本文件，走 server 路由。
 *
 * 契约（前端只认这个，字段名别改）：
 *   POST /
 *   {
 *     "scene": "explain_sentence" | "explain_word",
 *     "title": "剧名", "episode": "第 N 话",
 *     "ja": "当前句", "zh": "当前句中文",
 *     "prev": [{ja,zh},...], "next": [{ja,zh},...],
 *     "word": "用户点的词（可空字符串）",
 *     "refs": [{ja,zh},...]      // 本剧真实台词，用来造例句
 *   }
 *   200 -> { "ok": true, "text": "Markdown 全文" }
 *   4xx/5xx -> { "ok": false, "error": "not_configured|too_many|bad_request|upstream_error|timeout" }
 *
 * 环境变量（在 CloudBase 控制台 → 函数配置 → 环境变量里配）：
 *   MM_API_KEY      必填。MiniMax **Subscription Key**（sk-cp- 开头）
 *   MM_BASE_URL     选填。默认 https://api.minimaxi.com/v1  （国内站）
 *                   国际站改成 https://api.minimax.io/v1
 *   MM_MODEL        选填。默认 MiniMax-M3
 *   MM_THINKING     选填。默认 disabled（关思考，快）
 *                   ⚠️ MiniMax-M3.1-Flash 必须用 adaptive，否则接口报 2013
 *   AI_TOKEN        选填。设了就在环境变量里填同一个值，不一致直接 401
 *   MM_TIMEOUT_MS   选填。默认 60000
 *   MM_MAX_TOKENS   选填。默认 2000
 *   AI_WEEKLY_STOP_PCT 选填。默认 20（周窗口剩余低于这个百分比就返回 too_many）
 *
 *   ⚠️ 曾有个 AI_DAILY_CAP（单实例内存计数）—— **已废弃、不生效**。
 *      真正的限流只看官方周窗口（weeklyStopPct），别再被它误导。
 */

'use strict';
/*__VOCAB_OPS_BEGIN_1*/
/*__VOCAB_OPS_BEGIN_1*/
/* 🔴 教师侧特权写端点模块（每日听力记录站「删一条 / 清空全部」）
 *   ⚠️ 独立模块，与 ai-proxy 的 AI 讲解逻辑完全无关。
 *   ⚠️ service_role key **只从环境变量读**（SB_URL / SB_SERVICE_ROLE）
 *      ⇒ 绝不在本文件、绝不在任何 zip 里出现真 key。
 *   ⚠️ service_role **绕过 RLS** ⇒ 老师口令摘要校验是唯一防线
 *      ⇒ 校验不过必须一行都不删（模块内部已保证）。
 */
const __VOCAB_OPS_MOD__ = require('./vocab_ops');

/* 路径判定：兼容 CloudBase HTTP 触发的几种 event 形状
 *   ⚠️ 与 vocab_ops.js 内部的 pickPath 同口径
 *   ⚠️ 同时支持 /vocab-ops（直连函数域名）与 /ai/vocab-ops（自定义域名 + 网关路由）
 *      —— 网关只映射 /ai 前缀 ⇒ 自定义域名下必须走 /ai/vocab-ops
 */
function __vocabOpsPath(event) {
  var cands = [
    event && event.path,
    event && event.rawPath,
    event && event.requestContext && event.requestContext.http && event.requestContext.http.path,
    event && event.requestContext && event.requestContext.path,
    event && event.headers && (event.headers['x-tcb-path'] || event.headers['X-Tcb-Path'])
  ];
  for (var i = 0; i < cands.length; i++) {
    if (cands[i] && String(cands[i]).indexOf('/vocab-ops') >= 0) return true;
  }
  return false;
}
/*__VOCAB_OPS_END_1*//*__VOCAB_OPS_END_1*/


const https = require('https');
const http = require('http');
const crypto = require('crypto');

/* prompt 指纹：前端拿它跟本地那份对比 → 不一致就说明该同步了 */
function promptSha() {
  return crypto.createHash('sha256').update(SYSTEM_PROMPT, 'utf8').digest('hex');
}

/* ------------------------------------------------------------------ */
/* 配置                                                                */
/* ------------------------------------------------------------------ */

/* ================================================================
   🔴 备用口子：如果你在 CloudBase 控制台里找不到「环境变量」的入口，
      就把下面这行引号里填上你的 key（只填 sk-cp-... 那一串本身，
      不要加别的字），然后保存部署即可。

      例：const MM_KEY_HERE = 'sk-cp-xxxxxxxxxxxxxxxx';
   ================================================================ */
const MM_KEY_HERE = '';

const CFG = {
  baseUrl: (process.env.MM_BASE_URL || 'https://api.minimaxi.com/v1').replace(/\/+$/, ''),
  apiKey: process.env.MM_API_KEY || MM_KEY_HERE || '',
  model: process.env.MM_MODEL || 'MiniMax-M3',
  thinking: process.env.MM_THINKING || 'disabled',
  timeoutMs: parseInt(process.env.MM_TIMEOUT_MS || '60000', 10),
  maxTokens: parseInt(process.env.MM_MAX_TOKENS || '2000', 10),
  token: process.env.AI_TOKEN || '',
  /* 🔴 真限流：MiniMax 周窗口剩余低于这个百分比就返回 too_many */
  weeklyStopPct: parseInt(process.env.AI_WEEKLY_STOP_PCT || '20', 10),
};

/* 只是日志里的调用计数（冷启动会重置）——**不是限流器**，别拿它当配额 */
let CALLS = 0;

/* ------------------------------------------------------------------ */
/* SYSTEM PROMPT —— 用户亲自定稿，别改格式，只在必要时微调措辞          */
/* ------------------------------------------------------------------ */
const SYSTEM_PROMPT = `【角色】
你是日语老师，给中文母语的学习者讲日语。讲解用中文；日语语法术语第一次出现时写成「中文（日本語用語）」双写。

【任务】
解析用户给你的一句日语台词（可能附带上下文）。严格按下面固定结构输出：不要寒暄、不要复述题目、不要用 emoji、不要自由发挥。

【输出结构（顺序固定）】
1. 原文：日语文本，汉字后用括号注假名（例：元気（げんき））
2. 中文翻译
3. 句子结构剖析

【句子结构剖析的固定写法】
3.1 整体大框架：只写一行，成分用字母标记（从 A 开始按出现顺序），被包住的部分用【】括起来。
    格式：A は 【B】 言っています
3.2 成分展开：每个成分写两行，格式固定
    A：<该成分原文，逐字取自原句>
    A 说明：<它是什么 + 词性/语法功能 + 在这句里跟谁是什么关系>
    （可选）这个成分在本剧有对应的真实台词时，紧跟着一行写：
    例句：<逐字取自上下文的本剧台词原文>
3.3 成分内部骨架：只有当某个成分内部还有结构（修饰成分、并列、介词短语、补助动词等）时才写
    B 内部骨架：X に Y ように
    X = <原文>
    X 说明：<说明>
    に说明：<助词单独解释：接在谁后面、提示什么、全句有几处这种>
    Y 说明：<说明>
    ように说明：<说明>
3.4 主句谓语：谓语如果已经是框架里的某个字母位，就不用单独写；否则单独写
    主句谓语：<原文>
    说明：<说明>

【硬性规则】
- 成分原文必须逐字取自原句，不许改写、不许换成罗马音
- 内部骨架里的助词（如 に / は / を / ので）要单独拎出来解释，一行一个
- 说明要讲「这个成分在这句里的具体作用」，不要只抄词典释义；每条 1~2 句
- 框架里没有的成分不要硬凑；句子简单就少拆几层
- 例句是**可选**的：只在能拿到能体现该要点的**本剧真实台词**时才写；拿不到就**整行不写**
      - 一旦要写，必须逐字取自上下文（refs / prev / next 里原样搬运），一个字都别改
      - 不许编造、不许改写、不许把当前句重复当例句
      - 引用例句时只写日文原文，不要加括号注音、不要加下划线、不要加英文残留
- 不需要罗马音
- 不确定的地方直说不确定，不要编造语法术语或读音
- 假名标注只作参考，App 端有标准注音时以标准注音为准`;

/* ------------------------------------------------------------------ */
/* 工具                                                                */
/* ------------------------------------------------------------------ */
/* ------------------------------------------------------------------ */
/* 音频配置（hub 各项目）                                              */
/* 🔴 为什么要这个端点：hub 的每个项目**每集只有 1 个音频节点** →
/*   节点一挂 = 完全没声音 = 必须重打 APK + 用户重新下载。
/*   这个端点让「换节点」变成「重拉一份配置」，不用重装 APK。
/* 🔴 域名必须是**永久的**（hub 站名每次发版都变）→ 放在中转里。
/* 🔴 **不烧 AI 额度**（不走 MiniMax）。
/* 🔴 改配置 = 改这里 + 重新部署（频率极低：只有换站时才换）。
/* 🔴 数据是从 hub 的 assets 里**自动提取**的（extract.py），不是手抄。 */
var AUDIO_CONFIG = JSON.parse("{\"v\":3,\"updated\":\"2026-10-23T02:30:00Z\",\"note\":\"hub 各项目的音频地址表 —— 节点失效时不用重装 APK，重新拉这个配置即可。\",\"keyRule\":\"table 型的键 = **该集在页面里被查表时用的那个键**。sakura: window.__CDN__[ep.id]（ep.id = \\\"ep01\\\"）；wakakusa: CDN_MAP[ep.id]（ep.id = \\\"ep01\\\"）。🔴 **dora 的 episodes.json 里 id 是数字（1/2/3），但它的音频文件名是 ep01.mp3** —— dora 走 base 型不需要 table；若将来改走 table，键必须用 **audio 文件名去扩展名**（ep01），不是 id。\",\"pathRule\":\"base 型的 path 是**相对 root** 的路径模板。🔴 `{n2}` 之类带数字后缀的占位符 = **按 pad 字段补零**（ama 的 {n2} 必须 2 位）。🔴 `{file}` 类型的占位符**已含扩展名**，不要再拼 ext。⇒ 每个 base 型项目都带 example 字段 —— **示例比说明更难用错**。🔴 但**「一个例子」和「一个规则」不是一回事 —— 例子只能证伪，不能定义**：客户端若照着单个 example 猜规则（以为「数字就是两位」）→ 拼出 E100.m4a → 永远没人发现。⇒ 所以 example 是**数组**，必须覆盖**跨位数**的那一集，并配 exampleRange 写明取值范围。\",\"projects\":{\"sakura\":{\"mode\":\"table\",\"valueType\":\"list\",\"table\":{\"ep01\":[\"https://f3rpiqeouy6c0.space.mcode.cn/media/ep01.m4a\"],\"ep02\":[\"https://f3rpiqeouy6c0.space.mcode.cn/media/ep02.m4a\"],\"ep03\":[\"https://f3rpiqeouy6c0.space.mcode.cn/media/ep03.m4a\"],\"ep04\":[\"https://f3rpiqeouy6c0.space.mcode.cn/media/ep04.m4a\"],\"ep05\":[\"https://f3rpiqeouy6c0.space.mcode.cn/media/ep05.m4a\"],\"ep06\":[\"https://f3rpiqeouy6c0.space.mcode.cn/media/ep06.m4a\"],\"ep07\":[\"https://f3rpiqeouy6c0.space.mcode.cn/media/ep07.m4a\"],\"ep08\":[\"https://f3rpiqeouy6c0.space.mcode.cn/media/ep08.m4a\"],\"ep09\":[\"https://f3rpiqeouy6c0.space.mcode.cn/media/ep09.m4a\"],\"ep10\":[\"https://f3rpiqeouy6c0.space.mcode.cn/media/ep10.m4a\"],\"ep11\":[\"https://f3rpiqeouy6c0.space.mcode.cn/media/ep11.m4a\"],\"ep12\":[\"https://f3rpiqeouy6c0.space.mcode.cn/media/ep12.m4a\"],\"ep13\":[\"https://f3rpiqeouy6c0.space.mcode.cn/media/ep13.m4a\"],\"ep14\":[\"https://f3rpiqeouy6c0.space.mcode.cn/media/ep14.m4a\"],\"ep15\":[\"https://5wxizdpb9tyq8.space.mcode.cn/media/ep15.m4a\"],\"ep16\":[\"https://5wxizdpb9tyq8.space.mcode.cn/media/ep16.m4a\"],\"ep17\":[\"https://5wxizdpb9tyq8.space.mcode.cn/media/ep17.m4a\"],\"ep18\":[\"https://5wxizdpb9tyq8.space.mcode.cn/media/ep18.m4a\"],\"ep19\":[\"https://5wxizdpb9tyq8.space.mcode.cn/media/ep19.m4a\"],\"ep20\":[\"https://5wxizdpb9tyq8.space.mcode.cn/media/ep20.m4a\"],\"ep21\":[\"https://5wxizdpb9tyq8.space.mcode.cn/media/ep21.m4a\"],\"ep22\":[\"https://5wxizdpb9tyq8.space.mcode.cn/media/ep22.m4a\"],\"ep23\":[\"https://5wxizdpb9tyq8.space.mcode.cn/media/ep23.m4a\"],\"ep24\":[\"https://5wxizdpb9tyq8.space.mcode.cn/media/ep24.m4a\"],\"ep25\":[\"https://5wxizdpb9tyq8.space.mcode.cn/media/ep25.m4a\"],\"ep26\":[\"https://5wxizdpb9tyq8.space.mcode.cn/media/ep26.m4a\"],\"ep27\":[\"https://5wxizdpb9tyq8.space.mcode.cn/media/ep27.m4a\"],\"ep28\":[\"https://5wxizdpb9tyq8.space.mcode.cn/media/ep28.m4a\"],\"ep29\":[\"https://bjyzdgmd6px91.space.mcode.cn/media/ep29.m4a\"],\"ep30\":[\"https://bjyzdgmd6px91.space.mcode.cn/media/ep30.m4a\"],\"ep31\":[\"https://bjyzdgmd6px91.space.mcode.cn/media/ep31.m4a\"],\"ep32\":[\"https://bjyzdgmd6px91.space.mcode.cn/media/ep32.m4a\"],\"ep33\":[\"https://bjyzdgmd6px91.space.mcode.cn/media/ep33.m4a\"],\"ep34\":[\"https://bjyzdgmd6px91.space.mcode.cn/media/ep34.m4a\"],\"ep35\":[\"https://bjyzdgmd6px91.space.mcode.cn/media/ep35.m4a\"],\"ep36\":[\"https://bjyzdgmd6px91.space.mcode.cn/media/ep36.m4a\"],\"ep37\":[\"https://bjyzdgmd6px91.space.mcode.cn/media/ep37.m4a\"],\"ep38\":[\"https://bjyzdgmd6px91.space.mcode.cn/media/ep38.m4a\"],\"ep39\":[\"https://bjyzdgmd6px91.space.mcode.cn/media/ep39.m4a\"],\"ep40\":[\"https://bjyzdgmd6px91.space.mcode.cn/media/ep40.m4a\"],\"ep41\":[\"https://bjyzdgmd6px91.space.mcode.cn/media/ep41.m4a\"],\"ep42\":[\"https://bjyzdgmd6px91.space.mcode.cn/media/ep42.m4a\"],\"ep43\":[\"https://clqvqp5j1qrqu.space.mcode.cn/media/ep43.m4a\"],\"ep44\":[\"https://clqvqp5j1qrqu.space.mcode.cn/media/ep44.m4a\"],\"ep45\":[\"https://clqvqp5j1qrqu.space.mcode.cn/media/ep45.m4a\"],\"ep46\":[\"https://clqvqp5j1qrqu.space.mcode.cn/media/ep46.m4a\"],\"ep47\":[\"https://clqvqp5j1qrqu.space.mcode.cn/media/ep47.m4a\"],\"ep48\":[\"https://clqvqp5j1qrqu.space.mcode.cn/media/ep48.m4a\"],\"ep49\":[\"https://clqvqp5j1qrqu.space.mcode.cn/media/ep49.m4a\"],\"ep50\":[\"https://clqvqp5j1qrqu.space.mcode.cn/media/ep50.m4a\"],\"ep51\":[\"https://clqvqp5j1qrqu.space.mcode.cn/media/ep51.m4a\"],\"ep52\":[\"https://clqvqp5j1qrqu.space.mcode.cn/media/ep52.m4a\"],\"ep53\":[\"https://clqvqp5j1qrqu.space.mcode.cn/media/ep53.m4a\"],\"ep54\":[\"https://clqvqp5j1qrqu.space.mcode.cn/media/ep54.m4a\"],\"ep55\":[\"https://clqvqp5j1qrqu.space.mcode.cn/media/ep55.m4a\"],\"ep56\":[\"https://clqvqp5j1qrqu.space.mcode.cn/media/ep56.m4a\"],\"ep57\":[\"https://vi57vb0da33qp.space.mcode.cn/media/ep57.m4a\"],\"ep58\":[\"https://vi57vb0da33qp.space.mcode.cn/media/ep58.m4a\"],\"ep59\":[\"https://vi57vb0da33qp.space.mcode.cn/media/ep59.m4a\"],\"ep60\":[\"https://vi57vb0da33qp.space.mcode.cn/media/ep60.m4a\"],\"ep61\":[\"https://vi57vb0da33qp.space.mcode.cn/media/ep61.m4a\"],\"ep62\":[\"https://vi57vb0da33qp.space.mcode.cn/media/ep62.m4a\"],\"ep63\":[\"https://vi57vb0da33qp.space.mcode.cn/media/ep63.m4a\"],\"ep64\":[\"https://vi57vb0da33qp.space.mcode.cn/media/ep64.m4a\"],\"ep65\":[\"https://vi57vb0da33qp.space.mcode.cn/media/ep65.m4a\"],\"ep66\":[\"https://vi57vb0da33qp.space.mcode.cn/media/ep66.m4a\"],\"ep67\":[\"https://vi57vb0da33qp.space.mcode.cn/media/ep67.m4a\"],\"ep68\":[\"https://vi57vb0da33qp.space.mcode.cn/media/ep68.m4a\"],\"ep69\":[\"https://vi57vb0da33qp.space.mcode.cn/media/ep69.m4a\"],\"ep70\":[\"https://vi57vb0da33qp.space.mcode.cn/media/ep70.m4a\"]}},\"wakakusa\":{\"mode\":\"table\",\"valueType\":\"single\",\"table\":{\"ep01\":\"https://4535p9s0wnpzs.space.mcode.cn/audio/ep01.m4a\",\"ep02\":\"https://4535p9s0wnpzs.space.mcode.cn/audio/ep02.m4a\",\"ep03\":\"https://4535p9s0wnpzs.space.mcode.cn/audio/ep03.m4a\",\"ep04\":\"https://4535p9s0wnpzs.space.mcode.cn/audio/ep04.m4a\",\"ep05\":\"https://4535p9s0wnpzs.space.mcode.cn/audio/ep05.m4a\",\"ep06\":\"https://4535p9s0wnpzs.space.mcode.cn/audio/ep06.m4a\",\"ep07\":\"https://4535p9s0wnpzs.space.mcode.cn/audio/ep07.m4a\",\"ep08\":\"https://4535p9s0wnpzs.space.mcode.cn/audio/ep08.m4a\",\"ep09\":\"https://4535p9s0wnpzs.space.mcode.cn/audio/ep09.m4a\",\"ep10\":\"https://4535p9s0wnpzs.space.mcode.cn/audio/ep10.m4a\",\"ep11\":\"https://4535p9s0wnpzs.space.mcode.cn/audio/ep11.m4a\",\"ep12\":\"https://4535p9s0wnpzs.space.mcode.cn/audio/ep12.m4a\",\"ep13\":\"https://4535p9s0wnpzs.space.mcode.cn/audio/ep13.m4a\",\"ep14\":\"https://4535p9s0wnpzs.space.mcode.cn/audio/ep14.m4a\",\"ep15\":\"https://lem5lvwy41rn9.space.mcode.cn/audio/ep15.m4a\",\"ep16\":\"https://lem5lvwy41rn9.space.mcode.cn/audio/ep16.m4a\",\"ep17\":\"https://lem5lvwy41rn9.space.mcode.cn/audio/ep17.m4a\",\"ep18\":\"https://lem5lvwy41rn9.space.mcode.cn/audio/ep18.m4a\",\"ep19\":\"https://lem5lvwy41rn9.space.mcode.cn/audio/ep19.m4a\",\"ep20\":\"https://lem5lvwy41rn9.space.mcode.cn/audio/ep20.m4a\",\"ep21\":\"https://lem5lvwy41rn9.space.mcode.cn/audio/ep21.m4a\",\"ep22\":\"https://lem5lvwy41rn9.space.mcode.cn/audio/ep22.m4a\",\"ep23\":\"https://lem5lvwy41rn9.space.mcode.cn/audio/ep23.m4a\",\"ep24\":\"https://lem5lvwy41rn9.space.mcode.cn/audio/ep24.m4a\",\"ep25\":\"https://lem5lvwy41rn9.space.mcode.cn/audio/ep25.m4a\",\"ep26\":\"https://lem5lvwy41rn9.space.mcode.cn/audio/ep26.m4a\",\"ep27\":\"https://lem5lvwy41rn9.space.mcode.cn/audio/ep27.m4a\",\"ep28\":\"https://lem5lvwy41rn9.space.mcode.cn/audio/ep28.m4a\",\"ep29\":\"https://wn1nwme4cg1hh.space.mcode.cn/audio/ep29.m4a\",\"ep30\":\"https://wn1nwme4cg1hh.space.mcode.cn/audio/ep30.m4a\",\"ep31\":\"https://wn1nwme4cg1hh.space.mcode.cn/audio/ep31.m4a\",\"ep32\":\"https://wn1nwme4cg1hh.space.mcode.cn/audio/ep32.m4a\",\"ep33\":\"https://wn1nwme4cg1hh.space.mcode.cn/audio/ep33.m4a\",\"ep34\":\"https://wn1nwme4cg1hh.space.mcode.cn/audio/ep34.m4a\",\"ep35\":\"https://wn1nwme4cg1hh.space.mcode.cn/audio/ep35.m4a\",\"ep36\":\"https://wn1nwme4cg1hh.space.mcode.cn/audio/ep36.m4a\",\"ep37\":\"https://wn1nwme4cg1hh.space.mcode.cn/audio/ep37.m4a\",\"ep38\":\"https://wn1nwme4cg1hh.space.mcode.cn/audio/ep38.m4a\",\"ep39\":\"https://wn1nwme4cg1hh.space.mcode.cn/audio/ep39.m4a\",\"ep40\":\"https://wn1nwme4cg1hh.space.mcode.cn/audio/ep40.m4a\"}},\"dora\":{\"mode\":\"base\",\"root\":\"https://9kgu879p4dhy2.space.mcode.cn\",\"path\":\"/audio/{file}\",\"example\":[{\"file\":\"ep01.mp3\",\"url\":\"https://9kgu879p4dhy2.space.mcode.cn/audio/ep01.mp3\"}],\"exampleRange\":{\"min\":1,\"max\":7,\"note\":\"{file} 已含扩展名，不要再拼 ext\"},\"sample\":{\"ep01\":\"ep01.mp3\",\"ep02\":\"ep02.mp3\"}},\"ama\":{\"mode\":\"base\",\"root\":\"https://tcw0ti0k7p0hd.space.mcode.cn\",\"path\":\"/audio/E{n2}.m4a\",\"pad\":{\"n2\":2},\"example\":[{\"n2\":1,\"url\":\"https://tcw0ti0k7p0hd.space.mcode.cn/audio/E01.m4a\"},{\"n2\":9,\"url\":\"https://tcw0ti0k7p0hd.space.mcode.cn/audio/E09.m4a\"},{\"n2\":10,\"url\":\"https://tcw0ti0k7p0hd.space.mcode.cn/audio/E10.m4a\"}],\"exampleRange\":{\"min\":1,\"max\":12,\"note\":\"本项目共 12 集；1~9 与 10~12 均为 2 位（补零到 2 位）\"}},\"pony\":{\"mode\":\"base\",\"root\":\"https://3vpcud2aabhor.space.mcode.cn\",\"path\":\"/media/{tag}.m4a\",\"example\":[{\"tag\":\"ep01\",\"url\":\"https://3vpcud2aabhor.space.mcode.cn/media/ep01.m4a\"}]},\"tadoku\":{\"mode\":\"base\",\"root\":\"https://zyksozpp1p7i0.space.mcode.cn\",\"path\":\"/media/{tag}.mp3\",\"example\":[{\"tag\":\"ep01\",\"url\":\"https://zyksozpp1p7i0.space.mcode.cn/media/ep01.mp3\"}]}}}");

function corsHeaders() {
  return {
    'Content-Type': 'application/json; charset=utf-8',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type,Authorization',
    'Access-Control-Allow-Methods': 'POST,OPTIONS,GET',
    'Access-Control-Max-Age': '86400',
  };
}

function reply(statusCode, obj) {
  return {
    statusCode: statusCode,
    headers: corsHeaders(),
    body: JSON.stringify(obj),
    isBase64Encoded: false,
  };
}

function clean(s, max) {
  if (s === null || s === undefined) return '';
  let t = String(s).replace(/\s+/g, ' ').trim();
  if (max && t.length > max) t = t.slice(0, max);
  return t;
}

function pickJa(x) {
  if (!x) return '';
  if (typeof x === 'string') return clean(x, 200);
  return clean(x.ja || x.jp || x.text || '', 200);
}

function pickZh(x) {
  if (!x) return '';
  if (typeof x === 'string') return clean(x, 200);
  return clean(x.zh || x.cn || x.trans || '', 200);
}

function arr(v, max) {
  if (!Array.isArray(v)) return [];
  return v.slice(0, max || 8).map(function (x) {
    return { ja: pickJa(x), zh: pickZh(x) };
  }).filter(function (x) { return x.ja; });
}

/* ------------------------------------------------------------------ */
/* 拼 USER 消息                                                        */
/* ------------------------------------------------------------------ */
function buildUserMessage(body) {
  const lines = [];
  lines.push('剧名：' + (clean(body.title, 60) || '（未指定）'));
  if (body.episode) lines.push('集数：' + clean(body.episode, 40));
  lines.push('');

  const scene = body.scene === 'explain_word' ? 'explain_word' : 'explain_sentence';
  if (scene === 'explain_word' && clean(body.word, 40)) {
    lines.push('★ 本次要重点讲解的词：' + clean(body.word, 40));
    lines.push('（仍然按五段结构输出，但「逐词拆解」和「语法说明」要围绕这个词展开）');
    lines.push('');
  }

  const prev = arr(body.prev, 4);
  const next = arr(body.next, 4);

  lines.push('【上下文】');
  if (prev.length) {
    lines.push('--- 上一句 ---');
    prev.forEach(function (p) { lines.push(p.ja + (p.zh ? '　' + p.zh : '')); });
  }
  lines.push('--- 当前句（要解析的）---');
  lines.push(clean(body.ja, 300) + (clean(body.zh, 300) ? '　' + clean(body.zh, 300) : ''));
  if (next.length) {
    lines.push('--- 下一句 ---');
    next.forEach(function (p) { lines.push(p.ja + (p.zh ? '　' + p.zh : '')); });
  }
  lines.push('');

  const refs = arr(body.refs, 6);
  if (refs.length) {
    lines.push('【本剧台词参考（用来造例句，优先用这里的原句，不要自己编）】');
    refs.forEach(function (r) { lines.push('- ' + r.ja + (r.zh ? '（' + r.zh + '）' : '')); });
    lines.push('');
  }

  return lines.join('\n');
}

/* ------------------------------------------------------------------ */
/* 调 MiniMax                                                          */
/* ------------------------------------------------------------------ */
function thinkingField() {
  switch (String(CFG.thinking).toLowerCase()) {
    case 'disabled': return { thinking: { type: 'disabled' } };
    case 'enabled':  return { thinking: { type: 'enabled' } };
    case 'adaptive': return { thinking: { type: 'adaptive' } };
    case 'none':     return {};
    default:         return { thinking: { type: 'disabled' } };
  }
}

function callMiniMax(userMsg) {
  return new Promise(function (resolve, reject) {
    const payloadObj = {
      model: CFG.model,
      messages: [
        { role: 'system', content: SYSTEM_PROMPT },
        { role: 'user', content: userMsg }
      ],
      max_completion_tokens: CFG.maxTokens,
      temperature: 0.3
    };
    Object.assign(payloadObj, thinkingField());
    const payload = JSON.stringify(payloadObj);

    /* ⚠️ 绝对不要用 new URL()：
       CloudBase 的 Node 沙箱里没有全局 URL（ReferenceError: URL is not defined），
       而本地 Node 有 → 本地测全绿、线上必挂。改成纯字符串解析。 */
    const fullUrl = CFG.baseUrl + '/chat/completions';
    const um = /^(https?):\/\/([^/:?#]+)(?::(\d+))?([^?#]*)(\?[^#]*)?/.exec(fullUrl);
    if (!um) return reject(new Error('bad_base_url:' + fullUrl));
    const req = https.request({
      hostname: um[2],
      port: um[3] ? parseInt(um[3], 10) : 443,
      path: (um[4] || '/') + (um[5] || ''),
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(payload),
        'Authorization': 'Bearer ' + CFG.apiKey
      },
      timeout: CFG.timeoutMs
    }, function (res) {
      let buf = '';
      res.setEncoding('utf8');
      res.on('data', function (d) { buf += d; });
      res.on('end', function () {
        if (res.statusCode !== 200) {
          return reject(new Error('upstream_' + res.statusCode + ':' + buf.slice(0, 300)));
        }
        let j;
        try { j = JSON.parse(buf); } catch (e) { return reject(new Error('bad_upstream_json')); }
        if (j.base_resp && j.base_resp.status_code && j.base_resp.status_code !== 0) {
          return reject(new Error('upstream_biz:' + JSON.stringify(j.base_resp)));
        }
        const text = j.choices && j.choices[0] && j.choices[0].message
          ? (j.choices[0].message.content || '')
          : '';
        if (!text) return reject(new Error('empty_upstream_text'));
        resolve(text);
      });
    });

    req.on('timeout', function () { req.destroy(new Error('timeout')); });
    req.on('error', function (e) { reject(e); });
    req.write(payload);
    req.end();
  });
}

/* ------------------------------------------------------------------ */
/* 真·额度查询（MiniMax Token Plan 官方接口）                          */
/*   GET {baseUrl}/token_plan/remains                                   */
/*   → 5h 窗口剩余 % / 周窗口剩余 % / 重置倒计时                        */
/*   这是「真信号」—— 比内存计数靠谱得多                                */
/* ------------------------------------------------------------------ */
let QUOTA_CACHE = null;
let QUOTA_AT = 0;

function httpGetJson(url, headers) {
  return new Promise(function (resolve, reject) {
    const um = /^(https?):\/\/([^/:?#]+)(?::(\d+))?([^?#]*)(\?[^#]*)?/.exec(url);
    if (!um) return reject(new Error('bad_url'));
    const req = https.request({
      hostname: um[2],
      port: um[3] ? parseInt(um[3], 10) : 443,
      path: (um[4] || '/') + (um[5] || ''),
      method: 'GET',
      headers: headers || {},
      timeout: 15000
    }, function (res) {
      let buf = '';
      res.setEncoding('utf8');
      res.on('data', function (d) { buf += d; });
      res.on('end', function () {
        if (res.statusCode !== 200) return reject(new Error('quota_http_' + res.statusCode));
        try { resolve(JSON.parse(buf)); } catch (e) { reject(new Error('quota_bad_json')); }
      });
    });
    req.on('timeout', function () { req.destroy(new Error('quota_timeout')); });
    req.on('error', function (e) { reject(e); });
    req.end();
  });
}

async function getQuota(force) {
  const now = Date.now();
  if (!force && QUOTA_CACHE && (now - QUOTA_AT) < 60000) return QUOTA_CACHE;
  const j = await httpGetJson(CFG.baseUrl + '/token_plan/remains', {
    'Authorization': 'Bearer ' + CFG.apiKey,
    'Content-Type': 'application/json'
  });
  const br = j.base_resp || {};
  if (br.status_code && br.status_code !== 0) {
    throw new Error('quota_err:' + br.status_code + ' ' + (br.status_msg || ''));
  }
  const m = (j.model_remains && j.model_remains[0]) || {};
  QUOTA_CACHE = {
    interval_percent: m.current_interval_remaining_percent,
    weekly_percent: m.current_weekly_remaining_percent,
    interval_reset_in_ms: m.remains_time,
    weekly_reset_in_ms: m.weekly_remains_time,
    interval_status: m.current_interval_status,
    weekly_status: m.current_weekly_status
  };
  QUOTA_AT = now;
  return QUOTA_CACHE;
}

/* ------------------------------------------------------------------ */
/* 核心处理                                                            */
/* ------------------------------------------------------------------ */
async function handle(event) {
  const raw = (event && event.body !== undefined && event.body !== null) ? event.body : event;
  const method = String((event && event.httpMethod) || 'POST').toUpperCase();

  /* CORS 预检 */
  if (method === 'OPTIONS') return reply(204, { ok: true });

  /* 健康检查 */
  if (method === 'GET') {
    const gp = String((event && event.path) || '');
    /* 🔴 GET /prompt —— 让前端能拉到**本函数正在用的那份** SYSTEM_PROMPT 原文。
     *   为什么要有这个：
     *     中转和前端的 prompt 必须**逐字一致**（复制提问模式要跟真接口同结果，
     *     测试也要断言两端相同）。以前靠手抄/复制粘贴同步 → 迟早漂。
     *   现在：**从线上函数拉原文** → 脚本化替换 → 逐字 diff → 漂不了。
     *   🔴 prompt 里**不含任何密钥**，公开可读是安全的。 */
    if (gp.indexOf('prompt') >= 0) {
      return reply(200, {
        ok: true,
        prompt: SYSTEM_PROMPT,
        prompt_sha: promptSha(),
        prompt_len: SYSTEM_PROMPT.length
      });
    }
    /* 🔴🔴 GET /audio-config —— hub 各项目的音频地址表（2026-10-23 加，pony 提的方案）
     *   为什么放在中转：需要一个**永久域名**（hub 站名每次发版都变，不能编进 APK）；
     *   中转的 `vocab-test-….service.tcloudbase.com` 是目前唯一的永久域名。
     *   🔴 不烧 AI 额度、🔴 不含密钥 → 公开可读是安全的。
     *   🔴 契约：
     *     { v, updated, projects: {
     *         <project>: { mode:'table', table:{ <集key>: [url, ...] } }   // 每集独立表
     *         <project>: { mode:'base', base:'https://…/', ext:'.m4a', prefix? }  // base+固定后缀
     *     } }
     *   🔴 前端用法：**只在「当前域名连不上」时才拉**（用户流量敏感）→ 拉不到就用 APK 里的本地表。
     *   🔴 拉到了但没有某项目 → 该项目继续用本地表（不覆盖）。 */
    if (gp.indexOf('audio-config') >= 0) {
      return reply(200, Object.assign({ ok: true }, AUDIO_CONFIG));
    }
/*__CET4_BLOCK_BEGIN_2*/
    /* 🔴 CET4 分支（大学英语四级翻译批改）—— GET /ai/cet4-spec
     *   ⚠️ 位置要求：**必须在默认返回分支之前**。
     *   ⚠️ 命名铁律：现役路由用 `gp.indexOf(...)` **子串包含**匹配，
     *      且 'prompt' / 'audio-config' / 'quota' 三个判断在前面 ⇒
     *      我的路径**不能含这三个子串**，否则会先被日语分支吃掉。
     *      ⇒ 这里用 'cet4-spec'（不含 prompt/quota/audio-config）✅
     *   不烧 AI 额度、不含密钥 → 公开可读是安全的。 */
    
/*__VOCAB_OPS_BEGIN_2*/
/*__VOCAB_OPS_BEGIN_2*/
    /* 写端点只接受 POST ⇒ GET 一律 405（别让「200 + 默认信息」被当成成功） */
    if (gp.indexOf('vocab-ops') >= 0) {
      return reply(405, { ok: false, error: 'bad_request' });
    }
/*__VOCAB_OPS_END_2*//*__VOCAB_OPS_END_2*/
if (gp.indexOf('cet4-spec') >= 0) {
      return __CET4_MOD__.cet4Spec();
    }
    /* GET 打 /ai/cet4 ⇒ 明确告诉前端要用 POST，别让它拿到默认信息以为成功了 */
    if (gp.indexOf('cet4') >= 0) {
      return reply(405, { ok: false, error: 'bad_request' });
    }
/*__CET4_BLOCK_END_2*/
    if (gp.indexOf('quota') >= 0) {
      if (!CFG.apiKey) return reply(503, { ok: false, error: 'not_configured' });
      try {
        return reply(200, { ok: true, quota: await getQuota(true) });
      } catch (e) {
        console.error('[ai-proxy] quota fail ' + ((e && e.message) || 'unknown'));
        return reply(502, { ok: false, error: 'upstream_error' });
      }
    }
    return reply(200, {
      ok: true, service: 'ai-proxy', model: CFG.model,
      thinking: CFG.thinking, configured: !!CFG.apiKey
    });
  }

  /* 没有 key → 明确告诉前端「未配置」 */
  if (!CFG.apiKey) return reply(503, { ok: false, error: 'not_configured' });

  /* 可选的访问令牌校验 */
  if (CFG.token) {
    const hdr = (event && event.headers) || {};
    let auth = '';
    for (const k in hdr) {
      if (k.toLowerCase() === 'authorization') { auth = hdr[k]; break; }
    }
    const got = String(auth || '').replace(/^Bearer\s+/i, '').trim();
    if (got !== CFG.token) return reply(401, { ok: false, error: 'unauthorized' });
  }

  /* 🔴 真限流：查 MiniMax 真实额度（周窗口剩余太低就劝退）
     查不到额度时放行 —— 不能因为额度接口挂了就让整个服务不可用 */
  CALLS += 1;
  /* 🔴 真限流只看 MiniMax 真实额度（周窗口剩余低于阈值就劝退）
     ⚠️ 不再用内存计数做拦截 —— 那个阈值冷启动就重置，拦不住任何东西，
        还会让「今天用得有点多」这种文案误导用户（实际触发的是周窗口）。 */
  try {
    const q = await getQuota(false);
    if (typeof q.weekly_percent === 'number' && q.weekly_percent <= CFG.weeklyStopPct) {
      console.log('[ai-proxy] blocked too_many weekly=' + q.weekly_percent + '%');
      return reply(429, { ok: false, error: 'too_many', quota: q });
    }
    console.log('[ai-proxy] call#' + CALLS + ' weekly=' + q.weekly_percent + '% 5h=' + q.interval_percent + '%');
  } catch (e) {
    console.error('[ai-proxy] quota check skipped: ' + ((e && e.message) || 'unknown'));
  }

  /* 解析请求体 */
  let data = raw;
  if (typeof data === 'string') {
    try { data = JSON.parse(data); } catch (e) { return reply(400, { ok: false, error: 'bad_request' }); }
  }
  if (!data || typeof data !== 'object') return reply(400, { ok: false, error: 'bad_request' });

/*__CET4_BLOCK_BEGIN_1*/
    /* 🔴 CET4 分支（大学英语四级翻译批改）—— POST /ai/cet4
     *   ⚠️ 位置要求：必须在 **'const ja = clean(data.ja, 300);' 之前**
     *      —— 日语分支要求 body 里有 ja，而四级批改的 body 没有 ja
     *      ⇒ 放晚了会被日语分支判成 bad_request。
     *   ⚠️ 放在这里 ⇒ 白捡现役的三道闸门：key 检查 / token 校验 / 配额限流。 */
    if (String((event && event.path) || '').indexOf('cet4') >= 0) {
      return await __CET4_MOD__.cet4Route(data);
    }
/*__CET4_BLOCK_END_1*/
  
/*__VOCAB_OPS_BEGIN_3*/
/*__VOCAB_OPS_BEGIN_3*/
    /* 🔴 教师侧特权写端点（vocab-ops）—— 必须在 'const ja = clean(data.ja, 300);' 之前
     *   理由：日语分支要求 body 里有 ja，而 vocab-ops 的 body 没有 ja
     *        ⇒ 放晚了会被日语分支判成 bad_request（写操作被静默吞掉）
     *   放在这里还能白捡现役三道闸门：key 检查 / token 校验 / 配额限流
     *   ⚠️ 本端点用 service_role（绕过 RLS）⇒ 口令摘要校验在模块内部，做不到就一行不删
     */
    if (__vocabOpsPath(event)) {
      return await __VOCAB_OPS_MOD__.handleVocabOps(event);
    }
/*__VOCAB_OPS_END_3*//*__VOCAB_OPS_END_3*/
const ja = clean(data.ja, 300);
  if (!ja) return reply(400, { ok: false, error: 'bad_request' });

  const userMsg = buildUserMessage(data);

  try {
    const text = await callMiniMax(userMsg);
    console.log('[ai-proxy] ok model=' + CFG.model + ' len=' + text.length);
    return reply(200, { ok: true, text: text });
  } catch (e) {
    const msg = (e && e.message) || 'unknown';
    console.error('[ai-proxy] fail ' + msg + ' | code=' + (e && e.code) + ' | stack=' + String((e && e.stack) || '').split('\n').slice(0,3).join(' / '));
    if (msg === 'timeout') return reply(504, { ok: false, error: 'timeout' });
    if (msg.indexOf('upstream_401') >= 0 || msg.indexOf('2049') >= 0) {
      return reply(502, { ok: false, error: 'upstream_auth' });
    }
    if (msg.indexOf('2013') >= 0) {
      // 参数不合法（例如 M3.1-Flash 不允许关思考）
      return reply(502, { ok: false, error: 'upstream_params' });
    }
    if (msg.indexOf('2056') >= 0) {
      return reply(429, { ok: false, error: 'quota_exceeded' });
    }
    return reply(502, { ok: false, error: 'upstream_error' });
  }
}

/* ------------------------------------------------------------------ */
/* 模式 A：普通云函数（exports.main）                                   */
/* ------------------------------------------------------------------ */
let MAIN_CALLED = false;
exports.main = async function (event, context) {
  MAIN_CALLED = true;
  /* 如果是 Web 框架模式误走了这里 → 关掉 http server，让它退出 */
  if (server) {
    try { server.close(); } catch (e) { /* ignore */ }
    server = null;
  }
  return handle(event);
};

/* ------------------------------------------------------------------ */
/* 模式 B：Web 框架云函数（scf_bootstrap require 本文件 → 起 http server） */
/* ------------------------------------------------------------------ */
let server = null;
try {
  server = http.createServer(function (req, res) {
    let body = '';
    /* 🔴 必须 setEncoding('utf8')：Buffer 隐式 toString 是**按 chunk 边界**解码的，
     *   多字节字符（假名/汉字）正好被切在两个 chunk 之间时 → 那个字变 U+FFFD 乱码，
     *   用户那句日语就被静默改了一个字。setEncoding 用 StringDecoder，跨 chunk 正确。 */
    req.setEncoding('utf8');
    req.on('data', function (c) { body += c; });
    req.on('end', function () {
      let parsed = {};
      try { parsed = body ? JSON.parse(body) : {}; } catch (e) { parsed = {}; }
      handle({ httpMethod: req.method, headers: req.headers, body: parsed, path: req.url })
        .then(function (r) {
          res.writeHead(r.statusCode, r.headers);
          res.end(r.body);
        })
        .catch(function (e) {
          console.error('[ai-proxy] http err ' + (e && e.message));
          res.writeHead(500, corsHeaders());
          res.end(JSON.stringify({ ok: false, error: 'server_error' }));
        });
    });
  });
  server.on('error', function (e) {
    console.log('[ai-proxy] http server not started (' + (e && e.message) + ') — 走 exports.main 模式');
    server = null;
  });
  /* 🔴 延迟 400ms 再 bind 9000：
     万一 scf_bootstrap 走的是 Functions Framework（它自己也会 bind 9000），
     让它先占住端口 → 我们 EADDRINUSE → 自动退回 exports.main 模式。
     反过来若我们先占住，框架 bind 失败整个函数就废了。 */
  setTimeout(function () {
    if (MAIN_CALLED) {
      console.log('[ai-proxy] exports.main 模式（框架已接管端口），不起 http server');
      try { server.close(); } catch (e) { /* ignore */ }
      server = null;
      return;
    }
    server.listen(process.env.PORT || 9000, '0.0.0.0', function () {
      console.log('[ai-proxy] web server on :' + (process.env.PORT || 9000));
    });
  }, 400);
} catch (e) {
  console.log('[ai-proxy] http server unavailable — 走 exports.main 模式');
  server = null;
}

/*__CET4_BLOCK_BEGIN_3*/
/* ===== CET4 分支（大学英语四级翻译批改）· merge_cet4_branch.py 插入 ===== */
const __CET4_MOD__ = (function () {
/* ============================================================
 * CET4 分支核心 —— 大学英语四级翻译批改
 * ------------------------------------------------------------
 * 这段代码是**纯函数**，不依赖中转的任何内部结构：
 *   - 不发请求、不读环境变量、不写 HTTP 响应
 *   - 合并脚本会把它内联进 ai-proxy 的 index.js
 *
 * 中转侧只需要在路由里调用：
 *   var msgs  = CET4.buildMessages(payload);
 *   var text  = (await callModel(msgs));        // ← 中转自己的调用
 *   var obj   = CET4.parseOutput(text);          // 剥围栏 + 抽 JSON
 *   var clean = CET4.validate(obj, payload);     // 一致性 + 事实量校验
 *
 * 单独跑这套函数的测试：frontend/test_ai_cet4.js
 * ============================================================ */
var CET4 = (function () {

  /* ---- 五档标准（与 js/scoring.js 的 bandText 一字对齐） ---- */
  var BANDS = [
    { no: 1, name: '准确表达',     min: 13, max: 15, range: '13-15' },
    { no: 2, name: '基本表达',     min: 10, max: 12, range: '10-12' },
    { no: 3, name: '勉强表达',     min: 7,  max: 9,  range: '7-9' },
    { no: 4, name: '仅表达少部分', min: 4,  max: 6,  range: '4-6' },
    { no: 5, name: '支离破碎',     min: 1,  max: 3,  range: '1-3' }
  ];

  /* ---- 错误类型枚举（与 js/grammar.js 的 TYPES 一字对齐，不许自创） ---- */
  var TYPES = [
    '主谓一致', '冠词', '时态', '单复数', '动词形式',
    '介词搭配', '拼写', '重复用词', '中式表达', '超纲用词'
  ];

  /* ---- prompt 全文（合并脚本会用 CET4_SYSTEM_PROMPT.txt 内联覆盖） ----
     🔴 放在 STATE 对象里而不是裸变量 —— 闭包读裸变量时，
        「改了导出对象的属性」对闭包**无效**（改了表示，没改事实）。
        ⇒ 提供 setPrompt() 让运行时也能真注入。 */
  var STATE = { prompt: '【角色】\n你是大学英语四级（CET-4）翻译阅卷老师，按官方五档评分标准批改学生的汉译英。\n\n【任务】\n批改学生提交的翻译（本次可能是 2 句，也可能是全部 5 句）。\n你要同时给出：五档定档、分数区间、每句的具体语法错误、每句的修改建议。\n\n【你会收到的输入（JSON）】\n- mode：字符串，"2" 或 "5"，表示本次批改的句数\n- sentences：数组，每项 { no: 句号(1起), zh: 中文原句, reference: 参考译文, points: 该句的采分点数组 }\n- student：数组，每项 { no: 句号(1起), text: 学生译文（可能是空字符串，表示没作答） }\n\n【输出格式：只输出一个合法 JSON 对象，不要任何解释文字，不要 markdown 代码围栏】\n{\n  "band": 1,\n  "score_range": "13-15",\n  "score": 13,\n  "confidence": "high",\n  "summary": "一句话总评（中文，40 字以内）",\n  "sentences": [\n    {\n      "no": 1,\n      "student": "学生这句的原文，逐字照抄；空则空字符串",\n      "reference": "参考译文",\n      "missing_points": ["没体现出来的采分点"],\n      "grammar": [\n        { "type": "错误类型", "span": "错的那一段，逐字取自学生译文", "fix": "应该怎么改", "note": "为什么错，中文一句话" }\n      ],\n      "revised": "改好的整句英文，可直接抄进答卷",\n      "comment": "这一句的中文点评，1~2 句"\n    }\n  ],\n  "error_types": { "主谓一致": 2, "冠词": 1 },\n  "weakest_points": ["最该补的 3 个采分点，中文说明"]\n}\n\n【硬性规则】\n1. band 必须是 1~5 的整数。档位与分数区间必须严格对应，不许跨档：\n   第1档 准确表达 13-15｜第2档 基本表达 10-12｜第3档 勉强表达 7-9｜第4档 仅表达少部分 4-6｜第5档 支离破碎 1-3\n2. score 必须是这个区间里的整数。confidence 三档：\n   high = 信息完整、语言都清楚；medium = 意思大致对但有几处说不准；low = 学生写得残缺或你自己没把握。\n3. 定档要同时看三件事：①意思准不准（信息完整度）②语言对不对（语法）③通不通顺（表达）。\n   信息完整度高但语言错误多，照样要掉档；空着的句子按没作答算。\n4. grammar 里的 type 只能从这 10 个里选，不许自创、不许改写名称：\n   主谓一致、冠词、时态、单复数、动词形式、介词搭配、拼写、重复用词、中式表达、超纲用词\n5. span 必须逐字取自学生译文，不许改写、不许拼接、不许省略。\n6. 一条错误拿不准就不要报 —— 宁可漏报不可误报。没把握的整条不写进 grammar。\n7. 不许编造学生没写的句子。输入里出现过的句号才许出现在输出里；学生没作答的句子，\n   student 写空字符串、missing_points 写该句全部采分点、grammar 写空数组、revised 写空字符串。\n8. revised 是可以直接抄进答卷的英文，不是解说；只改错，不重写整句换个说法。\n9. error_types 要统计每类错误**出现了几次**（跨所有句子累加），只在 grammar 非空时才有这个键。\n10. summary、note、comment、weakest_points 用中文写；英文只允许出现在 span、fix、revised、reference、student 里。\n11. 不要 emoji。不要写「好的」「以下是」之类的开场白。\n\n【关于采分点命中】\n采分点判断按**语义**，不按用词是否一模一样：\n- 意思表达到了就算命中 —— 学生换了同义词、换了句式，都算命中\n- 完全没提到这个意思，才算漏，才写进 missing_points\n- 一个采分点被拆到两句里表达，也算命中\n' };
  function setPrompt(t) { STATE.prompt = String(t == null ? '' : t); return STATE.prompt; }

  function bandOf(no) {
    for (var i = 0; i < BANDS.length; i++) if (BANDS[i].no === no) return BANDS[i];
    return null;
  }

  /* ============================================================
   * 从模型输出里抽出 JSON 对象
   * 不用贪婪正则 —— 字符串里可能有 { } 和转义引号，必须括号配平扫描
   * ============================================================ */
  function extractJson(text) {
    if (typeof text !== 'string') return null;
    var s = text;

    /* 1) 剥 markdown 代码围栏（```json ... ``` / ``` ... ```） */
    var fence = s.match(/```[ \t]*([A-Za-z0-9_+-]*)[ \t]*\r?\n([\s\S]*?)```/);
    if (fence) s = fence[2];

    /* 2) 找第一个 '{'，然后括号配平扫到配对的 '}' */
    var start = s.indexOf('{');
    if (start < 0) return null;

    var depth = 0, inStr = false, esc = false, end = -1;
    for (var i = start; i < s.length; i++) {
      var ch = s.charAt(i);
      if (inStr) {
        if (esc) { esc = false; continue; }
        if (ch === '\\') { esc = true; continue; }
        if (ch === '"') inStr = false;
        continue;
      }
      if (ch === '"') { inStr = true; continue; }
      if (ch === '{') depth++;
      else if (ch === '}') {
        depth--;
        if (depth === 0) { end = i + 1; break; }
      }
    }
    if (end < 0) return null;

    var raw = s.slice(start, end);
    try { return JSON.parse(raw); }
    catch (e) {
      /* JSON.parse 对尾逗号宽容一点：再试一次 */
      try { return JSON.parse(raw.replace(/,\s*([}\]])/g, '$1')); }
      catch (e2) { return null; }
    }
  }

  /* ============================================================
   * 组装发给模型的消息
   * payload = { mode, sentences:[{no,zh,reference,points}], student:[{no,text}] }
   * ============================================================ */
  function buildMessages(payload) {
    var p = payload || {};
    var stu = {};
    (p.student || []).forEach(function (s) { stu[s.no] = (s.text || ''); });

    var lines = [];
    lines.push('mode: ' + (p.mode || '2'));
    lines.push('');
    lines.push('sentences:');
    (p.sentences || []).forEach(function (s) {
      lines.push('  - no: ' + s.no);
      lines.push('    zh: ' + (s.zh || ''));
      lines.push('    reference: ' + (s.reference || ''));
      lines.push('    points: [' + (s.points || []).join('; ') + ']');
    });
    lines.push('');
    lines.push('student:');
    (p.sentences || []).forEach(function (s) {
      var t = stu[s.no];
      lines.push('  - no: ' + s.no);
      lines.push('    text: ' + (t === undefined ? '' : t));
    });

    return [
      { role: 'system', content: STATE.prompt },
      { role: 'user', content: lines.join('\n') }
    ];
  }

  /* ============================================================
   * 一致性 + 事实量校验
   * 判据落在**事实量**上：
   *   ① band / score_range / score 三者互相自洽
   *   ② grammar.type 必须在枚举里
   *   ③ grammar.span 必须**逐字出现在该句学生译文里**（不许模型编造）
   *   ④ sentences 里的 no 必须在输入里出现过
   *   ⑤ **fix 必须真的说明了怎么改**（与 span 实质相同 ⇒ 是废话 ⇒ 剔除）
   *   ⑥ 同 span + 同 fix 的重复条目 ⇒ 只留第一条（否则错误类型统计虚高）
   * 校验不过的项**就地剔除**而不是整份丢弃（尽量给用户看）
   * ============================================================ */

  /* 归一：只留字母数字小写 ⇒ 比较「实质内容」而不是表面写法 */
  function normFix(s) {
    return String(s === null || s === undefined ? '' : s)
      .toLowerCase().replace(/[^a-z0-9]+/g, '');
  }

  function validate(obj, payload) {
    var out = { ok: false, problems: [] };
    if (!obj || typeof obj !== 'object') {
      out.problems.push('不是 JSON 对象');
      return out;
    }

    var inputNos = {};
    (payload && payload.sentences || []).forEach(function (s) { inputNos[s.no] = true; });

    /* ① band */
    var band = parseInt(obj.band, 10);
    var b = bandOf(band);
    if (!b) {
      out.problems.push('band 非法: ' + JSON.stringify(obj.band));
      band = 0; b = null;
    }

    /* ② score_range / score */
    var range = typeof obj.score_range === 'string' ? obj.score_range.trim() : '';
    var score = parseInt(obj.score, 10);
    if (b) {
      if (range && range !== b.range) out.problems.push('score_range 与 band 不符: ' + range + ' vs ' + b.range);
      if (!(score >= b.min && score <= b.max)) {
        out.problems.push('score 越界: ' + obj.score + ' 不在 ' + b.range);
        score = b.min;                     /* 兜到区间下沿，不给用户一个假的越界分 */
      }
    }

    /* ③ sentences */
    var stuByNo = {};
    ((payload && payload.student) || []).forEach(function (s) { stuByNo[s.no] = s.text || ''; });

    var kept = [];
    (Array.isArray(obj.sentences) ? obj.sentences : []).forEach(function (s) {
      if (!s || typeof s !== 'object') return;
      var no = parseInt(s.no, 10);
      if (!inputNos[no]) { out.problems.push('句号不在输入里: ' + s.no); return; }

      var stuText = (s.student === undefined || s.student === null) ? '' : String(s.student);

      /* grammar：逐条查 type 枚举 + span 事实量 */
      var gKept = [], seenFix = {};
      (Array.isArray(s.grammar) ? s.grammar : []).forEach(function (g) {
        if (!g || typeof g !== 'object') return;
        var t = typeof g.type === 'string' ? g.type.trim() : '';
        if (TYPES.indexOf(t) < 0) { out.problems.push('未知错误类型: ' + t); return; }
        var span = typeof g.span === 'string' ? g.span : '';
        if (!span) { out.problems.push('span 为空'); return; }
        /* 🔴 事实量判据：span 必须逐字出现在学生译文里 */
        if (stuText && stuText.indexOf(span) < 0) {
          out.problems.push('span 不在学生译文里（第 ' + no + ' 句）: ' + span);
          return;
        }
        var fix = typeof g.fix === 'string' ? g.fix : '';
        /* 🔴 事实量判据：fix 必须真的说明了「怎么改」。
           实测踩到：模型报「[冠词]「China's」→ China's」—— 改法和原文一样，
           等于没说怎么改，却占掉一个错误类型（假警报）。 */
        if (!normFix(fix)) { out.problems.push('fix 为空（第 ' + no + ' 句）: ' + span); return; }
        if (normFix(fix) === normFix(span)) {
          out.problems.push('fix 与 span 实质相同，没说怎么改（第 ' + no + ' 句）: ' + span);
          return;
        }
        /* 同 span + 同 fix 的重复 ⇒ 只留第一条（否则错误类型统计虚高） */
        var dedup = normFix(span) + '|' + normFix(fix);
        if (seenFix[dedup]) { out.problems.push('重复条目已去重（第 ' + no + ' 句）: ' + span); return; }
        seenFix[dedup] = 1;
        gKept.push({
          type: t,
          span: span,
          fix: fix,
          note: typeof g.note === 'string' ? g.note : ''
        });
      });

      kept.push({
        no: no,
        student: stuText,
        reference: typeof s.reference === 'string' ? s.reference : '',
        missing_points: (Array.isArray(s.missing_points) ? s.missing_points : [])
          .filter(function (x) { return typeof x === 'string' && x; }),
        grammar: gKept,
        revised: typeof s.revised === 'string' ? s.revised : '',
        comment: typeof s.comment === 'string' ? s.comment : ''
      });
    });

    /* ④ error_types：只保留枚举里的键，且重算一遍（以实际留下的 grammar 为准） */
    var types = {};
    kept.forEach(function (s) {
      s.grammar.forEach(function (g) { types[g.type] = (types[g.type] || 0) + 1; });
    });

    out.ok = true;
    out.result = {
      band: band,
      band_name: b ? b.name : '',
      score_range: b ? b.range : '',
      score: score,
      confidence: ['high', 'medium', 'low'].indexOf(obj.confidence) >= 0 ? obj.confidence : 'medium',
      summary: typeof obj.summary === 'string' ? obj.summary : '',
      sentences: kept,
      error_types: types,
      weakest_points: (Array.isArray(obj.weakest_points) ? obj.weakest_points : [])
        .filter(function (x) { return typeof x === 'string' && x; }).slice(0, 3),
      problems: out.problems
    };
    return out;
  }

  return {
    BANDS: BANDS,
    TYPES: TYPES,
    STATE: STATE,
    setPrompt: setPrompt,
    extractJson: extractJson,
    buildMessages: buildMessages,
    validate: validate,
    bandOf: bandOf
  };
})();

/* =====================================================================
 * CET4 分支（大学英语四级翻译批改）
 * ------------------------------------------------------------
 * merge_cet4_branch.py 会把本文件**内联**进 ai-proxy 的 index.js。
 *
 * 🔴 设计原则：**一条都不重复造**
 *   · key 检查        → 复用现役 handle() 里已有的（插入点在它之后）
 *   · token 校验      → 同上
 *   · 配额/限流       → 同上（周窗口阈值 CFG.weeklyStopPct）
 *   · CFG / reply()   → 直接用现役的
 *   · 调 MiniMax      → 复制 callMiniMax 的 https 写法（**必须**：Node 沙箱里
 *                        没有全局 URL ⇒ 绝不能用 new URL()），但 messages 由我传入
 *                        （现役的 callMiniMax 把 SYSTEM_PROMPT 写死了）
 *   · CET4 核心       → ai/cet4-core.js（纯函数，无 DOM 无网络）
 *
 * ⚠️ 路径命名铁律（现役路由用 `gp.indexOf(...)` **子串包含**匹配）：
 *   现役 GET 依次判断 'prompt' → 'audio-config' → 'quota'
 *   ⇒ 我的路径**不能含这三个子串**，否则会先被日语分支吃掉
 *   ⇒ 用 'cet4-spec' 取 prompt+sha（避开 'prompt'）
 *   ⇒ 用 'cet4' 收 POST
 * ===================================================================== */

function cet4CallModel(messages) {
  return new Promise(function (resolve, reject) {
    /* max_completion_tokens 比现役的 2000 大：四级批改要输出结构化 JSON */
    var payloadObj = {
      model: CFG.model,
      messages: messages,
      max_completion_tokens: 3000,
      temperature: 0.2
    };
    Object.assign(payloadObj, thinkingField());
    var payload = JSON.stringify(payloadObj);

    /* ⚠️ 绝对不要用 new URL()：CloudBase 的 Node 沙箱里没有全局 URL
     *   （本地有 → 本地全绿、线上必挂）。沿用现役的纯字符串解析。 */
    var fullUrl = CFG.baseUrl + '/chat/completions';
    var um = /^(https?):\/\/([^/:?#]+)(?::(\d+))?([^?#]*)(\?[^#]*)?/.exec(fullUrl);
    if (!um) return reject(new Error('bad_base_url:' + fullUrl));
    var req = https.request({
      hostname: um[2],
      port: um[3] ? parseInt(um[3], 10) : 443,
      path: (um[4] || '/') + (um[5] || ''),
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(payload),
        'Authorization': 'Bearer ' + CFG.apiKey
      },
      timeout: CFG.timeoutMs
    }, function (res) {
      var buf = '';
      res.setEncoding('utf8');
      res.on('data', function (d) { buf += d; });
      res.on('end', function () {
        if (res.statusCode !== 200) {
          return reject(new Error('upstream_' + res.statusCode + ':' + buf.slice(0, 300)));
        }
        var j;
        try { j = JSON.parse(buf); } catch (e) { return reject(new Error('bad_upstream_json')); }
        if (j.base_resp && j.base_resp.status_code && j.base_resp.status_code !== 0) {
          return reject(new Error('upstream_biz:' + JSON.stringify(j.base_resp)));
        }
        var text = (j.choices && j.choices[0] && j.choices[0].message)
          ? (j.choices[0].message.content || '') : '';
        if (!text) return reject(new Error('empty_upstream_text'));
        resolve(text);
      });
    });

    req.on('timeout', function () { req.destroy(new Error('timeout')); });
    req.on('error', function (e) { reject(e); });
    req.write(payload);
    req.end();
  });
}

/* ================================================================
 * POST /ai/cet4
 * body = { mode:"2"|"5", sentences:[{no,zh,reference,points}], student:[{no,text}] }
 * ================================================================ */
async function cet4Route(data) {
  var b = data || {};
  if (!Array.isArray(b.sentences) || !b.sentences.length) {
    return reply(400, { ok: false, error: 'bad_request' });
  }
  var anyText = false;
  for (var i = 0; i < (b.student || []).length; i++) {
    if (String((b.student[i] || {}).text || '').trim()) { anyText = true; break; }
  }
  if (!anyText) return reply(400, { ok: false, error: 'bad_request' });

  try {
    var msgs = CET4.buildMessages(b);
    var text = await cet4CallModel(msgs);
    var obj = CET4.extractJson(text);
    /* 🔴 抽不出 JSON ⇒ **不报错**，把模型原话透给前端。
     *   理由：模型不听话输出 markdown 是常态；给用户一句「失败了」比不给更糟。 */
    if (!obj) return reply(200, { ok: true, unparsed: true, raw: text });
    var v = CET4.validate(obj, b);
    if (!v || !v.ok) return reply(200, { ok: true, unparsed: true, raw: text });
    return reply(200, { ok: true, result: v.result });
  } catch (e) {
    var msg = (e && e.message) || 'unknown';
    console.error('[cet4] fail ' + msg + ' | stack=' + String((e && e.stack) || '').split('\n').slice(0, 3).join(' / '));
    if (msg === 'timeout') return reply(504, { ok: false, error: 'timeout' });
    if (msg.indexOf('upstream_401') >= 0 || msg.indexOf('2049') >= 0) {
      return reply(502, { ok: false, error: 'upstream_auth' });
    }
    if (msg.indexOf('2013') >= 0) {
      return reply(502, { ok: false, error: 'upstream_params' });
    }
    if (msg.indexOf('2056') >= 0) {
      return reply(429, { ok: false, error: 'quota_exceeded' });
    }
    return reply(502, { ok: false, error: 'upstream_error' });
  }
}

/* ================================================================
 * GET /ai/cet4-spec —— 取 prompt + sha（前端对齐用，不烧额度）
 * ================================================================ */
function cet4Spec() {
  var p = CET4.STATE.prompt;
  var sha = crypto.createHash('sha256').update(p, 'utf8').digest('hex');
  return reply(200, {
    ok: true,
    prompt: p,
    prompt_sha: sha,
    prompt_len: p.length,
    types: CET4.TYPES,
    bands: CET4.BANDS
  });
}
  return { CET4: CET4, cet4Route: cet4Route, cet4Spec: cet4Spec };
})();
/*__CET4_BLOCK_END_3*/
